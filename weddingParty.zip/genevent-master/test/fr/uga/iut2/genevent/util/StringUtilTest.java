package fr.uga.iut2.genevent.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringUtilTest {

    @Test
    void capitalize(){

        //
        assertEquals(StringUtil.capitalize("bonjour"), "Bonjour", "La fonction est censée retourné une chaine de caractère avec la première" +
                " lettre en majuscule et le reste en minuscule");

        //
        assertEquals(StringUtil.capitalize("bonjOur"), "Bonjour", "La fonction est censée retourné une chaine de caractère avec la première " +
                "lettre en majuscule et le reste en minuscule");

        //
        assertEquals(StringUtil.capitalize("Bonjour"), "Bonjour", "La fonction est censée retourné une chaine de caractère avec la première " +
                "lettre en majuscule et le reste en minuscule");

        assertEquals(StringUtil.capitalize("Bonjour Le Correcteur"), "Bonjour le correcteur", "La fonction est censée retourné une chaine de caractère avec la première " +
                "lettre en majuscule et le reste en minuscule");
    }



}