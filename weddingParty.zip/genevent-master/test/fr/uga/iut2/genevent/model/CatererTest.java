package fr.uga.iut2.genevent.model;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class CatererTest {

    @Test
    void setCompanyName() {
        Caterer caterer1 = new Caterer("mcdonalds","Menu Fish Mac", CatererCategory.Francais,
                    "0525285",
                    new Adresse("8","rue des poissons","38900"),
                    "bonjour@gmail.com");
        assertEquals("Mcdonalds",caterer1.getCompanyName(),"Un nom doit avoir la première lettre en " +
                "Majuscule et le reste en minuscule");
    }

    @Test
    void getMenu() {
        Adresse adresse2 = new Adresse("10","rue des chevaux","38900");
        Caterer caterer2 = new Caterer("Pizza Autentica", "Pizza Napolitaine", CatererCategory.Italien,
                "05123687", adresse2, "pizzaantentica@gmail.com");

        assertEquals("Pizza Napolitaine",caterer2.getMenu(),"Le getter nom doit renvoyé le menu de l'entreprise");

    }

    // TEST DE isReservedFor : tester si un mariage est réservé pour ce traiteur pour la date donné par le mariage
    @Test
    void addWedding() {
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);

        Individual marieA = new Individual("Bulut","Jesse",new Date(2002,8,03),"0667841726",
                new Adresse("6","allée","38800"),"jesse@gmail.com");
        Individual marieB = new Individual("Bulut","Jimmy",new Date(2000,7,04),"068821726",
                new Adresse("7","rue","38700"),"jimmye@gmail.com");

        Wedding wedding1 = new Wedding(new Individual("Bulut","Jean",new Date(1975,7,04),"070821726",
                new Adresse("7","rue","38700"),"jimmye@gmail.com"),marieA, marieB,startDate1,endDate1);

        Caterer caterer1 = new Caterer("carrefour","un menu",
                CatererCategory.Francais,"060515151",
                new Adresse("8","rue des poissons","38900"),
                "carrefour@gmail.com");

        caterer1.addWedding(wedding1);
        boolean isReservedFor = caterer1.isWeddingReservedFor(wedding1);
        assertTrue(isReservedFor, "Le traiteur devrait contenir le mariage dans sa liste et donc retourner true");
    }

    //TEST POUR VERIFIER QU'UN TRAITEUR A BIEN ENREGISTRE UN MARIAGE
    @Test
    void isIntervalReserved(){
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);

        //Création des mariés
        Individual marieA = new Individual("Bulut","Jesse",new Date(2002,8,03),"0667841726",
                new Adresse("6","allée","38800"),"jesse@gmail.com");
        Individual marieB = new Individual("Bulut","Jimmy",new Date(2000,7,04),"068821726",
                new Adresse("7","rue","38700"),"jimmye@gmail.com");

        // Création du mariage avec le client et les mariés
        Wedding wedding2 = new Wedding(new Individual("Aulut","Jean",new Date(1975,7,04),"070821726",
                new Adresse("7","rue","38700"),"jimmye@gmail.com"),marieA, marieB,startDate1,endDate1);

        // Création du traiteur
        Caterer caterer1 = new Caterer("carrefour","un menu",
                CatererCategory.Francais,"060515151",
                new Adresse("8","rue des poissons","38900"),
                "carrefour@gmail.com");

        //Ajout du mariage dans traiteur
        caterer1.addWedding(wedding2);

        assertTrue(caterer1.isWeddingReservedFor(wedding2),"Le mariage devrait être parmis ceux enregistrés " +
                "par le traiteur.");
    }

    //TEST POUR VERIFIER QU'UN TRAITEUR A BIEN SUPPRIME UN MARIAGE
    @Test
    void removeWedding() {
        //Création des dates
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);

        //Création des mariés
        Individual marieA = new Individual("Bulut","Jesse",new Date(2002,8,03),"0667841726",
                new Adresse("6","allée","38800"),"jesse@gmail.com");
        Individual marieB = new Individual("Bulut","Jimmy",new Date(2000,7,04),"068821726",
                new Adresse("7","rue","38700"),"jimmye@gmail.com");

        // Création du mariage avec le client et les mariés
        Wedding wedding2 = new Wedding(new Individual("Aulut","Jean",new Date(1975,7,04),"070821726",
                new Adresse("7","rue","38700"),"jimmye@gmail.com"),marieA, marieB,startDate1,endDate1);

        // Création du traiteur
        Caterer caterer1 = new Caterer("carrefour","un menu",
                CatererCategory.Francais,"060515151",
                new Adresse("8","rue des poissons","38900"),
                "carrefour@gmail.com");

        //Ajout du mariage dans traiteur
        caterer1.addWedding(wedding2);

        //Retrait du mariage dans traiteur
        caterer1.removeWedding(wedding2);
        assertFalse(caterer1.isWeddingReservedFor(wedding2),"Le mariage ne devrait pas être parmis ceux enregistrés " +
                "par le traiteur car il a été enlevé");

        boolean isReservedFor = caterer1.isWeddingReservedFor(wedding2);

    }
}