package fr.uga.iut2.genevent.model;

import org.apache.commons.digester.plugins.strategies.LoaderFromClass;
import org.junit.jupiter.api.Test;


import java.util.Date;


import static org.junit.jupiter.api.Assertions.*;

class DateIntervalTest {

    @Test
    void setDateInterval() {
        //
        Date startDate = new Date(1900,10,19);
        Date endDate = new Date(1900, 10,20);
        DateInterval dateInterval = new DateInterval(startDate,endDate);
        assertEquals(dateInterval.getEndDate(), endDate, "La fonction est censée retourner la date de fin car celle-ci se situe bien après" +
                " / egal la date de début");

        //
        Date endDate1 = new Date(1900, 10,19);
        DateInterval dateInterval1 = new DateInterval(startDate,endDate1);
        assertEquals(dateInterval1.getEndDate(), endDate1, "La fonction est censée retourner la date de fin car celle-ci se situe bien après" +
                " / egal la date de début");

        //
        Date endDate2 = new Date(1900, 10,18);
        DateInterval dateInterval2 = new DateInterval(startDate,endDate2);
        assertNull(dateInterval2.getEndDate(), "La fonction est censée retourner null car endDate se situe avant startDate");

        //

        DateInterval dateInterval3 = new DateInterval(null,null);
        assertNull(dateInterval2.getEndDate(), "La fonction est censée retourner null car aucune des entrées n'étaient valides"); // pas sûr que ça soit utile
    }

    // TEST DE OVERLAP : TESTER SI DEUX DATES SE SUPERPOSENT
    @Test
    void overlap() {

        //TEST 1
        Date startDate = new Date(1900,10,19);
        Date endDate = new Date(1900, 10,20);
        DateInterval dateInterval= new DateInterval(startDate,endDate);

        Date startDate1 = new Date(1900,10,18);
        Date endDate1 = new Date(1900, 10,19);
        DateInterval dateInterval1 = new DateInterval(startDate1,endDate1);

        assertTrue(dateInterval1.overlap(dateInterval), "La fonction est censée retourner vrai car la date " +
                "entrée en pramètre s'entrpose avec l'autre date");

        //TEST 2
        Date startDate2 = new Date(1900,10,1);
        Date endDate2 = new Date(1900, 10,20);
        DateInterval dateInterval2= new DateInterval(startDate2,endDate2);

        Date startDate3 = new Date(1900,9,1);
        Date endDate3 = new Date(1900, 9,2);
        DateInterval dateInterval3 = new DateInterval(startDate3,endDate3);

        assertFalse(dateInterval2.overlap(dateInterval3), "La fonction est censée retourner faux car les deux " +
                "dates ne s'entreposent pas");

        //TEST 3
        Date startDate4 = new Date(1900,9,19);
        Date endDate4 = new Date(1900, 10,20);
        DateInterval dateInterval4= new DateInterval(startDate,endDate);

        Date startDate5 = new Date(1900,10,15);
        Date endDate5 = new Date(1900, 10,16);
        DateInterval dateInterval5 = new DateInterval(startDate1,endDate1);

        assertTrue(dateInterval4.overlap(dateInterval5), "La fonction est censée retourner vrai, car les deux " +
                "dates ne s'entreposent pas");


    }
}