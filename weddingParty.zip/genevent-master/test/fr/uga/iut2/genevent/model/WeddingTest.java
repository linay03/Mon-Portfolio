package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.exceptions.AdresseInvalideException;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class WeddingTest {

    //TEST AJOUT DE TRAITEUR POUR UN MARIAGE
    @Test
    void addCaterer() {

        //
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);
        Individual marieA = new Individual("Sulut","Jesse");
        Individual marieB = new Individual("Bulut","Jimmy");
        Individual client1 = new Individual("Aulut" ,"Jean");

        // Creation du mariage
        Wedding wedding = new Wedding(client1, marieA,marieB,startDate1,endDate1);

        // Creation des traiteurs
        Caterer caterer1 = new Caterer("carrefour","un menu",
                CatererCategory.Francais,"060515151",
                new Adresse("8","rue des poissons","38900"),
                "carrefour@gmail.com");

        Caterer caterer2 = new Caterer("carrefour","un menu",
                CatererCategory.Francais,"060515151",
                new Adresse("8","rue des poissons","38900"),
                "carrefour@gmail.com");


        // Ajout des traiteurs
        wedding.addCaterer(caterer1);

        assertEquals(wedding.getCaterers().get(0), caterer1, "Le traiteur retenu dans la liste du mariage doit etre le même que celui rentré");

        // Ajout des traiteurs
        wedding.addCaterer(caterer2);
        assertEquals(wedding.getCaterers().get(1), caterer2, "Le traiteur retenu dans la liste du mariage doit etre le même que celui rentré");

        // Ajout d'un traiteur déjà présent
        wedding.addCaterer(caterer2);
        assertEquals(wedding.getCaterers().size(), 2, "Le traiteur ne doit pas etre réajouté à la liste de traiteurs du mariage car il est déjà présent.");


        // Ajout bidirectionnel : quand un mariage ajoute un traiteur, le traiteur ajoute également ce mariage

        assertTrue(caterer1.containsWedding(wedding), "Le traiteur ajoute également le mariage dans sa liste de réservation");
        assertTrue(caterer2.containsWedding(wedding), "Le traiteur ajoute également le mariage dans sa liste de réservation");
    }

    @Test
    void setCaterer() {

        //
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);
        Individual marieA = new Individual("Sulut","Jesse");
        Individual marieB = new Individual("Bulut","Jimmy");
        Individual client1 = new Individual("Aulut" ,"Jean");

        // Creation du mariage
        Wedding wedding = new Wedding(client1, marieA,marieB,startDate1,endDate1);

        // Creation des traiteurs
        Caterer caterer1 = new Caterer("carrefour","un menu",
                CatererCategory.Francais,"060515151",
                new Adresse("8","rue des poissons","38900"),
                "carrefour@gmail.com");

        Caterer caterer2 = new Caterer("carrefour","un menu",
                CatererCategory.Francais,"060515151",
                new Adresse("8","rue des poissons","38900"),
                "carrefour@gmail.com");

        // Ajout des traiteurs dans une liste
        ArrayList<Caterer> caterers = new ArrayList<>(Arrays.asList(caterer1,caterer2));

        // Ajout de ses traiteurs dans Wedding
        wedding.setCaterers(caterers);

        // Test de leur présence
        assertEquals(wedding.getCaterers().get(0), caterer1, "Le traiteur retenu dans la liste du mariage doit etre le même que celui rentré");
        assertEquals(wedding.getCaterers().get(1), caterer2, "Le traiteur retenu dans la liste du mariage doit etre le même que celui rentré");

        // Ajout d'un traiteur déjà présent
        wedding.addCaterer(caterer2);
        assertEquals(wedding.getCaterers().size(), 2, "Le traiteur ne doit pas etre réajouté à la liste de traiteurs du mariage car il est déjà présent.");

        // Ajout bidirectionnel : quand un mariage ajoute un traiteur, le traiteur ajoute également ce mariage
        assertTrue(caterer1.containsWedding(wedding), "Le traiteur ajoute également le mariage dans sa liste de réservation");
        assertTrue(caterer2.containsWedding(wedding), "Le traiteur ajoute également le mariage dans sa liste de réservation");
    }

    // TEST POUR VERIFIER SI UN LIEU EST ENREGISTRE POUR LE MARIAGE
    @Test
    void containsLocation() throws AdresseInvalideException {

        Adresse adr1 = new Adresse("6","rue des poissons","38800");
        Adresse adr2 = new Adresse("8","rue des poissons","38900");
        Owner owner = new Owner("Bulut", "065854",adr2,"maildebulut@gmail.com");
        ArrayList<DateInterval> unavailabilities1 = new ArrayList<>();
        //DateInterval dateInterval1 = new DateInterval(new Date(2022,02,03),new Date(2022,02,04));
        //unavailabilities.add(dateInterval1);
        Location location1 = new Location("Fuschiaa",adr1, 88, 115, owner,15.55f,
                InteriorExterior.Exterieur,"Parc avec fontaines",unavailabilities1);

        //
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);
        Individual marieA = new Individual("Sulut","Jesse");
        Individual marieB = new Individual("Bulut","Jimmy");
        Individual client1 = new Individual("Aulut" ,"Jean");

        // Creation du mariage
        Wedding wedding = new Wedding(client1, marieA,marieB,startDate1,endDate1);


        assertFalse(wedding.containsLocation(location1), "Ce mariage ne doit pas contenir ce lieu, car il n'en contient aucun");

        // Ajout du lieu dans le mariage
        wedding.addLocation(location1);

        assertTrue(wedding.containsLocation(location1), "Le lieux doit etre présent dans la liste de lieu du mariage");
    }

    //TEST D'AJOUT D'UN LIEU POUR UN MARIAGE
    @Test
    void testAddLocation() throws AdresseInvalideException { // et bidirectionnalité

        Adresse adr1 = new Adresse("6","rue des poissons","38800");

        Owner owner = new Owner("Bulut", "065854",new Adresse("8","rue des poissons","38900"),"maildebulut@gmail.com");
        ArrayList<DateInterval> unavailabilities2 = new ArrayList<>();
        Location location1 = new Location("Fuschiaa",adr1,
                88,115,owner,15.55f,InteriorExterior.Exterieur,"Parc avec fontaines",unavailabilities2);

        //
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);
        Individual marieA = new Individual("Sulut","Jesse");
        Individual marieB = new Individual("Bulut","Jimmy");
        Individual client1 = new Individual("Aulut" ,"Jean");

        // Creation du mariage
        Wedding wedding = new Wedding(client1, marieA,marieB,startDate1,endDate1);


        wedding.addLocation(location1);

        assertTrue(wedding.containsLocation(location1), "Ce lieu doit avoir été ajouté dans la liste");
        assertTrue(location1.containsWedding(wedding), "Le mariage doit également aovir été ajouté dans la liste de mariage réservé pour ce lieu");



        Adresse adr2 = new Adresse("16","rue des poissons","38800");
        ArrayList<DateInterval> unavailabilities3 = new ArrayList<>();
        Location location2 = new Location("Fuschiaa",adr2,
                88,155,new Owner("Bulut","Sha","065854",new Adresse("8","rue des poissons","38900"),
                "maildebulut@gmail.com"),15.55f,InteriorExterior.InterieurEtExterieur,"Parc avec fontaines",unavailabilities3);

        //
        Individual marieAA = new Individual("Lulut","Jesse");
        Individual marieBB = new Individual("Julut","Jimmy");
        Individual client2 = new Individual("Aulut" ,"Jean");

        // Creation du mariage
        Wedding wedding2 = new Wedding(client2, marieAA,marieBB,startDate1,endDate1);

        // Non ajout du lieu dans le mariage
        wedding2.addLocation(location2);
        assertFalse(wedding2.containsLocation(location1), "Ce lieu est déjà réservé à cette date et ne peut donc pas etre ajouté et présent dans cet autre mariage");

    }



}