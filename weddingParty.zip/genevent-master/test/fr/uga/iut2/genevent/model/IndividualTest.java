package fr.uga.iut2.genevent.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IndividualTest {

    @Test
    void setName() {
        Individual individual1 = new Individual("dupont", "Joshua");
        assertEquals(individual1.getName(),"Dupont", "Un nom doit avoir sa première lettre en majuscule et le reste en minuscule");
    }

    @Test
    void setFirstName() {
         Individual individual1 = new Individual("Dupont", "joshua");
        assertEquals(individual1.getFirstName(),"Joshua", "Un prénom doit avoir sa première lettre en majuscule et le reste en minuscule");
    }

}