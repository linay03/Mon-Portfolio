package fr.uga.iut2.genevent.model;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class EquipmentOrderTest {

    //TEST
//    @Test
//    void setAmountWedding() {
//        Individual marieA = new Individual("Bulut","Jesse");
//        Individual marieB = new Individual("Didouze","Jimmy");
//        Wedding wedding1 = new Wedding(new Individual("Bulut","Jean"),marieA,marieB);
//
//        // Création d'une nouvelle adresse et du supplier needed pour equipment
//        Adresse adresseSupplier = new Adresse(new Adresse("302 bis","rue des bois", "38000"));
//        Supplier supplier = new Supplier("Meubles de bonne qualité", "0379877665",adresseSupplier, "meubles@gmail.com");
//
//        Equipment equipment = new Equipment("Table","Table en bois",
//                15.55f,50,EquipmentCategory.Furniture, supplier);
//        assertThrows(IllegalArgumentException.class,()->{
//            new EquipmentOrder(equipment,-15,wedding1);
//            },"Une quantité demandée doit être inférieur au stock actuel");
//        }

    // TEST DE GETSTOCK POUR LES RESERVATIONS EXTERIEURS
//    @Test
//    void setAmountOthers() {
//        Individual marieA = new Individual("Bulut","Jesse");
//        Individual marieB = new Individual("Didouze","Jimmy");
//        Wedding wedding1 = new Wedding(new Individual("Bulut","Jean"),marieA,marieB);
//
//        // Création d'une nouvelle adresse et du supplier needed pour equipment
//        Adresse adresseSupplier = new Adresse(new Adresse("302 bis","rue des bois", "38000"));
//        Supplier supplier = new Supplier("Meubles de bonne qualité", "0379877665",adresseSupplier, "meubles@gmail.com");
//
//        Equipment equipment = new Equipment("Table","Table en bois",
//                15.55f,50, CategorieMateriel.Meubles,supplier);
//        DateInterval dateInterval = new DateInterval(new Date(2023,05,05),new Date(2023,05,05));
//        assertThrows(IllegalArgumentException.class,()->{
//            new EquipmentOrder(equipment,-78,dateInterval);},"Une quantité demandée doit être inférieure au stock actuel");
//    }

    // TEST AJOUT DE RESERVATIONS DE MARIAGE DANS EQUIPEMENT
    @Test
    void addEquipmentWedding() {

        // Création d'une nouvelle adresse et du supplier needed pour equipment
        Adresse adresseSupplier = new Adresse(new Adresse("302 bis","rue des bois", "38000"));
        Supplier supplier = new Supplier("Meubles de bonne qualité", "0379877665",adresseSupplier, "meubles@gmail.com");

        Equipment equipment = new Equipment("Table","Table en bois",
                15.55f,50, CategorieMateriel.Meubles,supplier);
        Individual marieA = new Individual("Bulut","Jesse");
        Individual marieB = new Individual("Didouze","Jimmy");
        Wedding wedding1 = new Wedding(new Individual("Bulut","Jean"),marieA,marieB);
        EquipmentOrder equipmentOrder = new EquipmentOrder(equipment,18,wedding1);
        equipmentOrder.addEquipmentWedding();
        int size = equipment.getWeddingsReserved().size();
        assertEquals(wedding1,equipment.getWeddingsReserved().get(size-1),"L'ajout de wedding dans equipment n'est pas valide");
    }

    // TEST AJOUT DE RESERVATIONS EXTERIEURES DANS EQUIPEMENT
    @Test
    void addEquipmentOthers() {

        // Création d'une nouvelle adresse et du supplier needed pour equipment
        Adresse adresseSupplier = new Adresse(new Adresse("302 bis","rue des bois", "38000"));
        Supplier supplier = new Supplier("Meubles de bonne qualité", "0379877665",adresseSupplier, "meubles@gmail.com");

        Equipment equipment = new Equipment("Table","Table en bois",
                15.55f,50, CategorieMateriel.Meubles, supplier);
        DateInterval dateInterval = new DateInterval(new Date(2023,05,05),new Date(2023,05,05));
        EquipmentOrder equipmentOrder = new EquipmentOrder(equipment,18,dateInterval);
        equipmentOrder.addEquipmentOthers();
        int size = equipment.getOthersReservations().size();
        assertEquals(equipmentOrder,equipment.getOthersReservations().get(size-1),"L'ajout de others dans equipment n'est pas valide");

    }
}