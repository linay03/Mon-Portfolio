package fr.uga.iut2.genevent.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AdresseTest {

    @Test
    void setRue() {
        Adresse adresse1 = new Adresse("6", "RUE des poissons", "38330");
        assertEquals("rue des poissons", adresse1.getNomRue(), "Le nom de rue doit être en minuscule");
    }

    @Test
    void setCodePostal() throws IllegalArgumentException {
        assertThrows(IllegalArgumentException.class, () -> {
                    new Adresse("6", "RUE des poissons", "38");}
                , "Un code postal doit être de 5 chiffres");
    }


    @Test
    void testEquals() {

        // CREATION DE 2 ADRESSES ÉQUIVALENTES
        Adresse adresse1 = new Adresse("6", "RUE des poissons", "38330");
        Adresse adresse2 = new Adresse("6", "RUE des poissons", "38330");

        // TEST D'EGALITÉ
        assertTrue(adresse1.equals(adresse2), "Les deux adresses ont les mêmes attributs, et devraient etre égales");
        assertTrue(adresse2.equals(adresse1), "Les deux adresses ont les mêmes attributs, et devraient etre égales");

        // TEST POUR DIFFERENCE DE NUMERO DE RUE
        Adresse adresse3 = new Adresse("8", "RUE des poissons", "38330");
        assertFalse(adresse1.equals(adresse3), "Les deux adresses n'ont pas les mêmes attributs, et ne devraient pas etre égales");

        // TEST POUR DIFFERENCE DE RUE
        Adresse adresse4 = new Adresse("6", "RUE des cerisiers", "38330");
        assertFalse(adresse1.equals(adresse4), "Les deux adresses n'ont pas les mêmes attributs, et ne devraient pas etre égales");

        // TEST POUR DIFFERENCE DE NOM
        Adresse adresse5 = new Adresse("8", "RUE des poissons", "38330");
        assertFalse(adresse1.equals(adresse5), "Les deux adresses n'ont pas les mêmes attributs, et ne devraient pas etre égales");

        // TEST POUR DIFFERENCE DE CODE POSTAL
        Adresse adresse6 = new Adresse("8", "RUE des poissons", "38330");
        assertFalse(adresse1.equals(adresse6), "Les deux adresses n'ont pas les mêmes attributs, et ne devraient pas etre égales");

        // TEST POUR DIFFERENCE DE CODE POSTAL
        Adresse adresse7 = null;
        assertFalse(adresse1.equals(adresse7), "Une adresse ne doit pas etre egale à un objet null");
    }
}



