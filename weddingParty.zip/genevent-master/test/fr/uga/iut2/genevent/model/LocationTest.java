package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.exceptions.AdresseInvalideException;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class LocationTest {

    @Test
    void getName() throws AdresseInvalideException {
        ArrayList<DateInterval> unavailabilities1 = new ArrayList<>();
        Location location1 = new Location("fuscHiaa",new Adresse("6","rue des poissons","38800"),
                100,155,new Owner("Bulut","Jean","065854",new Adresse("8","rue des poissons","38900"),
                "maildebulut@gmail.com"),55,InteriorExterior.Interieur, "5 entrées",unavailabilities1);
        assertEquals(location1.getName(),"Fuschiaa","Un nom doit avoir la première lettre en Majuscule et le reste en minuscule");
    }

    @Test
    void setCapacity() {
        assertThrows(IllegalArgumentException.class,()-> {
            new Location("Fuschiaa",new Adresse("7","rue des poissons","38800"),
                    -88,155,new Owner("Bulut","Jean","065854",new Adresse("8","rue des poissons"
                    ,"38900"),
                    "maildebulut@gmail.com"),15.55f,InteriorExterior.Exterieur,"Accès handicap",new ArrayList<DateInterval>());}
                ,"La capacite ne peut pas être negative" );
    }

    @Test
    void setPrice() {
        assertThrows(IllegalArgumentException.class,()-> {
            new Location("Fuschiaa",new Adresse("9","rue des canards","38800"),
                    25,50,new Owner("Bulut","Sha","065854",new Adresse("8","rue des poissons","38900"),
                    "maildebulut@gmail.com"),-15.55f,InteriorExterior.InterieurEtExterieur,"Terrasse 20m2",new ArrayList<DateInterval>());},"Un prix ne peux pas être négatif");
    }

    // TEST DE L'AJOUT D'UN LIEU DANS WEDDING
    @Test
    void addWedding() throws AdresseInvalideException {
        Individual marieA = new Individual("Bulut","Jesse");
        Individual marieB = new Individual("Bulut","Jimmy");
        Wedding wedding1 = new Wedding(new Individual("Bulut","Jean"),marieA,marieB);
        ArrayList<DateInterval> unavailabilities2 = new ArrayList<>();

        Location location1= new Location("Fuschiaa",new Adresse("11","rue des poissons","38800"),
                88,50,new Owner("Bulut","Sha","065854",new Adresse("8","rue des poissons","38900"),
                "maildebulut@gmail.com"),15.55f,InteriorExterior.InterieurEtExterieur,"Terrasse avec meubles",unavailabilities2);
        wedding1.addLocation(location1);
        int size = wedding1.getLocations().size();
        assertEquals(wedding1.getLocations().get(size-1),location1);
    }

    //TEST POUR ENREGISTRER UN LIEU QUI NE DOIT PAS AVOIR LA MEME ADRESSE
    @Test
    void setAdresse() throws AdresseInvalideException{

        GenEvent genEvent = new GenEvent();
        RootController.setGenevent(genEvent);


        Adresse adr1 = new Adresse("25","rue des poissons","38800");
        Adresse adr2 = new Adresse("18","rue des poissons","38800");

        ArrayList<DateInterval> unavailabilities3 = new ArrayList<>();
        ArrayList<DateInterval> unavailabilities4 = new ArrayList<>();

        Location location1= new Location("Fuschiaa",adr1,
                    88,40,new Owner("Bulut","Sha","065854",new Adresse("72","rue des poissons","38900"),
                    "maildebulut@gmail.com"),15.55f,InteriorExterior.InterieurEtExterieur, "Terrasse avec meubles",unavailabilities3);

        Location location2= new Location("Fuschiaa",adr2,
                    88,40,new Owner("Bulut","Sha","065854",new Adresse("72","rue des poissons","38900"),
                    "maildebulut@gmail.com"),15.55f,InteriorExterior.InterieurEtExterieur, "Terrasse avec meubles",unavailabilities4);

        RootController.getGenevent().newLocation(location1);
        RootController.getGenevent().newLocation(location2);

        assertThrows(AdresseInvalideException.class, () -> {location1.setAdress(adr2);}, "Un lieu ne peut pas avoir la même adresse qu'un autre lieu existant");

    }

    // TEST POUR VERIFIER SI LOCATION A ENREGSTRE UN MARIAGE
    @Test
    void containsWedding() throws AdresseInvalideException {
        Adresse adr1 = new Adresse("52","rue des fleurs","38800");
        ArrayList<DateInterval> unavailabilities = new ArrayList<>();
        Location location1 = new Location("Fuschiaa",adr1,
                88,150,new Owner("Bulut","Sha","065854",new Adresse("30","rue des fleurs","38900"),
                "maildebulut@gmail.com"),15.55f,InteriorExterior.InterieurEtExterieur,"",unavailabilities);

        //
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);
        Individual marieA = new Individual("Sulut","Jesse");
        Individual marieB = new Individual("Bulut","Jimmy");
        Individual client1 = new Individual("Aulut" ,"Jean");

        // Creation du mariage
        Wedding wedding = new Wedding(client1, marieA,marieB,startDate1,endDate1);

        assertFalse(location1.containsWedding(wedding), "Ce lieu n'a pas été ajouté au mariage et ne doit pas être présent dans la liste de lieu du mariage");


        location1.addWedding(wedding);
        assertTrue(location1.containsWedding(wedding), "Ce lieu vient d'etre ajouté au mariage et doit être présent dans la liste de lieu du mariage");
    }
}