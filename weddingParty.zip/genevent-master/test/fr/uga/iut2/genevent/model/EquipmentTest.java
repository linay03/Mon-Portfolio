package fr.uga.iut2.genevent.model;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class EquipmentTest {

    // TEST POUR RECUPERER LE CURRENTSTOCK POUR UNE DATE
    @Test
    void getCurrentStock() {
        Supplier supplier = new Supplier("Ikea", "0767564534", new Adresse("409", "rue des cocinnelles", "38000"),"ikea@gmail.com");
        Equipment equipment = new Equipment("Table","Table en bois",
                15.55f,50, CategorieMateriel.Meubles, supplier);

        //Création mariage 1
        Date startDate1 = new Date(2000,11,19);
        Date endDate1 = new Date(2000,11,19);
        Individual marieA = new Individual("Sulut","Jesse");
        Individual marieB = new Individual("Bulut","Jimmy");
        Individual client1 = new Individual("Aulut" ,"Jean");
        Wedding wedding = new Wedding(client1, marieA,marieB,startDate1,endDate1);
        wedding.addEquipmentOrder(equipment,5);

        // Creation du mariage 2
        Date startDate2 = new Date(2000,11,19);
        Date endDate2 = new Date(2000,11,19);

        Individual client2 = new Individual("Dupont" ,"Jean");
        Wedding wedding2 = new Wedding(client2, marieA,marieB,startDate2,endDate2);
        wedding2.addEquipmentOrder(equipment,5);

        EquipmentOrder equipmentOrder = wedding.getEquipmentOrders().get(0);
        assertEquals(40,wedding.getEquipmentOrders().get(0).getEquipment().getCurrentStock(equipmentOrder),"Le stock actuel n'est pas bon");

        //===================
        Equipment equipment2 = new Equipment("Table","Table en bois",
                15.55f,50, CategorieMateriel.Meubles, supplier);

        //Création equipmentOrder1
        Date startDate3 = new Date(2000,11,19);
        Date endDate3 = new Date(2000,11,19);
        EquipmentOrder equipmentOrder1 = new EquipmentOrder(equipment2,3,new DateInterval(startDate3,endDate3));
        equipmentOrder1.addEquipmentOthers();

        //Création equipmentOrder2
        Date startDate4 = new Date(2000,11,19);
        Date endDate4 = new Date(2000,11,19);
        EquipmentOrder equipmentOrder2 = new EquipmentOrder(equipment2,5,new DateInterval(startDate4,endDate4));
        equipmentOrder2.addEquipmentOthers();

        assertEquals(42,equipment2.getCurrentStock(equipmentOrder2),"Le stock actuel n'est pas bon");


        //===================
        Equipment equipment3 = new Equipment("Table","Table en bois",
                15.55f,50, CategorieMateriel.Meubles, supplier);

        //Création equipmentOrder1
        Date startDate5 = new Date(2004,11,18);
        Date endDate5 = new Date(2004,11,20);
        EquipmentOrder equipmentOrder3 = new EquipmentOrder(equipment3,3,new DateInterval(startDate5,endDate5));
        equipmentOrder3.addEquipmentOthers();

        //Création equipmentOrder2
        Date startDate6 = new Date(2004,11,19);
        Date endDate6 = new Date(2004,11,19);
        EquipmentOrder equipmentOrder4 = new EquipmentOrder(equipment3,5,new DateInterval(startDate6,endDate6));
        equipmentOrder4.addEquipmentOthers();

        assertEquals(42,equipment3.getCurrentStock(equipmentOrder4),"Le stock actuel n'est pas bon");
    }

}