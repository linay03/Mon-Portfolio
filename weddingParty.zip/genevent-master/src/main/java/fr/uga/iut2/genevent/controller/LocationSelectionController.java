package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.DesignLocation.LocationDesignController;
import fr.uga.iut2.genevent.controller.SelectionItems.SelectionItemController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Location;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class LocationSelectionController extends SelectionController<Location> {

    private ArrayList<Location> unavailable;

    public LocationSelectionController(Selector<Location> selectorObject, ArrayList<Location> unavailable){
        //Le selecteur où iras le lieu selectionné.
        super( selectorObject );
        this.unavailable = unavailable;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initialiseNames("Lieux", "lieu");
        initItems();
    }

    @Override
    protected void initItems() {
        for( Location location : RootController.getGenevent().getLocations()){

            Pane item;

            try{
                //Charge l'item et le relie à l'élement
                SelectionItemController<Location> controller = new SelectionItemController<>(location, getSelectorObject());
                FXMLLoader loader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/selectionItem.fxml"));
                loader.setController(controller);
                item = loader.load();
            } catch (IOException e) {
                item = new Pane(new Label(e.getMessage()));
                throw new RuntimeException(e);
            }
            //Assure que la taille de l'item prennent toute la fenêtre
            item.setMinWidth(super.getContent().getWidth());
            item.minWidthProperty().bind(super.getScrollPane().widthProperty());

            if(unavailable.contains(location)){
                item.setDisable(true);
            }
            //Ajoute l'item
            super.getContent().getChildren().add(item);
        }
    }

    @Override
    protected void createNew(ActionEvent event) {
        LocationDesignController controller = new LocationDesignController(getSelectorObject());
        RootController.getPageManager().stepForward(
                new Page("Création d'un lieu", "/fr/uga/iut2/genevent/views/Design/DesignLocation/designLocation.fxml",
                        controller, true)
        );
    }
}
