package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.ConsultationController.CatererConsultationDataController;
import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.util.StringUtil;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Cette classe représente la notion de traiteur. Un traiteur à différents attributs tels que :
 * companyName : le nom l'entreprise du traiteur
 * menu : le menu proposé par ce traiteur, dans notre cas, un traiteur ne gère qu'un menu
 * category : est la catégorie de nourriture que ce traiteur fourni dans le menu (ex : Mexicain, Italien...)
 * weddingsReserved : est une liste des différents mariages qui ont réservé ce traiteur.
 *
 */
public class Caterer extends Person implements Serializable, DirectoryItem<Caterer> {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation

    private String companyName;
    private String menu;
    private CatererCategory category;

    private ArrayList<Wedding> weddingsReserved;

     //private int nbDeMariagesMemeTps; // à voir si on add ça ou pas, mais si oui, y add dans le constructeur du traiteur

    private ArrayList<DateInterval> othersReservations = new ArrayList<>();


    /**
     * Constructeur de Caterer
     * @param companyName le nom l'entreprise du traiteur
     * @param menu le menu proposé par ce traiteur, dans notre cas, un traiteur ne gère qu'un menu
     * @param category la catégorie de nourriture que ce traiteur fourni dans le menu (ex : Mexicain, Italien...)
     * @param phone le numero de téléphone de l'entreprise du traiteur
     * @param adress l'adresse du siège du traiteur
     * @param email l'email de contact du traiteur
     */
    public Caterer(String companyName, String menu, CatererCategory category, String phone, Adresse adress, String email){
        super(phone, adress,email);
        setCompanyName(companyName);
        this.menu = menu;
        this.category = category;
        this.weddingsReserved=new ArrayList<>();
    }

    //Implementation de DirectoryItem
    @Override
    public ItemFieldInfos getItemFieldInfo() {
        return new ItemFieldInfos(10,20,30,10,
                getCompanyName(), getAdress().toString(), getMenu(), getCategory().name());
    }
    @Override
    public ConsultationDataController<Caterer> getConsultationDataController() {
        return new CatererConsultationDataController(this);
    }
    @Override
    public String getElementName() {
        return "traiteur";
    }

    //Getters & Setters
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Méthode permettant de définir le nom de l'entreprise en respectant la contrainte de la majuscule au début.
     * @param companyName est le nom de l'entreprise
     */
    public void setCompanyName(String companyName) {
        this.companyName = StringUtil.capitalize(companyName);
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    /**
     * Cette fonction vérifie si le mariage est déjà présent dans la liste de ce traiteur, un traiteur ne pouvant etre pris qu'une fois
     * @param wedding est la mariage pour lequel on vérifie la présence dans la liste de mariages du traiteur
     * @return vrai si le mariage est déjà présent pour ce traiteur, faux sinon
     */
    public boolean isWeddingReservedFor(Wedding wedding) {
        return weddingsReserved.contains(wedding);
    }
    public void addWedding(Wedding wedding){
        if (!this.isWeddingReservedFor(wedding) && !this.isIntervalReserved(wedding)
                && !this.isOthersReserved(wedding.getDateInterval())){
            this.weddingsReserved.add(wedding);
            if(!wedding.containsCaterer(this)){
                wedding.addCaterer(this);
            }
        }
    }

    public void removeWedding(Wedding wedding){
        if(this.isWeddingReservedFor(wedding)){
            this.weddingsReserved.remove(wedding);
            if(wedding.containsCaterer(this)){
                wedding.removeCaterer(this);
            }
        }

    }

    /**
     * Méthode qui teste si pour ce traiteur un
     * mariage est déjà pris à la date du mariage passé en paramètres
     * @param wedding est le mariage pour lequel on veut savoir si le traiteur est disponible
     * @return vrai si le traiteur n'est pas disponible pour le mariage, faux si le traiteur est disponible
     */
    public boolean isIntervalReserved(Wedding wedding){
       for (Wedding weddingReserved: weddingsReserved) {
           if (wedding.getDateInterval().overlap(weddingReserved.getDateInterval()) && weddingReserved != wedding){
               return true;
           }
       }
       return false;
    }

    public boolean containsWedding(Wedding wedding){
        return this.weddingsReserved.contains(wedding);
    }

    /**
     * Méthode qui teste si pour cette location une
     * réservation est déjà prise à la date du mariage passé en paramètres
     * @param dateInterval
     * @return
     */
    public boolean isOthersReserved(DateInterval dateInterval){
        for (DateInterval dateIntervalReserved: othersReservations){
            if (dateInterval.overlap(dateIntervalReserved)){

                return true;
            }
        }
        return false;
    }

    public void setCategory(CatererCategory category) {
        this.category = category;
    }

    public CatererCategory getCategory() {
        return category;
    }
}
