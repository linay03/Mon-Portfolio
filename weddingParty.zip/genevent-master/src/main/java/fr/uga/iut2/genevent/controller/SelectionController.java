package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.Selectors.Selector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

public abstract class SelectionController<T> extends ListController {
	
	private final Selector<T> selectorObject;

	protected Selector<T> getSelectorObject(){
		return selectorObject;
	}
	
	public SelectionController(Selector<T> dataObject){
		this.selectorObject = dataObject;
	}
	
	@Override
	public void backtrackedTo() {
		if(selectorObject.isChanged()){
			RootController.getPageManager().backtrack();
		}
	}
}
