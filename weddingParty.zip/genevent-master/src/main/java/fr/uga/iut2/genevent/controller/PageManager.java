package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.LeadingController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.model.GenEvent;

import java.util.ArrayList;

public class PageManager {



	private LeadingController leadingController;
	private ArrayList<Page> pages = new ArrayList<>();

	
	public LeadingController getLeadingController(){
		return leadingController;
	}
	public void setLeadingController(LeadingController leadingController){
		this.leadingController = leadingController;
	}

	public void setFirstPage(Page page){
		pages.clear();
		pages.add(page);
		leadingController.setActivePage(page);
		updateBreadCrumbs();
		leadingController.setDisableButtons(page.isLeadingDisabled());
	}
	public void stepForward(Page page){
		pages.add(page);
		leadingController.setActivePage(page);
		updateBreadCrumbs();
		leadingController.setDisableButtons(page.isLeadingDisabled());
	}
	
	public void backtrack(){
		if(pages.size() > 1){
			pages.remove( pages.size()-1 );
			leadingController.setActivePage(pages.get(pages.size() - 1));
			updateBreadCrumbs();
			leadingController.setDisableButtons( pages.get(pages.size()-1).isLeadingDisabled() );
			pages.get(pages.size()-1).backtrackedTo();
		}
	}
	
	private void updateBreadCrumbs(){
		StringBuilder text = new StringBuilder("> ");
		
		for ( int i = 0; i < pages.size()-1; i++ ) {
			text.append(pages.get(i).getName());
			text.append(" / ");
		}
		text.append( pages.get(pages.size()-1).getName() );
		
		leadingController.setBreadCrumbsText(text.toString());
	}
}
