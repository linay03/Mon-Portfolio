package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.DesignLocation.LocationDesignController;
import fr.uga.iut2.genevent.controller.DesignOwner.OwnerDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Location;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class LocationConsultationDataController extends ConsultationDataController<Location> {

    @FXML
    private Label nameLabel,roadNumberLabel,roadNameLabel,postalCodeLabel,priceLabel,capacityLabel,floorSpaceLabel,ownerLabel,insideOutsideLabel,detailLabel;

    public LocationConsultationDataController(Location location){
        super(location);

    }

    @Override
    public String getFxmlPath() {
        return "/fr/uga/iut2/genevent/views/Consultation/Location/consultationLocation.fxml";
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        Location location = getConsultedObject();
        nameLabel.setText(location.getName());
        roadNumberLabel.setText(location.getAdress().getNumeroRue());
        roadNameLabel.setText(location.getAdress().getNomRue());
        postalCodeLabel.setText(location.getAdress().getCodePostal());
        priceLabel.setText(String.valueOf(location.getPrice()));
        capacityLabel.setText(String.valueOf(location.getCapacity()));
        floorSpaceLabel.setText(String.valueOf(location.getSurface()));
        ownerLabel.setText(location.getOwner().getName());
        insideOutsideLabel.setText(location.getInteriorExterior().name());
        detailLabel.setText(location.getDetails());
    }

    @Override
    protected void edit(){
        LocationDesignController controller = new LocationDesignController(getConsultedObject());
        RootController.getPageManager().stepForward(
                new Page("Modification d'un lieu", "/fr/uga/iut2/genevent/views/Design/DesignLocation/designLocation.fxml",
                        controller, true)
        );
    }
}
