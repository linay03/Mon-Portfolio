package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.ConsultationController.IndividualConsultationDataController;
import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.util.StringUtil;

import java.io.Serializable;
import java.util.Date;

/**
 * Cette classe représente la notion de particulier
 * Un particulier hérite de la notion de personne. Il a donc comme attributs
 * name : le nom de famille du particulier
 * firstname : le prénom du particulier
 * birthdate : la date de naissance du particulier
 * phone : le numero de téléphone du particulier
 * adress : l'adresse du particulier
 * mail : l'adresse mail du particulier
 */
public class Individual extends Person implements Serializable, DirectoryItem<Individual> {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation

    private String name;

    private String firstName;

    private Date birthdate;

    /**
     * Constructeur prenant 2 paramètres de la classe particulier
     * @param name est le nom du particulier
     * @param firstName est le prénom du particulier
     */
    public Individual(String name, String firstName){
        super(null,null,null);
        setName(name);
        setFirstName(firstName);
    }
    /**
     * Constructeur prenant 6 paramètres
     * @param name st le nom du particulier
     * @param firstName est le prénom du particulier
     * @param birthdate est la date de naissance du particulier
     * @param phone est le numero de téléphone du particulier
     * @param adress est l'adresse physique du particulier
     * @param mail est ml'adresse mail du particulier
     */
    public Individual(String name, String firstName,Date birthdate,String phone, Adresse adress, String mail){
        super(phone, adress,mail);

        setName(name);
        setFirstName(firstName);
        this.birthdate = birthdate;

    }

    @Override
    public ItemFieldInfos getItemFieldInfo() {
        return new ItemFieldInfos(20, 20, 30, 0,
                getName(), getFirstName(), getMail(), "");
    }
    @Override
    public ConsultationDataController<Individual> getConsultationDataController() {
        return new IndividualConsultationDataController(this);
    }
    @Override
    public String getElementName() {
        return "particulier";
    }

    public String getName() {
        return name;
    }

    /**
     * Méthode permettant de s'assurer que le nom de l'utilisateur commence par une majuscule et le reste en minuscule
     * @param name est le nom de famulle du particulier
     */
    public void setName(String name) {
        this.name = StringUtil.capitalize(name);
    }

    public String getFirstName() {
        return firstName;
    }

    /**
     * Méthode permettant de s'assurer que le nom de l'utilisateur commence par une majuscule et le reste en minuscule
     * @param firstName est le prenom du particulier
     */
    public void setFirstName(String firstName) {
        this.firstName = StringUtil.capitalize(firstName);
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }
}


