package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.DesignCaterer.CatererDesignController;
import fr.uga.iut2.genevent.controller.DesignEquipment.EquipmentDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Caterer;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class CatererConsultationDataController extends ConsultationDataController<Caterer> {

    @FXML
    private Label nameLabel,emailLabel,phoneNumberLabel,menuLabel,typeLabel,roadNumberLabel,roadNameLabel,postalCodeLabel;

    public CatererConsultationDataController(Caterer caterer){
        super(caterer);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        nameLabel.setText( getConsultedObject().getCompanyName() );
        emailLabel.setText( getConsultedObject().getMail());
        phoneNumberLabel.setText( getConsultedObject().getPhone() );
        menuLabel.setText( getConsultedObject().getMenu() );
        typeLabel.setText( getConsultedObject().getCategory().name() );
        roadNumberLabel.setText( String.valueOf(getConsultedObject().getAdress().getNumeroRue()) );
        roadNameLabel.setText( getConsultedObject().getAdress().getNomRue() );
        postalCodeLabel.setText( getConsultedObject().getAdress().getCodePostal() );

    }

    @Override
    public String getFxmlPath() {
        return "/fr/uga/iut2/genevent/views/Consultation/Caterer/consultationCaterer.fxml";
    }

    @Override
    protected void edit(){
        CatererDesignController controller = new CatererDesignController(getConsultedObject());
        RootController.getPageManager().stepForward(
                new Page("Modification d'un traiteur", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }
}
