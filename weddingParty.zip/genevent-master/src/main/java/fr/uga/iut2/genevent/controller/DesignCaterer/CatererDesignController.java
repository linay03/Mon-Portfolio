package fr.uga.iut2.genevent.controller.DesignCaterer;

import fr.uga.iut2.genevent.controller.DesignController;
import fr.uga.iut2.genevent.controller.DesignIndividual.IndividualDataController;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Adresse;
import fr.uga.iut2.genevent.model.Caterer;
import fr.uga.iut2.genevent.model.CatererCategory;
import javafx.event.ActionEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class CatererDesignController extends DesignController<Caterer> {

    private CatererDataController controller = new CatererDataController();

    public CatererDesignController(){
        super("Traiteur");
    }
    public CatererDesignController(Caterer editedObject){
        super("Traiteur", editedObject);
        controller = new CatererDataController(editedObject);
    }
    public CatererDesignController(Selector<Caterer> selector){
        super(selector, "Traiteur");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        initializeCenter("/fr/uga/iut2/genevent/views/Design/DesignCaterer/designCaterer.fxml", controller);
    }

    @Override
    protected void save(ActionEvent event){
        resetValidity();
        if (!checkValidity()){
            return;
        }

        String name = controller.getName();
        String email = controller.getEmail();
        String phone = controller.getPhone();
        String menu = controller.getMenu();
        Adresse adresse = controller.getAdresse();
        CatererCategory catererCategory = controller.getCategory();

        if(isEditMod()){
            getEditedObject().setCompanyName(name);
            getEditedObject().setMail(email);
            getEditedObject().setPhone(phone);
            getEditedObject().setMenu(menu);
            getEditedObject().setAdress(adresse);
            getEditedObject().setCategory(catererCategory);

            RootController.logInfo("Modification d'un traiteur");
            RootController.getPageManager().backtrack();
            RootController.getPageManager().backtrack();
        }else{
            Caterer newCaterer = new Caterer(name, menu,catererCategory,phone,adresse,email);
            setNewObject(newCaterer);//L'object crée est passé a super() pour être assigné au selector lors d'une sélection

            RootController.getGenevent().newCaterer(newCaterer);

            RootController.logInfo("Création d'un traiteur");
            RootController.getPageManager().backtrack();
        }
    }

    /**
     * Cette fonction permet de vérifier que tout les field sont replis et replis corréctement
     * @return
     */
    private boolean checkValidity(){
        boolean isValid = true;

        if (controller.getName().isBlank()){
            isValid = false;
            controller.setNameInvalid(true, "Le nom doit être renseigné");
        }
        if(controller.getEmail().isBlank()){
            isValid = false;
            controller.setEmailInvalid(true, "L'email doit être renseigné");
        }else if (!controller.getEmail().contains("@")){
            //si l'adresse mail ne contien pas de @
            isValid = false;
            controller.setEmailInvalid(true, "L'email doit être au bon format");
        }
        if (controller.getPhone().isBlank()){
            isValid = false;
            controller.setPhoneInvalid(true, "Le numero de téléphone doit être renseigné");
        }else if (!controller.getPhone().matches("[0-9\\s]+")){
            //si le numéro de téléhpone ne contien pas uniquement des chiffre et des espace
            isValid = false;
            controller.setPhoneInvalid(true, "Le numéro de téléphone doit être au bon format");
        }
        if (controller.getMenu().isBlank()){
            isValid = false;
            controller.setMenuInvalid(true, "Le menu doit être renseigné");
        }
        if (controller.getCategory() == null){
            isValid = false;
            controller.setCategoryInvalid(true, "La catégorie doit être renseigné");
        }
        if (controller.getRoadNumber().isBlank()){
            isValid = false;
            controller.setRoadNumberInvalid(true, "Le numero de rue doit être renseigné");
        }
        if (controller.getRoadName().isBlank()){
            isValid = false;
            controller.setRoadNameInvalid(true, "Le nom de rue doit être renseigné");
        }
        if (controller.getPostalCode().isBlank()){
            isValid = false;
            controller.setPostalCodeInvalid(true, "Le code postal doit être renseigné");
        }else if (controller.getPostalCode().length() != 5 || controller.getPostalCode().length() != 5 && !controller.getPostalCode().matches("\\d+")){
            //si le code postal ne fait pas exatement 5 de long ou si le code postal ne fait pas exatement 5 de long et contien d'autre carractère que des chiffre
            isValid = false;
            controller.setPostalCodeInvalid(true, "le code postal doit être être valide(5 chiffre uniquement)");
        }
        return isValid;
    }

    /**
     * cette fonction permet de restet le style de tout les champs a remplir.
     * Cette fonction toujours appeler avant checkValidity
     */
    private void resetValidity(){
        controller.setNameInvalid(false, null);
        controller.setEmailInvalid(false, null);
        controller.setPhoneInvalid(false, null);
        controller.setMenuInvalid(false, null);
        controller.setCategoryInvalid(false, null);
        controller.setRoadNumberInvalid(false, null);
        controller.setRoadNameInvalid(false, null);
        controller.setPostalCodeInvalid(false, null);
    }
}
