package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;

public interface DirectoryItem<T> {

    /**
     * Utilisé dans DirectoryItemController pour afficher les directoryItems et selectionItems
     * @return Un objet ItemFieldInfo contenant toutes les informations de tailles des colonnes (somme=70) et leur valeur
     */
    public ItemFieldInfos getItemFieldInfo();

    /**
     * Utilisé par DirectoryItemController/ConsultationController pour afficher la page de consultation correspondante à l'objet
     * @return Une instance [Objet]ConsultationDataController avec comme paramètre l'object à inspecter (this)
     */
    public ConsultationDataController<T> getConsultationDataController();

    /**
     * Utilisé pour afficher le nom de la page lors de la consultation
     * @return Le nom de l'élement au singulier, en minuscule
     */
    public String getElementName();
}
