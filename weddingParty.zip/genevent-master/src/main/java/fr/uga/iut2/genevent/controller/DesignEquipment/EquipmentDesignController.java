package fr.uga.iut2.genevent.controller.DesignEquipment;

import fr.uga.iut2.genevent.controller.DesignController;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Equipment;
import fr.uga.iut2.genevent.model.CategorieMateriel;
import fr.uga.iut2.genevent.model.Supplier;
import javafx.event.ActionEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class EquipmentDesignController extends DesignController<Equipment> {


    private EquipmentDataController controller = new EquipmentDataController();

    public EquipmentDesignController(){
        super("Matériel");
    }
    public EquipmentDesignController(Equipment editedObject){
        super("Matériel", editedObject);
        controller = new EquipmentDataController(editedObject);
    }
    public EquipmentDesignController(Selector<Equipment> selector){
        super(selector, "Matériel");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initializeCenter("/fr/uga/iut2/genevent/views/Design/DesignEquipment/designEquipment.fxml", controller);
    }

    @Override
    protected void save(ActionEvent event) {
        resetValidity();
        if (!checkValidity()){
            return;
        }

        String name = controller.getName();
        String description = controller.getDescription();
        float price = Float.parseFloat(controller.getPrice());
        int stock = Integer.parseInt(controller.getStock());
        CategorieMateriel category = controller.getCategory();
        Supplier supplier = controller.getSupplier();

        if(isEditMod()){
            getEditedObject().setName(name);
            getEditedObject().setDescription(description);
            getEditedObject().setTotalStock(stock);
            getEditedObject().setCategoryEquipment(category);
            getEditedObject().setSupplier(supplier);

            RootController.logInfo("Modification d'un materiel");
            RootController.getPageManager().backtrack();
            RootController.getPageManager().backtrack();
        }
        else{
            Equipment newEquipment = new Equipment(name, description, price, stock, category, supplier);
            setNewObject(newEquipment); //L'objet créé est passé à super() pour être assigné au Selector lors d'un selection.

            RootController.getGenevent().newEquipment(newEquipment);

            RootController.logInfo("Création d'un nouveau materiel");
            RootController.getPageManager().backtrack();
        }
    }

    @Override
    public void backtrackedTo() {
        controller.updateLabels();
    }

    /**
     * Cette fonction permet de vérifier que tout les field sont replis et replis corréctement
     * @return
     */
    private boolean checkValidity(){
        boolean isValid = true;
        if (controller.getName().isBlank()){
            isValid = false;
            controller.setNameInvalid(true, "Le nom doit être renseigné");
        }
        if (controller.getCategory().name().isBlank()){
            isValid = false;
            controller.setCategoryInvalid(true, "La catégorie doit être renseigné");
        }
        if (controller.getPrice().isBlank()){
            isValid = false;
            controller.setPriceInvalid(true, "Le prix doit être renseigné");
        }else {
            try {
                Float.parseFloat(controller.getPrice());
            } catch (NumberFormatException e) {
                //si le prix n'est pas un numéro valide
                isValid = false;
                controller.setPriceInvalid(true, "Le prix doit être au bon format (point pour séparer)");
            }
        }
        if (controller.getDescription().isBlank()){
            isValid = false;
            controller.setDescriptionInvalid(true, "La description doit être renseigné");
        }
        if (controller.getStock().isBlank()){
            isValid = false;
            controller.setStockInvalid(true, "Le stock doit être renseigné");
        }else{
            try{
                Integer.parseInt(controller.getStock());
            }catch(NumberFormatException e){
                isValid = false;
                controller.setStockInvalid(true, "Le stock doit etre un nombre valide");
            }
        }
        if (controller.getSupplier() == null){
            isValid = false;
            controller.setSupplierInvalid(true);
        }
        return isValid;
    }
    /**
     * cette fonction permet de restet le style de tout les champs a remplir.
     * Cette fonction toujours appeler avant checkValidity
     */
    private void resetValidity(){
        controller.setNameInvalid(false, null);
        controller.setCategoryInvalid(false, null);
        controller.setPriceInvalid(false, null);
        controller.setDescriptionInvalid(false, null);
        controller.setStockInvalid(false, null);
        controller.setSupplierInvalid(false);
    }
}
