package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.model.conflicts.WeddingCatererTimingConflict;
import fr.uga.iut2.genevent.model.conflicts.WeddingEquipmentStockConflict;
import fr.uga.iut2.genevent.model.conflicts.WeddingLocationCapacityConflict;
import fr.uga.iut2.genevent.model.conflicts.WeddingLocationTimingConflict;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.*;


public class GenEvent implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    
    private final Set<Wedding> weddings = new HashSet<>();
    private final Set<Location> locations = new HashSet<>();
    private final Set<Caterer> caterers = new HashSet<>();
    private final Set<Individual> individuals = new HashSet<>();  // association qualifiée par l'email
    private final Set<Owner> owners = new HashSet<>();
    private final Set<Supplier> suppliers = new HashSet<>();
    private final Set<Equipment> equipments = new HashSet<>();

    //Conflits
    private final Set<WeddingCatererTimingConflict> weddingCatererTimingConflicts = new HashSet<>();

    private final Set<WeddingEquipmentStockConflict> weddingEquipmentStockConflicts = new HashSet<>();

    private final Set<WeddingLocationCapacityConflict> weddingLocationCapacityConflicts = new HashSet<>();

    private final Set<WeddingLocationTimingConflict> weddingLocationTimingConflicts = new HashSet<>();

    //region getters
    public Set<Wedding> getWeddings() {
        return this.weddings;
    }
    public Set<Location> getLocations() {
        return locations;
    }
    public Set<Caterer> getCaterers() {
        return caterers;
    }
    public Set<Individual> getIndividuals() {
        return individuals;
    }
    public Set<Owner> getOwners() {
        return owners;
    }
    public Set<Supplier> getSuppliers() {
        return suppliers;
    }
    public Set<Equipment> getEquipments() {
        return equipments;
    }
    //endregion
    
    public void newWedding(Wedding wedding) {
        weddings.add(wedding);
    }
    public void newIndividual(Individual individual) {
        individuals.add(individual);
    }

    public void newLocation(Location location){locations.add(location); }

    public void newOwner(Owner owner){owners.add(owner); }
    public void newSupplier(Supplier supplier){
        suppliers.add(supplier);
    }
    public void newEquipment(Equipment equipment){
        equipments.add(equipment);
    }

    public void newCaterer(Caterer caterer){
        caterers.add(caterer);
    }

}
