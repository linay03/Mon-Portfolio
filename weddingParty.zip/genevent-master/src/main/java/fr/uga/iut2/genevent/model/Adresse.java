package fr.uga.iut2.genevent.model;

import java.io.Serializable;

/**
 * Cette classe représente une adresse avec les différents éléments caractérisitques :
 * numero de rue
 * nom de la rue
 * code postal
 */
public class Adresse implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    String numeroRue;

    String nomRue;

    String codePostal; // 5 CHIFFRES  CONTRAINTE

    /**
     * Constructeur de la classe Adresse
     * @param numeroRue le numero de la rue (ex : 123 , 123 bis)
     * @param nomRue le nom de la rue (ex : rue des paquerettes)
     * @param codePostal le code postal (ex : 38000)
     */
    public Adresse(String numeroRue, String nomRue, String codePostal){
        setNumeroRue(numeroRue);;
        setNomRue(nomRue);
        setCodePostal(codePostal);
    }

    public Adresse(Adresse adresse){ // Constructeur qui n'a pas besoin de verifications car
        // l'adresse rentrée en param aura déjà dû les resepcter
        setNumeroRue(adresse.getNumeroRue());
        setNomRue(adresse.getNomRue());
        setCodePostal(adresse.codePostal);
    }

    /**
     * Permet de définir le numero de rue de cette adresse
     * @param numRue le nouveau numero de rue de cette adresse
     */
    public void setNumeroRue(String numRue) {
        if (numRue == null){
            this.numeroRue = null;
        } else {
        this.numeroRue = numRue;}
    }

    /**
     * Permet de définir le nom de la rue de cette adresse
     * Le nom de la rue à la contrainte d'etre en minuscule
     * @param nomRue le nouveau nom de la rue de cette adresse
     */
    public void setNomRue(String nomRue)  {
        if (nomRue == null){
            this.numeroRue = null;
        } else {
            this.nomRue = nomRue.toLowerCase();
        }
    }


    /**
     * Permet de définir le code postal de la rue de cette adresse
     * Le code postal a la contrainte d'etre de longueur 5
     * @param codePostal est la code postal de l'adresse
     */
    public void setCodePostal(String codePostal) {
        if (codePostal == null){
            this.codePostal = null;
        } else {
            if(codePostal.trim().length()==5){
                this.codePostal = codePostal;
            } else {
                throw new IllegalArgumentException();
            }
        }
    }

    public String getNumeroRue() {
        return numeroRue;
    }

    public String getNomRue() {
        return nomRue;
    }

    public String getCodePostal() {
        return codePostal;
    }


    /**
     * Comparateur entre 2 adresses de type Adresse.
     * Permet de savoir si elles sont égales ou non, c'est à dire que leurs attributs sont les mêmes
     * @param adr est une adresse de type Adresse
     * @return true si les deux adresses sont égales, faux sinon.
     */
    public boolean equals(Adresse adr){
        return adr!=null && this.numeroRue.equals(adr.getNumeroRue()) && this.nomRue.equals(adr.getNomRue()) && this.codePostal.equals(adr.getCodePostal());
    }

    /**
     * Permet d'avoir l'affichgage en String de l'adresse actuelle
     * @return une chaine de caractères contenant les différents attributs de l'adresse actuelle.
     */
    @Override
    public String toString() {
        return numeroRue+" "+nomRue+" "+ codePostal;
    }
}
