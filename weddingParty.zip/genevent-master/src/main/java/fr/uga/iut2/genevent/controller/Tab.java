package fr.uga.iut2.genevent.controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;

import java.io.IOException;

public class Tab {

    private String name;
    private Object controller;
    private Parent root;
    private Label header;
    public Object getController() {
        return controller;
    }
    public void setController(Object controller) {
        this.controller = controller;
    }
    public Label getHeader() {
        return header;
    }
    public void setHeader(Label header) {
        this.header = header;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Parent getRoot() {
        return root;
    }
    public void setRoot(Parent root) {
        this.root = root;
    }

    public Tab(String name, String fxmlPath, Object controller, Label header){

        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        loader.setController(controller);
        try{
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.name = name;
        this.header = header;
    }

}
