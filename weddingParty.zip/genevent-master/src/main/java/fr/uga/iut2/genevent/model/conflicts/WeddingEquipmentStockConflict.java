package fr.uga.iut2.genevent.model.conflicts;

import fr.uga.iut2.genevent.model.Equipment;
import fr.uga.iut2.genevent.model.Wedding;

import java.io.Serializable;

public class WeddingEquipmentStockConflict extends Conflict implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private Equipment equipment;

    public WeddingEquipmentStockConflict(Wedding wedding,Equipment equipment){
        super(wedding);
        this.equipment = equipment;
    }

    @Override
    public String conflictMessage() {
        return "ATTENTION : le stock demandé n'est pas disponible";
    }
}
