package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.DesignOwner.OwnerDesignController;
import fr.uga.iut2.genevent.controller.SelectionItems.SelectionItemController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Owner;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class OwnerSelectionController extends SelectionController<Owner>{
	
	private ArrayList<Owner> unavailable;
	
	public OwnerSelectionController(Selector<Owner> selectorObject, ArrayList<Owner> unavailable){
		//Le selecteur où iras l'individus selectionné.
		super( selectorObject );
		this.unavailable = unavailable;
	}
	
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		initialiseNames("Propriétaires", "propriétaire");
		initItems();
	}
	
	@Override
	protected void initItems() {
		for( Owner owner : RootController.getGenevent().getOwners()){
			
			Pane ownerItem;
			
			try{
				//Charge l'item et le relie à l'élement
				SelectionItemController<Owner> controller = new SelectionItemController<>(owner, getSelectorObject());
				FXMLLoader ownerItemLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/selectionItem.fxml"));
				ownerItemLoader.setController(controller);
				ownerItem = ownerItemLoader.load();
			}
			catch (IOException e){
				ownerItem = new Pane(new Label(e.getMessage()));
				throw new RuntimeException(e);
			}
			//Assure que la taille de l'item prennent toute la fenêtre
			ownerItem.setMinWidth(super.getContent().getWidth());
			ownerItem.minWidthProperty().bind(super.getScrollPane().widthProperty());
			
			if(unavailable.contains(owner)){
				ownerItem.setDisable(true);
			}
			
			//Ajoute l'item
			super.getContent().getChildren().add(ownerItem);
		}
	}
	
	@Override
	protected void createNew(ActionEvent event) {
		OwnerDesignController controller = new OwnerDesignController(getSelectorObject());
		RootController.getPageManager().stepForward(
				new Page("Création d'un propriétaire", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
						controller, true)
		);
	}
}
