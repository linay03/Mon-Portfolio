package fr.uga.iut2.genevent.model.conflicts;

import fr.uga.iut2.genevent.model.Wedding;

import java.io.Serializable;

/**
 * Classe qui représente la notion de Conflit.
 * Les objets de type conflit sont utilisés lors de la création du mariage.
 * Ils sont créés lorsque des conflits sont détectés.
 * Le conflit possède le mariage conscerné.
 */
public abstract class Conflict implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private Wedding wedding;


    Conflict(Wedding wedding){
        this.wedding = wedding;
    }

    public abstract String conflictMessage();


}
