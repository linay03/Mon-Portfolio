package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.DesignSupplier.SupplierDesignController;
import fr.uga.iut2.genevent.controller.SelectionItems.SelectionItemController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Supplier;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SupplierSelectionController extends SelectionController<Supplier>{

    private final ArrayList<Supplier> unavailable;

    public SupplierSelectionController(Selector<Supplier> selectorObject, ArrayList<Supplier> unavailable){
        //Le selecteur où iras l'individus selectionné.
        super(selectorObject);
        this.unavailable = unavailable;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initialiseNames("Fournisseurs", "fournisseur");
        initItems();
    }

    @Override
    protected void initItems() {
        for( Supplier supplier : RootController.getGenevent().getSuppliers() ){

            Pane supplierItem;

            try {
                SelectionItemController<Supplier> controller = new SelectionItemController<>(supplier, getSelectorObject());
                FXMLLoader individualItemLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/selectionItem.fxml"));
                individualItemLoader.setController(controller);
                supplierItem = individualItemLoader.load();

            } catch (IOException e) {
                supplierItem = new Pane(new Label(e.getMessage()));
                throw new RuntimeException(e);
            }

            supplierItem.setMinWidth(super.getContent().getWidth());
            supplierItem.minWidthProperty().bind(super.getScrollPane().widthProperty());

            if(unavailable.contains(supplier)){
                supplierItem.setDisable(true);
            }

            super.getContent().getChildren().add(supplierItem);
        }
    }

    @Override
    protected void createNew(ActionEvent event) {
        SupplierDesignController controller = new SupplierDesignController(getSelectorObject());
        RootController.getPageManager().stepForward(
                new Page("Création d'un fournisseur", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller,true)
        );
    }
}
