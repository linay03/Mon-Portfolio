package fr.uga.iut2.genevent.controller.DesignWedding;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class EquipmentHeaderItemController implements Initializable {

    @FXML
    Label headerNameLable;

    private String headerName;

    EquipmentHeaderItemController(String headerName){
        this.headerName = headerName;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        headerNameLable.setText(headerName);
    }
}
