package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.Selectors.Selector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.io.IOException;

public abstract class DesignController<T> implements Initializable, PageController {
	
	@FXML
	private BorderPane borderPane;
	@FXML
	private Button create;
	@FXML
	private Label titleLabel;

	private boolean isEditMod;
	private T editedObject; //L'object modifié lors d'une modification
	private Selector<T> selectorNewObject;
	private String title;

	public boolean isEditMod() {
		return isEditMod;
	}
	protected void setNewObject(T newObject){
		if(selectorNewObject != null){
			this.selectorNewObject.setObject(newObject);
		}
	}

	public T getEditedObject() {
		return editedObject;
	}

	public DesignController(String title){
		this(title, null);
	}
	public DesignController(String title, T editedObject){
		this(null, title, editedObject);
	}
	public DesignController(Selector<T> selectorNewObject, String title){
		this(selectorNewObject, title, null);
	}
	private DesignController(Selector<T> selectorNewObject, String title, T editedObject){
		this.selectorNewObject = selectorNewObject;
		this.isEditMod = editedObject != null;
		this.editedObject = editedObject;
		this.title = title;
	}
	
	protected void initializeCenter(String fxmlPath, Object controller){
		titleLabel.setText(title);

		try{
			FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
			loader.setController(controller);
			borderPane.setCenter(loader.load());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	@FXML
	private void cancel(ActionEvent event){
		RootController.getPageManager().backtrack();
	}
	
	@FXML
	protected abstract void save(ActionEvent event);
	
	@Override
	public void backtrackedTo() {}
}
