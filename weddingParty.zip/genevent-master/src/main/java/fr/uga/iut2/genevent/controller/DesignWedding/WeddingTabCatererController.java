package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.controller.CatererSelectionController;
import fr.uga.iut2.genevent.controller.LocationSelectionController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Caterer;
import fr.uga.iut2.genevent.model.Wedding;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ResourceBundle;

public class WeddingTabCatererController implements Initializable {

	@FXML
	private ScrollPane scrollPane;
	@FXML
	private VBox content;

	private ArrayList<SelectedCatererItemController> catererSelectionControlers = new ArrayList<>();

	private Wedding editedWedding;

	public ArrayList<Caterer> getCaterers(){
		ArrayList<Caterer> caterers = new ArrayList<>();
		for (SelectedCatererItemController item : catererSelectionControlers){
			caterers.add( item.getCatererSelector().getObject() );
		}
		return caterers;
	}

	WeddingTabCatererController(){}
	WeddingTabCatererController(Wedding editedWedding){
		this.editedWedding = editedWedding;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		if(editedWedding != null ){

			for (Caterer caterer : editedWedding.getCaterers()){
				catererSelectionControlers.add( new SelectedCatererItemController(this, new Selector<>(caterer)) );
				updateSelectionList();
			}
			updateSelectionList();
		}
	}

	@FXML
	private void selectMore(ActionEvent event){
		Selector<Caterer> newCatererSelector = new Selector<>(null);
		catererSelectionControlers.add( new SelectedCatererItemController(this, newCatererSelector) );

		ArrayList<Caterer> unavailable = new ArrayList<>();
		for (SelectedCatererItemController itemController : catererSelectionControlers){
			unavailable.add(itemController.getCatererSelector().getObject());
		}

		//Avance vers la page de selection pour selection location. Aucun est indisponible.
		CatererSelectionController controller = new CatererSelectionController(newCatererSelector, unavailable);
		RootController.getPageManager().stepForward(
				new Page("Selection d'un traiteur", "/fr/uga/iut2/genevent/views/Base/list.fxml",
						controller, true)
		);

	}

	public void updateSelectionList(){
		//Supprime tous les éléments existant
		content.getChildren().clear();

		//Ajoute les éléments de la liste
		Iterator<SelectedCatererItemController> iterator = catererSelectionControlers.iterator();
		while (iterator.hasNext()){
			SelectedCatererItemController current = iterator.next();

			if(current.getCatererSelector().getObject() == null){
				iterator.remove();
				continue;
			}

			Pane item;
			try{
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingCatererItem.fxml"));
				loader.setController(current);
				item = loader.load();
			} catch (IOException e) {
				item = new Pane(new Label(e.getMessage()));
				throw new RuntimeException(e);
			}
			content.getChildren().add(item);
		}
	}

	//Appelé par SelectedCatererItemController.@FXML remove() (s'enlève lui-même de tab en donnant la root du fxml et le controller
	public void removeItem(GridPane gridPane, SelectedCatererItemController controller){
		content.getChildren().remove(gridPane);
		catererSelectionControlers.remove(controller);
	}
}
