package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.Selectors.Selector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.ArrayList;

public abstract class DesignTabController<T> implements Initializable, PageController{

    @FXML
    private BorderPane borderPane;  //Le pane affichant le contenu de l'onglet courant
    @FXML
    private HBox tabHeadContainer;
    @FXML
    private Button previous, next, create;

    private ArrayList<Tab> tabs;
    private int currentTabIndex;

    private boolean isEditMod;
    private T editedObject;
    private Selector<T> selectorNewObject;

    public boolean isEditMod() {
        return isEditMod;
    }

    public T getEditedObject() {
        return editedObject;
    }

    protected void setNewObject(T newObject){
        if(selectorNewObject != null){
            this.selectorNewObject.setObject(newObject);
        }
    }
    public DesignTabController(){
        this(null, null);
    }
    public DesignTabController(T editedObject){
        this(null, editedObject);
    }
    public DesignTabController(Selector<T> selectorNewObject){
        this(selectorNewObject, null);
    }
    private DesignTabController(Selector<T> selectorNewObject, T editedObject){
        this.selectorNewObject = selectorNewObject;
        this.isEditMod = editedObject != null;
        this.editedObject = editedObject;
    }

    protected ArrayList<Tab> getTabs() {
        return tabs;
    }

    protected void initilizeTabs(ArrayList<Tab> tabs){
        this.tabs = tabs;
        
        //Init le nom des tabs
        for ( Tab tab : tabs ){
            tab.getHeader().setText( tab.getName() );
        }
    
        //Montre la première tab
        setActiveTab(tabs.get(0));
    }

    @FXML
    private void nextTab(){
        if(currentTabIndex == tabs.size()-1){
            throw new IndexOutOfBoundsException("Tried to access a tab outside of bounds.");
        }
        currentTabIndex++;
        setActiveTab(tabs.get(currentTabIndex));
    }
    @FXML
    private void previousTab(){
        if(currentTabIndex == 0){
            throw new IndexOutOfBoundsException("Tried to access a tab outside of bounds.");
        }
        currentTabIndex--;
        setActiveTab(tabs.get(currentTabIndex));
    }
    
    private void updateNavigationButtons(){
        if(currentTabIndex == 0){
            previous.setDisable(true);
            next.setDisable(false);
        }
        else if(currentTabIndex == tabs.size()-1){
            next.setDisable(true);
            previous.setDisable(false);
        }
        else{
            next.setDisable(false);
            previous.setDisable(false);
        }
    }
    
    
    @FXML
    private void cancel(ActionEvent event){
        RootController.getPageManager().backtrack();
    }

    private void setActiveTab(Tab tab){
        borderPane.setCenter(tab.getRoot());
        updateNavigationButtons();
        //active le bon header de tab
        for ( Tab currentTab : tabs ){
            currentTab.getHeader().setDisable(true);
        }
        tab.getHeader().setDisable(false);
    }
    
    @FXML
    protected abstract void save(ActionEvent event);
}
