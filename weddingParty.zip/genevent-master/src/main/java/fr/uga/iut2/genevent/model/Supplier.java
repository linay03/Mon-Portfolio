package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.ConsultationController.SupplierConsultationDataController;
import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.util.StringUtil;

import java.io.Serializable;

/**
 * Classe qui représente la notion de Supplier (fournisseur).
 * Il hérite de la classe Person.
 */
public class Supplier extends Person implements Serializable, DirectoryItem<Supplier> {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private String name;

    public Supplier(String name,String phone, Adresse adress, String mail) {
        super(phone, adress, mail);
        setName(name);
    }

    //Implémentation de directoryItem
    @Override
    public ItemFieldInfos getItemFieldInfo() {
        return new ItemFieldInfos(20, 30, 20, 0,
                getName(), getMail(), getPhone(), "");
    }
    @Override
    public ConsultationDataController<Supplier> getConsultationDataController() {
        return new SupplierConsultationDataController(this);
    }
    @Override
    public String getElementName() {
        return "fournisseur";
    }

    //Getters & Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = StringUtil.capitalize(name);
    }
}
