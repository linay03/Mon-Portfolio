package fr.uga.iut2.genevent.controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;

public class Page {
	
	private String name;
	private Parent root;
	private boolean isLeadingDisabled;
	private PageController controller;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Parent getRoot() {
		return root;
	}
	public void setRoot(Parent root) {
		this.root = root;
	}
	public boolean isLeadingDisabled() {
		return isLeadingDisabled;
	}
	public void setLeadingDisabled(boolean leadingDisabled) {
		isLeadingDisabled = leadingDisabled;
	}
	
	public Page(String name, String fxmlPath, PageController controller, boolean isLeadingDisabled){

		FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
		loader.setController(controller);
		try{
			root = loader.load();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		this.name = name;
		this.isLeadingDisabled = isLeadingDisabled;
		this.controller = controller;
	}
	
	public void backtrackedTo(){
		controller.backtrackedTo();
	}
}
