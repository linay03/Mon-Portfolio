package fr.uga.iut2.genevent.util;

public class StringUtil {
    public static String capitalize(String chaine) {
        if(chaine.isEmpty()){
            return null;
        }

        String majChaine = chaine.toUpperCase().trim();
        char lettre1 = majChaine.charAt(0);
        String newChaine = majChaine.substring(1).toLowerCase();
        return lettre1+newChaine;
    }

}
