package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.DesignSupplier.SupplierDesignController;
import fr.uga.iut2.genevent.controller.DesignWedding.WeddingDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Caterer;
import fr.uga.iut2.genevent.model.EquipmentOrder;
import fr.uga.iut2.genevent.model.Location;
import fr.uga.iut2.genevent.model.Wedding;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

public class WeddingConsultationDataController extends ConsultationDataController<Wedding> {


    @FXML
    private Label GroomAFirstNameLabel,GroomANameLabel,GroomAPhoneLabel,GroomBFirstNameLabel,GroomBNameLabel,GroomBPhoneLabel,clientFirstNameLabel,clientNameLabel,clientPhoneLabel,
            dateDebutLabel,dateFinLabel,guestNbLabel,detailLabel;
    @FXML
    private VBox locationContent, catererContent, equipmentContent;
    public WeddingConsultationDataController(Wedding wedding) {
        super(wedding);
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    @Override
    public String getFxmlPath() {
        return "/fr/uga/iut2/genevent/views/Consultation/Wedding/consultationWedding.fxml";
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Wedding wedding = getConsultedObject();
        GroomAFirstNameLabel.setText(wedding.getGroomA().getFirstName());
        GroomANameLabel.setText(wedding.getGroomA().getName());
        GroomAPhoneLabel.setText(wedding.getGroomA().getPhone());
        GroomBFirstNameLabel.setText(wedding.getGroomB().getFirstName());
        GroomBNameLabel.setText(wedding.getGroomB().getName());
        GroomBPhoneLabel.setText(wedding.getGroomB().getPhone());
        clientFirstNameLabel.setText(wedding.getClient().getFirstName());
        clientNameLabel.setText(wedding.getClient().getName());
        clientPhoneLabel.setText(wedding.getClient().getPhone());

        Date startDate = wedding.getDateInterval().getStartDate();
        Date endDate = wedding.getDateInterval().getEndDate();
        dateDebutLabel.setText( dateFormat.format( startDate ) );
        dateFinLabel.setText( dateFormat.format( endDate ) );

        guestNbLabel.setText(String.valueOf(wedding.getGuestNb()));
        detailLabel.setText(wedding.getDetails());

        //Rempli les scrollPane
        locationContent.getChildren().clear();
        for (Location location : wedding.getLocations()){
            locationContent.getChildren().add( new Label( location.getName() ) );
        }
        catererContent.getChildren().clear();
        for (Caterer caterer : wedding.getCaterers()){
            catererContent.getChildren().add( new Label( caterer.getCompanyName() ) );
        }
        equipmentContent.getChildren().clear();
        for (EquipmentOrder equipmentOrder : wedding.getEquipmentOrders()){
            equipmentContent.getChildren().add( new Label( equipmentOrder.getEquipment().getName() + ", " + equipmentOrder.getAmount() ) );
        }
    }

    @Override
    protected void edit(){
        WeddingDesignController controller = new WeddingDesignController(getConsultedObject());
        RootController.getPageManager().stepForward(
                new Page("Modification d'un mariage", "/fr/uga/iut2/genevent/views/Design/DesignWedding/designWedding.fxml",
                        controller, true)
        );
    }
}
