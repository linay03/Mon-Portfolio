package fr.uga.iut2.genevent.controller;

public class ItemFieldInfos {

    int field1Size, field2Size, field3Size, field4Size;
    String field1Value, field2Value, field3Value, field4Value;

    public ItemFieldInfos(int field1Size, int field2Size, int field3Size, int field4Size,
                          String field1Value, String field2Value, String field3Value, String field4Value) {
        this.field1Size = field1Size;
        this.field2Size = field2Size;
        this.field3Size = field3Size;
        this.field4Size = field4Size;
        this.field1Value = field1Value;
        this.field2Value = field2Value;
        this.field3Value = field3Value;
        this.field4Value = field4Value;
    }

    public int getField1Size() {
        return field1Size;
    }
    public int getField2Size() {
        return field2Size;
    }
    public int getField3Size() {
        return field3Size;
    }
    public int getField4Size() {
        return field4Size;
    }
    public String getField1Value() {
        return field1Value;
    }
    public String getField2Value() {
        return field2Value;
    }
    public String getField3Value() {
        return field3Value;
    }
    public String getField4Value() {
        return field4Value;
    }
}
