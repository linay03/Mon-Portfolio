package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Location;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class SelectedLocationItemController implements Initializable {

    @FXML
    private GridPane gridPane;

    @FXML
    private Label nameLabel,adressLabel,capacityLabel;

    private WeddingTabDateLocationController tabController;
    private Selector<Location> locationSelector;

    public Selector<Location> getLocationSelector() {
        return locationSelector;
    }

    SelectedLocationItemController(WeddingTabDateLocationController tabController, Selector<Location> locationSelector){
        this.tabController = tabController;
        this.locationSelector = locationSelector;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if(locationSelector.getObject() != null){
            nameLabel.setText(locationSelector.getObject().getName());
            adressLabel.setText(locationSelector.getObject().getAdress().toString());
            capacityLabel.setText(String.valueOf(locationSelector.getObject().getCapacity()));
        }
        else{
            nameLabel.setText("Error, locationSelector.getObject() is null");
        }
    }

    @FXML
    private void remove(ActionEvent event){
        tabController.removeItem(gridPane, this);
    }
}
