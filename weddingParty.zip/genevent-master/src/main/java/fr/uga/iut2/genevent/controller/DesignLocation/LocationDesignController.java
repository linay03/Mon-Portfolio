package fr.uga.iut2.genevent.controller.DesignLocation;

import fr.uga.iut2.genevent.controller.DesignTabController;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.controller.Tab;
import fr.uga.iut2.genevent.exceptions.AdresseInvalideException;
import fr.uga.iut2.genevent.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class LocationDesignController extends DesignTabController<Location> {

    @FXML
    private Label tabHeader1, tabHeader2, tabHeader3;

    private LocationTabInfosController infosTabController = new LocationTabInfosController();
    private LocationTabUnavailabilityController unavailabilityTabController = new LocationTabUnavailabilityController();
    private LocationTabSpecificationController specificationTabController = new LocationTabSpecificationController();

    public LocationDesignController() {
        super();
    }
    public LocationDesignController(Location editedObject){
        super(editedObject);
        infosTabController = new LocationTabInfosController(editedObject);
        unavailabilityTabController = new LocationTabUnavailabilityController(editedObject);
        specificationTabController = new LocationTabSpecificationController(editedObject);
    }
    public LocationDesignController(Selector<Location> selectorNewObject) {
        super(selectorNewObject);
    }

    public LocationTabInfosController getInfosTabController() {
        return infosTabController;
    }
    public LocationTabUnavailabilityController getUnavailabilityTabController() {
        return unavailabilityTabController;
    }
    public LocationTabSpecificationController getSpecificationTabController() {
        return specificationTabController;
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Donne les tabs utilisé pour la création d'un lieu à DesignTabController
        initilizeTabs(
                new ArrayList<>(Arrays.asList(
                        new Tab("Informations Générales", "/fr/uga/iut2/genevent/views/Design/DesignLocation/designLocationDetails.fxml",
                                infosTabController, tabHeader1),
                        new Tab("Indisponibilités", "/fr/uga/iut2/genevent/views/Design/DesignLocation/designLocationUnavailablility.fxml",
                                unavailabilityTabController, tabHeader2),
                        new Tab("Spécifications", "/fr/uga/iut2/genevent/views/Design/DesignLocation/designLocationSpecification.fxml",
                                specificationTabController, tabHeader3)
                ))
        );
    }

    @Override
    protected void save(ActionEvent event) {
        resetValidity();
        if (!checkValidity()){
            return;
        }
        String name = infosTabController.getName();
        Adresse adresse = infosTabController.getAdresse();
        int capacity = infosTabController.getCapacity();
        float surface = Float.parseFloat(infosTabController.getSurface());
        Owner owner = infosTabController.getOwner();
        Float price = Float.parseFloat(infosTabController.getPrice());
        ArrayList<DateInterval> unavailability = unavailabilityTabController.getUnavailabilities();
        InteriorExterior interiorExterior = specificationTabController.getInteriorExterior();
        String specifications = specificationTabController.getSpecifications();

        if(isEditMod()){
            getEditedObject().setName(name);
            try{
                getEditedObject().setAdress(adresse);
            } catch (AdresseInvalideException e) {
                throw new RuntimeException(e);
            }
            getEditedObject().setCapacity(capacity);
            getEditedObject().setSurface(surface);
            getEditedObject().setOwner(owner);
            getEditedObject().setPrice(price);
            getEditedObject().setUnavailability(unavailability);
            getEditedObject().setInteriorExterior(interiorExterior);
            getEditedObject().setDetails(specifications);

            RootController.logInfo("Modification d'un lieu");
            RootController.getPageManager().backtrack();
            RootController.getPageManager().backtrack();
        }
        else{
            try {
                Location newLocation = new Location(name, adresse, capacity, surface, owner, price, interiorExterior, specifications, unavailability);
                setNewObject(newLocation); //L'objet créé est passé à super() pour être assigné au Selector lors d'un selection.

                RootController.getGenevent().newLocation(newLocation);

                RootController.logInfo("Création d'un nouveau lieu");
                RootController.getPageManager().backtrack();
            }catch (AdresseInvalideException e){
                infosTabController.setRoadNumberInvalid(true, "Cette adresse existe déjà");
                infosTabController.setRoadNameInvalid(true, "Cette adresse existe déjà");
                infosTabController.setPostalCodeInvalid(true, "Cette adresse existe déjà");
            }
        }
    }

    @Override
    public void backtrackedTo() {
        infosTabController.updateLabels();
    }
    /**
     * Cette fonction permet de vérifier que tout les field sont replis et replis corréctement
     * @return
     */
    private boolean checkValidity(){
        boolean isValid = true;
        if (infosTabController.getName().isBlank()){
            isValid = false;
            infosTabController.setNameInvalid(true, "Le nom doit être renseigné");
            setTabInvalid(tabHeader1);
        }
        if (infosTabController.getRoadNumber().isBlank()){
            isValid = false;
            infosTabController.setRoadNumberInvalid(true, "Le numéro doit être renseigné");
            setTabInvalid(tabHeader1);
        }
        if (infosTabController.getRoadName().isBlank()){
            isValid = false;
            infosTabController.setRoadNameInvalid(true, "le nom de rue doit être renseigné");
            setTabInvalid(tabHeader1);
        }
        if (infosTabController.getPostalCode().isBlank()){
            isValid = false;
            infosTabController.setPostalCodeInvalid(true, "Le code postal doit être renseigné");
            setTabInvalid(tabHeader1);
        }else if (infosTabController.getPostalCode().length() != 5 || infosTabController.getPostalCode().length() != 5  && !infosTabController.getPostalCode().matches("\\d+")){
            //si le code postal ne fait pas exatement 5 de long ou si le code postal ne fait pas exatement 5 de long et contien d'autre carractère que des chiffre
            isValid = false;
            infosTabController.setPostalCodeInvalid(true, "le code postal doit être valid (5 chiffre uniquement)");
            setTabInvalid(tabHeader1);
        }
        if(infosTabController.getPrice().isBlank()){
            isValid = false;
            infosTabController.setPriceInvalid(true, "Le prix doit être renseigné");
            setTabInvalid(tabHeader1);
        }else {
            try {
                Float.parseFloat(infosTabController.getPrice());
            } catch (NumberFormatException e) {
                //si le prix n'est pas un numéro valide
                isValid = false;
                infosTabController.setPriceInvalid(true, "Le prix doit être au bon format (point pour séparer)");
                setTabInvalid(tabHeader1);
            }
        }
        if (infosTabController.getCapacity() == 0){
            isValid = false;
            infosTabController.setCapacityInvalid(true, "La capacité doit être renseigné");
            setTabInvalid(tabHeader1);
        }
        if(infosTabController.getSurface().isBlank()){
            isValid = false;
            infosTabController.setSurfaceInvalid(true, "La surface doit être renseigné");
            setTabInvalid(tabHeader1);
        }else {
            try{
                Float.parseFloat(infosTabController.getSurface());
            }catch(NumberFormatException e){
                //si jamais la surface ne correspond pas a un numéro valide
                isValid = false;
                infosTabController.setSurfaceInvalid(true, "La surface doit être un numéro valide");
                setTabInvalid(tabHeader1);
            }
        }
        if(infosTabController.getOwner() == null){
            isValid = false;
            infosTabController.setOwnerInvalid(true);
        }else if(specificationTabController.getInteriorExterior().name().isBlank()){
            isValid = false;
            specificationTabController.setInteriorExteriorInvalid(true);
            setTabInvalid(tabHeader1);
        }
        return isValid;
    }
    /**
     * cette fonction permet de restet le style de tout les champs a remplir.
     * Cette fonction toujours appeler avant checkValidity
     */
    private void resetValidity(){
        infosTabController.setNameInvalid(false, null);
        infosTabController.setRoadNumberInvalid(false, null);
        infosTabController.setRoadNameInvalid(false, null);
        infosTabController.setPostalCodeInvalid(false, null);
        infosTabController.setPriceInvalid(false, null);
        infosTabController.setCapacityInvalid(false, null);
        infosTabController.setSurfaceInvalid(false,null);
        infosTabController.setOwnerInvalid(false);
        specificationTabController.setInteriorExteriorInvalid(false);
        setTabValid(tabHeader1);
    }

    private void setTabInvalid(Label label){
        if(!label.getStyleClass().contains("invalidTab")){
            label.getStyleClass().add("invalidTab");
        }
    }

    private void setTabValid(Label label){
        label.getStyleClass().remove("invalidTab");
    }


}
