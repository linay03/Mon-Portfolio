package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Caterer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class SelectedCatererItemController implements Initializable {

    @FXML
    private GridPane gridPane;
    @FXML
    private Label nameLabel,adressLabel,menuLabel,categoryLabel;

    private final WeddingTabCatererController tabController;
    private final Selector<Caterer> catererSelector;

    public Selector<Caterer> getCatererSelector() {
        return catererSelector;
    }

    public SelectedCatererItemController(WeddingTabCatererController tabController, Selector<Caterer> catererSelector) {
        this.tabController = tabController;
        this.catererSelector = catererSelector;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if(catererSelector.getObject() != null){
            nameLabel.setText(catererSelector.getObject().getCompanyName());
            adressLabel.setText(catererSelector.getObject().getAdress().toString());
            menuLabel.setText(catererSelector.getObject().getMenu());
            categoryLabel.setText(catererSelector.getObject().getCategory().name());
        }
        else{
            nameLabel.setText("Error, catererSelector.getObject() is null");
        }
    }

    @FXML
    private void remove(ActionEvent event){
        tabController.removeItem(gridPane, this);
    }
}
