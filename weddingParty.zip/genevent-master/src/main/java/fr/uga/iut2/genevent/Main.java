package fr.uga.iut2.genevent;

import fr.uga.iut2.genevent.controller.LeadingController;
import fr.uga.iut2.genevent.controller.PageManager;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.exceptions.AdresseInvalideException;
import fr.uga.iut2.genevent.template.controleur.Controleur;
import fr.uga.iut2.genevent.model.GenEvent;
import fr.uga.iut2.genevent.util.Persisteur;
import javafx.application.Platform;
import java.io.IOException;

public class Main {

    public static final int EXIT_ERR_LOAD = 2;
    public static final int EXIT_ERR_SAVE = 3;

    public static void main(String[] args) {
        GenEvent genevent = null;

        try {
            genevent = Persisteur.lireEtat();
        }
        catch (ClassNotFoundException | IOException ignored) {
            System.err.println("Erreur irrécupé rable pendant le chargement de l'état : fin d'exécution !");
            System.err.flush();
            System.exit(Main.EXIT_ERR_LOAD);
        }

        // `Controleur.demarrer` garde le contrôle de l'exécution tant que
        // l'utilisa·teur/trice n'a pas saisi la commande QUITTER.
        RootController.start(genevent);

        try {
            Persisteur.sauverEtat(genevent);
        }
        catch (IOException ignored) {
            System.err.println("Erreur irrécupérable pendant la sauvegarde de l'état : fin d'exécution !");
            System.err.flush();
            System.exit(Main.EXIT_ERR_SAVE);
        }

        Platform.exit();
    }
}
