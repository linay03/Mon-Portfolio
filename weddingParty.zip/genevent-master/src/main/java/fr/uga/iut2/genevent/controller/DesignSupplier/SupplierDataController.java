package fr.uga.iut2.genevent.controller.DesignSupplier;

import fr.uga.iut2.genevent.model.Adresse;
import fr.uga.iut2.genevent.model.Owner;
import fr.uga.iut2.genevent.model.Supplier;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;

import java.net.URL;
import java.util.ResourceBundle;

public class SupplierDataController implements Initializable {

    @FXML
    private TextField nameField, emailField, phoneField, roadNumberField, roadNameField, postalCodeField;

    private Supplier editedSupplier;

    SupplierDataController(){}//Constructeur vide par défaut

    //Utilisé pour spécifier l'object modifié lors de la modification (les labels doivent être mis à jour)
    SupplierDataController(Supplier editedSupplier){
        this.editedSupplier = editedSupplier;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if(editedSupplier != null){
            nameField.setText( editedSupplier.getName() );
            emailField.setText( editedSupplier.getMail() );
            phoneField.setText( editedSupplier.getPhone() );
            roadNumberField.setText( editedSupplier.getAdress().getNumeroRue() );
            roadNameField.setText( editedSupplier.getAdress().getNomRue() );
            postalCodeField.setText( editedSupplier.getAdress().getCodePostal() );
        }
    }

    public String getName(){
        return nameField.getText().trim();
    }
    public String getEmail(){
        return emailField.getText().trim();
    }
    public String getPhone(){
        return phoneField.getText().trim();
    }
    public Adresse getAdresse(){
        return new Adresse( roadNumberField.getText(), roadNameField.getText(), postalCodeField.getText() );
    }
    public String getRoadNumber(){
        return roadNumberField.getText().trim();
    }
    public String getRoadName(){
        return roadNameField.getText().trim();
    }
    public String getPostalCode(){
        return postalCodeField.getText().trim();
    }

    /**
     * si isInvalid est true on met le style invalid au fied qu'il faut remplir
     * et on ajout un message qui apparait lorsque l'on survole le field
     * @param isInvalid
     * @param message
     */
    public void setNameInvalid(boolean isInvalid, String message){
        if (isInvalid){
            nameField.setTooltip(new Tooltip(message));
            nameField.getStyleClass().add("invalid");
        }else{
            nameField.getStyleClass().remove("invalid");
        }
    }
    public void setEmailInvalid(boolean isInvalid, String message){
        if (isInvalid){
            emailField.setTooltip(new Tooltip(message));
            emailField.getStyleClass().add("invalid");
        }else{
            emailField.getStyleClass().remove("invalid");
        }
    }
    public void setPhoneInvalid(boolean isInvalid, String message){
        if (isInvalid){
            phoneField.setTooltip(new Tooltip(message));
            phoneField.getStyleClass().add("invalid");
        }else{
            phoneField.getStyleClass().remove("invalid");
        }
    }
    public void setRoadNumberInvalid(boolean isInvalid, String message){
        if (isInvalid){
            roadNumberField.setTooltip(new Tooltip(message));
            roadNumberField.getStyleClass().add("invalid");
        }else{
            roadNumberField.getStyleClass().remove("invalid");
        }
    }
    public void setRoadNameInvalid(boolean isInvalid, String message){
        if (isInvalid){
            roadNameField.setTooltip(new Tooltip(message));
            roadNameField.getStyleClass().add("invalid");
        }else{
            roadNameField.getStyleClass().remove("invalid");
        }
    }
    public void setPostalCodeInvalid(boolean isInvalid, String message){
        if (isInvalid){
            postalCodeField.setTooltip(new Tooltip(message));
            postalCodeField.getStyleClass().add("invalid");
        }else{
            postalCodeField.getStyleClass().remove("invalid");
        }
    }
}
