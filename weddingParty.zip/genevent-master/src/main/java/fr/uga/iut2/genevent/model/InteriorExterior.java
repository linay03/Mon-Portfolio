package fr.uga.iut2.genevent.model;

import java.io.Serializable;

public enum InteriorExterior implements Serializable {

    Interieur("Interieur"),
    Exterieur("Exterieur"),
    InterieurEtExterieur("Intérieur et Extérieur");

    private String label;

    InteriorExterior(String label){
        this.label=label;
    }
}

