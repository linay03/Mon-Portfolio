package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.DesignOwner.OwnerDesignController;
import fr.uga.iut2.genevent.controller.DesignWedding.WeddingDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Owner;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class OwnerConsultationDataController extends ConsultationDataController<Owner> {

    @FXML
    private Label nameLabel,prenomLabel,emailLabel,phoneNumberLabel,roadNumberLabel,roadNameLabel,postalCodeLabel;


    public OwnerConsultationDataController(Owner owner){
        super(owner);
    }

    @Override
    public String getFxmlPath() {
        return "/fr/uga/iut2/genevent/views/Consultation/Owner/consultationOwner.fxml";
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        Owner owner = getConsultedObject();
        nameLabel.setText(owner.getName());
        emailLabel.setText(owner.getMail());
        phoneNumberLabel.setText(owner.getPhone());
        roadNumberLabel.setText(String.valueOf(owner.getAdress().getNumeroRue()));
        roadNameLabel.setText(owner.getAdress().getNomRue());
        postalCodeLabel.setText(owner.getAdress().getCodePostal());
        if (owner.getFirstName() != null && !owner.getFirstName().isEmpty()){
            prenomLabel.setText(owner.getFirstName());
        }else{
            prenomLabel.setDisable(true);
            prenomLabel.setText("*(pas de prénom)");
        }
    }

    @Override
    protected void edit(){
        OwnerDesignController controller = new OwnerDesignController(getConsultedObject());
        RootController.getPageManager().stepForward(
                new Page("Modification d'un propriétaire", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }
}
