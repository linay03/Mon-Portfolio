package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.DesignOwner.OwnerDesignController;
import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Owner;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class OwnerDirectoryController extends DirectoryController {
	
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		super.initialize(url, resourceBundle);  //Rend invisible le bouton annuler
		initialiseNames("Propriétaires", "propriétaire");
		initItems();
	}
	
	@Override
	protected void initItems() {
		
		//vide tous les éléments
		getContent().getChildren().clear();
		
		for( Owner owner : RootController.getGenevent().getOwners()){
			
			Pane ownerItem;
			
			try{
				//Charge l'item et le relie à l'élement
				DirectoryItemController<Owner> controller = new DirectoryItemController<>(owner);
				FXMLLoader ownerItemLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/directoryItem.fxml"));
				ownerItemLoader.setController(controller);
				ownerItem = ownerItemLoader.load();
			}
			catch (IOException e){
				ownerItem = new Pane(new Label(e.getMessage()));
				throw new RuntimeException(e);
			}
			//Assure que la taille de l'item prennent toute la fenêtre
			ownerItem.setMinWidth(super.getContent().getWidth());
			ownerItem.minWidthProperty().bind(super.getScrollPane().widthProperty());
			
			//Ajoute l'item
			super.getContent().getChildren().add(ownerItem);
		}
	}
	
	@Override
	protected void createNew(ActionEvent event) {
		OwnerDesignController controller = new OwnerDesignController();
		RootController.getPageManager().stepForward(
				new Page("Création d'un propriétaire", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
						controller, true)
		);
	}
}
