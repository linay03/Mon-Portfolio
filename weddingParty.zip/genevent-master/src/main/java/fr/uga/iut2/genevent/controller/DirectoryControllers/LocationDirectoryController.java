package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.DesignLocation.LocationDesignController;
import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Location;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LocationDirectoryController extends DirectoryController {

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        super.initialize(url, resourceBundle);  //Rend invisible le bouton annuler
        initialiseNames("Lieux", "lieu");
        initItems();
    }
    
    @Override
    protected void initItems() {

        //vide tous les éléments
        getContent().getChildren().clear();

        for( Location location : RootController.getGenevent().getLocations()){

            Pane item;

            try{
                //Charge l'item et le relie à l'élement
                DirectoryItemController<Location> controller = new DirectoryItemController<>(location);
                FXMLLoader loader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/directoryItem.fxml"));
                loader.setController(controller);
                item = loader.load();
            }
            catch (IOException e){
                item = new Pane(new Label(e.getMessage()));
                throw new RuntimeException(e);
            }
            //Assure que la taille de l'item prennent toute la fenêtre
            item.setMinWidth(super.getContent().getWidth());
            item.minWidthProperty().bind(super.getScrollPane().widthProperty());

            //Ajoute l'item
            super.getContent().getChildren().add(item);
        }
    }
    
    @Override
    protected void createNew(ActionEvent event) {
        RootController.getPageManager().stepForward(
                new Page("Création d'un Lieu", "/fr/uga/iut2/genevent/views/Design/DesignLocation/designLocation.fxml",
                        new LocationDesignController(), true)
        );
    }
}
