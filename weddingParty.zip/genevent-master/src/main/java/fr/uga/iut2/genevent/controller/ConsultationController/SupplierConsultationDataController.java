package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.DesignIndividual.IndividualDesignController;
import fr.uga.iut2.genevent.controller.DesignSupplier.SupplierDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Supplier;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class SupplierConsultationDataController extends ConsultationDataController<Supplier> {

    @FXML
    private Label nameLabel, emailLabel, phoneNumberLabel,roadNumberLabel,roadNameLabel,postalCodeLabel;

    public SupplierConsultationDataController(Supplier supplier){
        super(supplier);
    }

    @Override
    public String getFxmlPath() {
        return "/fr/uga/iut2/genevent/views/Consultation/Supplier/consultationSupplier.fxml";
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        Supplier supplier = getConsultedObject();
        nameLabel.setText(supplier.getName());
        emailLabel.setText(supplier.getMail());
        phoneNumberLabel.setText(supplier.getPhone());
        roadNumberLabel.setText(String.valueOf(supplier.getAdress().getNumeroRue()));
        roadNameLabel.setText(supplier.getAdress().getNomRue());
        postalCodeLabel.setText(supplier.getAdress().getCodePostal());

    }

    @Override
    protected void edit(){
        SupplierDesignController controller = new SupplierDesignController(getConsultedObject());
        RootController.getPageManager().stepForward(
                new Page("Modification d'un fournisseur", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }
}
