package fr.uga.iut2.genevent.controller.DesignOwner;

import fr.uga.iut2.genevent.model.Adresse;
import fr.uga.iut2.genevent.model.Owner;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;

import java.net.URL;
import java.util.ResourceBundle;

public class OwnerDataController implements Initializable {
	
	@FXML
	private TextField nameField, firstNameField, emailField, phoneField, roadNumberField, roadNameField, postalCodeField;

	private Owner editedOwner;
	OwnerDataController(){}//Constructeur vide par défaut
	
	//Utilisé pour spécifier l'object modifié lors de la modification (les labels doivent être mis à jour)
	OwnerDataController(Owner editedOwner){
		this.editedOwner = editedOwner;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		if(editedOwner != null){
			nameField.setText( editedOwner.getName() );
			firstNameField.setText( editedOwner.getFirstName() );
			emailField.setText( editedOwner.getMail() );
			phoneField.setText( editedOwner.getPhone() );
			roadNumberField.setText( editedOwner.getAdress().getNumeroRue() );
			roadNameField.setText( editedOwner.getAdress().getNomRue() );
			postalCodeField.setText( editedOwner.getAdress().getCodePostal() );
		}
	}

	public String getLastName(){
		return nameField.getText().trim();
	}
	public String getFirstName(){
		return firstNameField.getText().trim();
	}
	public String getEmail(){
		return emailField.getText().trim();
	}
	public String getPhone(){
		return phoneField.getText().trim();
	}
	public Adresse getAdresse(){
		return new Adresse( roadNumberField.getText(), roadNameField.getText(), postalCodeField.getText() );
	}
	public String getRoadNumber(){
		return roadNumberField.getText().trim();
	}
	public String getRoadName(){
		return roadNameField.getText().trim();
	}
	public String getPostalCode(){
		return postalCodeField.getText().trim();
	}

	/**
	 * si isInvalid est true on met le style invalid au fied qu'il faut remplir
	 * et on ajout un message qui apparait lorsque l'on survole le field
	 * @param isInvalid
	 * @param message
	 */
	public void setLastNameInvalid(boolean isInvalid, String message){
		if (isInvalid){
			nameField.setTooltip(new Tooltip(message));
			nameField.getStyleClass().add("invalid");
		}else{
			nameField.getStyleClass().remove("invalid");
		}
	}
	public void setEmailInvalid(boolean isInvalid, String message){
		if (isInvalid){
			emailField.setTooltip(new Tooltip(message));
			emailField.getStyleClass().add("invalid");
		}else{
			emailField.getStyleClass().remove("invalid");
		}
	}
	public void setPhoneInvalid(boolean isInvalid, String message){
		if (isInvalid){
			phoneField.setTooltip(new Tooltip(message));
			phoneField.getStyleClass().add("invalid");
		}else{
			phoneField.getStyleClass().remove("invalid");
		}
	}
	public void setRoadNumberInvalid(boolean isInvalid, String message){
		if (isInvalid){
			roadNumberField.setTooltip(new Tooltip(message));
			roadNumberField.getStyleClass().add("invalid");
		}else{
			roadNumberField.getStyleClass().remove("invalid");
		}
	}
	public void setRoadNameInvalid(boolean isInvalid, String message){
		if (isInvalid){
			roadNameField.setTooltip(new Tooltip(message));
			roadNameField.getStyleClass().add("invalid");
		}else{
			roadNameField.getStyleClass().remove("invalid");
		}
	}
	public void setPostalCodeInvalid(boolean isInvalid, String message){
		if (isInvalid){
			postalCodeField.setTooltip(new Tooltip(message));
			postalCodeField.getStyleClass().add("invalid");
		}else{
			postalCodeField.getStyleClass().remove("invalid");
		}
	}

}
