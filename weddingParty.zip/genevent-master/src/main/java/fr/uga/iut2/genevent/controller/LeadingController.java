package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.DirectoryControllers.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class LeadingController implements Initializable {

    @FXML
    private BorderPane borderPane;
    @FXML
    private Label breadCrumbs;
    @FXML
    private Button weddingButton, locationButton, catererButton, individualButton, ownerButton, supplierButton, equipmentButton, quitButton;
    
    private ArrayList<Button> buttons;
    
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        buttons = new ArrayList<>(Arrays.asList(weddingButton, locationButton, catererButton,
                individualButton, ownerButton, supplierButton, equipmentButton, quitButton));
    }
    
    public void setBreadCrumbsText(String text){
        breadCrumbs.setText(text);
    }
    public void setDisableButtons(boolean isDisable){
        for ( Button button : buttons ){
            button.setDisable(isDisable);
        }
    }
    
    @FXML
    private void actionBtnQuitter(ActionEvent event){
        RootController.exit();
    }

    public void setActivePage(Page page){
        borderPane.setCenter(page.getRoot());
    }

    @FXML
    public void showWeddingDirectory(ActionEvent event){
        WeddingDirectoryController controller = new WeddingDirectoryController();
        RootController.getPageManager().setFirstPage(
                new Page("Mariages", "/fr/uga/iut2/genevent/views/Base/list.fxml", controller, false));
    }
    @FXML
    public void showLocationDirectory(ActionEvent event){
        LocationDirectoryController controller = new LocationDirectoryController();
        RootController.getPageManager().setFirstPage(
                new Page("Lieux", "/fr/uga/iut2/genevent/views/Base/list.fxml", controller, false));
    }
    @FXML
    public void showCatererDirectory(ActionEvent event){
        CatererDirectoryController controller = new CatererDirectoryController();
        RootController.getPageManager().setFirstPage(
                new Page("Traiteurs", "/fr/uga/iut2/genevent/views/Base/list.fxml", controller, false)
        );
    }
    @FXML
    public void showIndividualDirectory(ActionEvent event){
        IndividualDirectoryController controller = new IndividualDirectoryController();
        RootController.getPageManager().setFirstPage(
                new Page("Particuliers", "/fr/uga/iut2/genevent/views/Base/list.fxml", controller, false)
        );
    }
    @FXML
    public void showOwnerDirectory(ActionEvent event){
        OwnerDirectoryController controller = new OwnerDirectoryController();
        RootController.getPageManager().setFirstPage(
                new Page("Propriétaires", "/fr/uga/iut2/genevent/views/Base/list.fxml", controller, false)
        );
    }
    @FXML
    public void showSupplierDirectory(ActionEvent event){
        SupplierDirectoryController controller = new SupplierDirectoryController();
        RootController.getPageManager().setFirstPage(
                new Page("Fournisseurs", "/fr/uga/iut2/genevent/views/Base/list.fxml", controller, false)
        );
    }
    @FXML
    public void showEquipmentDirectory(ActionEvent event){
        EquipmentDirectoryController controller = new EquipmentDirectoryController();
        RootController.getPageManager().setFirstPage(
                new Page("Matériels", "/fr/uga/iut2/genevent/views/Base/list.fxml", controller, false)
        );
    }

}
