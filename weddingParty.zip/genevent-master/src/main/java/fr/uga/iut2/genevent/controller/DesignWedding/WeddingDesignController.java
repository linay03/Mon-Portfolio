package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.controller.DesignTabController;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.controller.Tab;
import fr.uga.iut2.genevent.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class WeddingDesignController extends DesignTabController<Wedding> {

    // ! Beaucoup de @FXML sont dans super !
    @FXML
    private Label individualTabHeader, dateLocationTabHeader, catererTabHeader, equipmentTabHeader, detailsTabHeader;
    
    private WeddingTabIndividualController individualTabController = new WeddingTabIndividualController();
    private WeddingTabDateLocationController dateLocationTabController = new WeddingTabDateLocationController();
    private WeddingTabCatererController catererTabController = new WeddingTabCatererController();
    private WeddingTabEquipementController equipementTabController = new WeddingTabEquipementController();
    private WeddingTabDetailsController detailsTabController = new WeddingTabDetailsController();

    public WeddingDesignController() {
        super();
    }
    public WeddingDesignController(Wedding editedObject){
        super(editedObject);
        individualTabController = new WeddingTabIndividualController(editedObject);
        dateLocationTabController = new WeddingTabDateLocationController(editedObject);
        catererTabController = new WeddingTabCatererController(editedObject);
        equipementTabController = new WeddingTabEquipementController(editedObject);
        detailsTabController = new WeddingTabDetailsController(editedObject);
    }
    public WeddingDesignController(Selector<Wedding> selectorNewObject) {
        super(selectorNewObject);
    }

    protected WeddingTabIndividualController getIndividualTabController() {
        return individualTabController;
    }
    protected WeddingTabDateLocationController getDateLocationTabController() {
        return dateLocationTabController;
    }
    protected WeddingTabCatererController getCatererTabController() {
        return catererTabController;
    }
    protected WeddingTabEquipementController getEquipementTabController() {
        return equipementTabController;
    }
    protected WeddingTabDetailsController getDetailsTabController() {
        return detailsTabController;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        super.initilizeTabs(
            new ArrayList<>(Arrays.asList(
                new Tab("Personnes", "/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingIndividual.fxml",
                        individualTabController, individualTabHeader),
                new Tab("Date & Lieu(x)", "/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingDateLocation.fxml",
                        dateLocationTabController, dateLocationTabHeader),
                new Tab("Traiteur(x)", "/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingCaterer.fxml",
                        catererTabController, catererTabHeader),
                new Tab("Matériel", "/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingEquipment.fxml",
                        equipementTabController, equipmentTabHeader),
                new Tab("Détails", "/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingDetail.fxml",
                        detailsTabController, detailsTabHeader)
            ))
        );
    }

    @Override
    protected void save(ActionEvent event) {
        resetValidity();
        if (!checkValidity()){
            return;
        }

        Individual client = getIndividualTabController().getClient();
        Individual groom1 = getIndividualTabController().getGroom1();
        Individual groom2 = getIndividualTabController().getGroom2();

        DateInterval dateInterval = getDateLocationTabController().getDateInterval();
        ArrayList<Location> locations = getDateLocationTabController().getLocations();

        ArrayList<Caterer> caterers = getCatererTabController().getCaterers();

        ArrayList<EquipmentItemController> equipmentControllers = getEquipementTabController().getEquipmentItemControllers();

        int guestNb = getDetailsTabController().getGuestAmount();
        String details = getDetailsTabController().getDetails();

        if(isEditMod()){
            getEditedObject().setClient(client);
            getEditedObject().setGroomA(groom1);
            getEditedObject().setGroomB(groom2);
            getEditedObject().setDateInterval(dateInterval);
            getEditedObject().setLocations(locations);
            getEditedObject().setCaterers(caterers);
            getEditedObject().setEquipments( generateEquipmentOrders(getEditedObject(), equipmentControllers) );
            getEditedObject().setGuestNb(guestNb);
            getEditedObject().setDetails(details);

            RootController.logInfo("Modification d'un mariage");
            RootController.getPageManager().backtrack();
            RootController.getPageManager().backtrack();
        }
        else{

            Wedding newWedding = new Wedding(client, groom1, groom2, dateInterval.getStartDate(), dateInterval.getEndDate(),
                    locations, caterers, guestNb, details);

            newWedding.setEquipments( generateEquipmentOrders(newWedding, equipmentControllers) );

            setNewObject(newWedding);

            RootController.getGenevent().newWedding(newWedding);
            RootController.logInfo("Création d'un nouveau mariage");

            RootController.getPageManager().backtrack();
        }
    }

    private ArrayList<EquipmentOrder> generateEquipmentOrders(Wedding wedding, ArrayList<EquipmentItemController> equipmentControllers){

        ArrayList<EquipmentOrder> equipmentOrders = new ArrayList<>();

        for (EquipmentItemController equipmentController : equipmentControllers){
            equipmentOrders.add(
                    new EquipmentOrder(equipmentController.getEquipment(), equipmentController.getAmount(), wedding)
            );
        }
        return equipmentOrders;
    }

    
    @Override
    public void backtrackedTo() {
        individualTabController.updateLabels();
        dateLocationTabController.updateSelectionList();
        catererTabController.updateSelectionList();
    }
    /**
     * Cette fonction permet de vérifier que tout les field sont replis et replis corréctement
     * @return
     */
    private boolean checkValidity(){
        boolean isValid = true;
        if (individualTabController.getGroom1() == null){
            isValid = false;
            individualTabController.setGroom1Invalid(true);
            setTabInvalid(individualTabHeader);
        }
        if (individualTabController.getGroom2()  == null){
            isValid = false;
            individualTabController.setGroom2Invalid(true);
            setTabInvalid(individualTabHeader);
        }
        if (individualTabController.getClient() == null){
            isValid = false;
            individualTabController.setClientInvalid(true);
            setTabInvalid(individualTabHeader);
        }
        if (dateLocationTabController.getDateInterval().getStartDate()  == null){
            isValid = false;
            dateLocationTabController.setStartDateInvalid(true, "La date de début doit être renseigé");
            setTabInvalid(dateLocationTabHeader);
        }
        if (dateLocationTabController.getDateInterval().getEndDate()  == null){
            isValid = false;
            dateLocationTabController.setEndDateInvalid(true, "La date de fin doit être renseigé");
            setTabInvalid(dateLocationTabHeader);
        }
        if (dateLocationTabController.getLocations()  == null){
            isValid = false;
            dateLocationTabController.setLocationInvalid(true);
            setTabInvalid(dateLocationTabHeader);
        }
        if (detailsTabController.getGuestAmount() == 0){
            isValid = false;
            detailsTabController.setGestAmountInvalid(true, "Le nombre d'inviter doit être reneigné");
            setTabInvalid(detailsTabHeader);
        }
        return isValid;
    }
    /**
     * cette fonction permet de restet le style de tout les champs a remplir.
     * Cette fonction toujours appeler avant checkValidity
     */
    private void resetValidity(){
        individualTabController.setGroom1Invalid(false);
        individualTabController.setGroom2Invalid(false);
        individualTabController.setClientInvalid(false);
        dateLocationTabController.setStartDateInvalid(false, null);
        dateLocationTabController.setEndDateInvalid(false, null);
        dateLocationTabController.setLocationInvalid(false);
        detailsTabController.setGestAmountInvalid(false, null);
        setTabValid(individualTabHeader);
        setTabValid(dateLocationTabHeader);
        setTabValid(catererTabHeader);
        setTabValid(equipmentTabHeader);
        setTabValid(detailsTabHeader);
    }

    /**
     * cette fonction permet de mettre le style invalidTabl si elle ne l'a pas déja a la tab conserné (celle dans laquel il y a une errreur)
     * @param label
     */
    private void setTabInvalid(Label label){
        if(!label.getStyleClass().contains("invalidTab")){
            label.getStyleClass().add("invalidTab");
        }
    }

    /**
     * cette fonction permet de retirer le style invalidTab d'une tab elle est toujours utiliser avant setTabInvalid
     * @param label
     */
    private void setTabValid(Label label){
        label.getStyleClass().remove("invalidTab");
    }
}
