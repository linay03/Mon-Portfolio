package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.DesignIndividual.IndividualDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Individual;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.net.URL;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class IndividualConsultationDataController extends ConsultationDataController<Individual> {

    @FXML
    private Label lastNameLabel, firstNameLabel, emailLabel, phoneNumberLabel, dateOfBirthLabel,roadNumberLabel, roadNameLabel, postalCodeLabel;

    public IndividualConsultationDataController(Individual individual){
        super(individual);
    }

    @Override
    public String getFxmlPath() {
        return "/fr/uga/iut2/genevent/views/Consultation/Individual/consultationIndividual.fxml";
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Individual individual = getConsultedObject();
        lastNameLabel.setText( individual.getName());
        firstNameLabel.setText(individual.getFirstName());
        emailLabel.setText(individual.getMail());
        phoneNumberLabel.setText(individual.getPhone());
        dateOfBirthLabel.setText(individual.getBirthdate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ISO_DATE));
        roadNumberLabel.setText(String.valueOf(individual.getAdress().getNumeroRue()));
        roadNameLabel.setText(individual.getAdress().getNomRue());
        postalCodeLabel.setText(individual.getAdress().getCodePostal());
    }

    @Override
    protected void edit(){
        IndividualDesignController controller = new IndividualDesignController(getConsultedObject());
        RootController.getPageManager().stepForward(
                new Page("Modification d'un particulier", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }

}
