package fr.uga.iut2.genevent.controller.DesignLocation;

import fr.uga.iut2.genevent.model.InteriorExterior;
import fr.uga.iut2.genevent.model.Location;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;

import java.net.URL;
import java.util.ResourceBundle;

class LocationTabSpecificationController implements Initializable {
	
	@FXML
	private ComboBox<InteriorExterior> interiorExteriorComboBox;
	@FXML
	private TextArea specificationArea;

	private Location editedLocation;

	LocationTabSpecificationController(){}

	//Utilisé pour spécifier l'object modifié lors de la modification (les labels doivent être mis à jour)
	public LocationTabSpecificationController(Location editedLocation){
		this.editedLocation = editedLocation;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		interiorExteriorComboBox.setItems(FXCollections.observableArrayList(
				InteriorExterior.values()
		));
		interiorExteriorComboBox.setValue(InteriorExterior.Interieur);

		//Si en mode édition, initialise les field au valeur de l'object
		if(editedLocation != null){
			interiorExteriorComboBox.setValue( editedLocation.getInteriorExterior() );
			specificationArea.setText( editedLocation.getDetails());
		}
	}
	
	public InteriorExterior getInteriorExterior(){
		return interiorExteriorComboBox.getValue();
	}
	public String getSpecifications(){
		return specificationArea.getText();
	}

	public void setInteriorExteriorInvalid(boolean isInvalid){
		if(isInvalid){
			interiorExteriorComboBox.getStyleClass().add("invalid");
		}else{
			interiorExteriorComboBox.getStyleClass().remove("invalid");
		}
	}
}
