package fr.uga.iut2.genevent.model;

import java.io.Serializable;

/**
 * Classe qui représente la notion de Person (personne physique ou morale)
 * Un client, un(e) marié(e), un fournisseur, un propriétaire, un traiteur sont des personnes.
 * Une personne possède :
 * - phone : numéro de téléphone
 * - une adresse
 * - mail : une adresse mail
 */
public abstract class Person implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private String phone;
    private Adresse adress;
    private String mail;

    public Person(String phone, Adresse adress, String mail) {
        this.phone = phone;
        this.adress = adress;
        this.mail = mail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Adresse getAdress() {
        return adress;
    }

    public void setAdress(Adresse adress) {
        this.adress = adress;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
}
