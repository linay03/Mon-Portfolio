package fr.uga.iut2.genevent.exceptions;


public class AdresseInvalideException extends Exception {

    public AdresseInvalideException() {
        super("Un autre lieu a déjà cette adresse");
    }
}

