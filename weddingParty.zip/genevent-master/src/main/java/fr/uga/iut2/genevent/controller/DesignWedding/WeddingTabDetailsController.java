package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.model.Wedding;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.ResourceBundle;

public class WeddingTabDetailsController implements Initializable {

	@FXML
	private VBox container;

	@FXML
	private TextField guestAmountField;
	@FXML
	private TextArea detailsArea;

	private int guestAmount;

	private Wedding editedWedding;

	WeddingTabDetailsController(){}
	WeddingTabDetailsController(Wedding editedWedding){
		this.editedWedding = editedWedding;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		if(editedWedding != null){
			guestAmount = editedWedding.getGuestNb();
			guestAmountField.setText( String.valueOf(editedWedding.getGuestNb()) );
			detailsArea.setText( editedWedding.getDetails() );
		}
	}

	public int getGuestAmount() {
		return guestAmount;
	}

	public String getDetails() {
		return detailsArea.getText();
	}

	@FXML
	private void upGuestAmount(ActionEvent event) {
		guestAmount++;
		guestAmountField.setText( String.valueOf(guestAmount) );
	}
	@FXML
	private void downGuestAmount(ActionEvent event){
		if(guestAmount > 0){
			guestAmount--;
			guestAmountField.setText( String.valueOf(guestAmount) );
		}
	}
	@FXML
	private void updateGuestAmount(ActionEvent event){
		try{
			int inputedValue = Integer.parseInt( guestAmountField.getText() );
			//clamp le min à 0
			if(inputedValue < 0){
				guestAmount = 0;
				guestAmountField.setText("0");
			}
			else{
				guestAmount = inputedValue;
			}
		}
		catch(NumberFormatException e){
			//Reset à la valeur précédente si l'entrée n'est pas un int
			guestAmountField.setText( String.valueOf(guestAmount) );
		}
		container.requestFocus();
	}

	public void setGestAmountInvalid(boolean isInvalid, String message){
		if (isInvalid){
			guestAmountField.getParent().getStyleClass().add("invalid");
			guestAmountField.setTooltip(new Tooltip(message));
		}else{
			guestAmountField.getParent().getStyleClass().remove("invalid");
			guestAmountField.setTooltip(new Tooltip(null));
		}
	}

}
