package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.DesignSupplier.SupplierDesignController;
import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Supplier;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SupplierDirectoryController extends DirectoryController {

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        super.initialize(url, resourceBundle);
        initialiseNames("Fournisseurs", "fournisseur");

        initItems();
    }

    @Override
    protected void initItems() {

        //vide tous les éléments
        getContent().getChildren().clear();

        for(Supplier supplier : RootController.getGenevent().getSuppliers()){

            Pane supplierItem;

            try{
                //Charge l'item et le relie à l'élément
                DirectoryItemController<Supplier> controller = new DirectoryItemController<>(supplier);
                FXMLLoader supplierItemLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/views/Items/directoryItem.fxml"));
                supplierItemLoader.setController(controller);
                supplierItem = supplierItemLoader.load();
            } catch (IOException e) {
                supplierItem = new Pane(new Label(e.getMessage()));
                throw new RuntimeException(e);
            }
            //Assure que la taille de l'item prennent toute la fenêtre
            supplierItem.setMinWidth(super.getContent().getWidth());
            supplierItem.minWidthProperty().bind(super.getScrollPane().widthProperty());

            //Ajoute l'item
            super.getContent().getChildren().add(supplierItem);
        }
    }

    @Override
    protected void createNew(ActionEvent event) {
        SupplierDesignController controller = new SupplierDesignController();
        RootController.getPageManager().stepForward(
                new Page("Création d'un fournisseur","/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }
}
