package fr.uga.iut2.genevent.controller.SelectionItems;

import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class SelectionItemController<T extends DirectoryItem<T>> extends DirectoryItemController<T> {

    private Selector<T> selector;

    public SelectionItemController(T object, Selector<T> selector) {
        super(object);
        this.selector = selector;
    }

    @FXML
    private void select(ActionEvent event){
        selector.setObject(getObject());
        RootController.getPageManager().backtrack();
    }
}
