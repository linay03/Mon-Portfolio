package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.ConsultationController.EquipementConsultationDataController;
import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.util.StringUtil;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Cette classe représente la notion de matériel
 * Un matériel prends en compte une demande matériel
 * pour vérifier le stock restant.
 * Un matériel possède :
 * - name : le nom du lieu
 * - une description
 * - categoryEquipment : la catégorie de matériel (Meubles,Argenterie...)
 * - price : le prix
 * - weddingReserved : une liste de tous les mariages auquel il est reservés
 * - othersReservations : une liste pour toutes les demandes extérieures auquel il est reservé
 * - totalStock : un stock total
 * - supplier : un fournisseur
 *
 */
public class Equipment implements Serializable, DirectoryItem<Equipment> {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation

    private String name;
    private String description;

    private CategorieMateriel categoryEquipment;
    private float price;

    private ArrayList<Wedding> weddingsReserved =new ArrayList<>();

    private ArrayList<EquipmentOrder> othersReservations = new ArrayList<>();

    private int totalStock;

    private Supplier supplier;

    /**
     * Constructeur de la classe Equipment
     * @param name est le nom du matériel (ex : chaisse, table...)
     * @param description est une courte description du matériel (ex: en bois de chêne, pour 6 personnes...)
     * @param price est le prix du matériel (quantité x1)
     * @param totalStock est le stock total que le fournisseur possède.
     * @param categoryEquipment est la catégorie du matériel (Argenterie, Meuble, Décoration, Pour les enfants)
     * @param supplier est le fournisseur possédant ce matériel
     */
    public Equipment(String name, String description, float price, int totalStock, CategorieMateriel categoryEquipment, Supplier supplier ){
        setName(name);
        this.description = description;
        this.price = price;
        this.totalStock = totalStock;
        this.categoryEquipment = categoryEquipment;
        this.supplier = supplier;
    }

    @Override
    public ItemFieldInfos getItemFieldInfo() {
        return new ItemFieldInfos(15, 30, 10, 15,
                getName(), getDescription(), String.valueOf(getPrice()), getSupplier().getName());
    }
    @Override
    public ConsultationDataController<Equipment> getConsultationDataController() {
        return new EquipementConsultationDataController(this);
    }
    @Override
    public String getElementName() {
        return "materiel";
    }

    public String getName() {
        return name;
    }

    /**
     * Méthode permettant de s'assurer que le nom du traiteur commence par une majsucule suivie de minuscules
     * @param name est le nom du traiteur
     */
    public void setName(String name) {
        this.name = StringUtil.capitalize(name);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public int getTotalStock() {
        return totalStock;
    }

    public void setTotalStock(int totalStock) {
        this.totalStock = totalStock;
    }


    /**
     * Méthode qui permet d'avoir le stock actuel à un interval de temps donné
     * Elle parcourt les mariages et autres reservations enregistrés pour voir quelle
     * quantité il reste pour un interval de date donnée.
     * @param order de type EquipmentOrder
     * @return le stock actuel à l'interval de temps demandé
     */
    public int getCurrentStock(EquipmentOrder order) {
        int currentStockAtDate = 0;
        for (Wedding wedding :weddingsReserved){
            if (wedding.getDateInterval().overlap(order.getDateInterval())){
                for (EquipmentOrder orderInWedding : wedding.getEquipmentOrders()){
                    if (orderInWedding.getEquipment().equals(this)){
                        currentStockAtDate += orderInWedding.getAmount();
                    }
                }
            }
        }
        for (EquipmentOrder others: othersReservations) {
            if (others.getDateInterval().overlap(order.getDateInterval())) {
                currentStockAtDate += others.getAmount();
            }
        }
        return this.totalStock - currentStockAtDate;
    }

    public void addWeddingReservations(Wedding wedding){
        this.weddingsReserved.add(wedding);
    }

    public void addOthersReservations(EquipmentOrder order){
        this.othersReservations.add(order);
    }

    public ArrayList<Wedding> getWeddingsReserved() {
        return weddingsReserved;
    }

    public void setWeddingsReserved(ArrayList<Wedding> weddingsReserved) {
        this.weddingsReserved = weddingsReserved;
    }

    public ArrayList<EquipmentOrder> getOthersReservations() {
        return othersReservations;
    }

    public void setOthersReservations(ArrayList<EquipmentOrder> othersReservations) {
        this.othersReservations = othersReservations;
    }

    public CategorieMateriel getCategoryEquipment() {
        return categoryEquipment;
    }

    public void setCategoryEquipment(CategorieMateriel categoryEquipment) {
        this.categoryEquipment = categoryEquipment;
    }
}
