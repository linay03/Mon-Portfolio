package fr.uga.iut2.genevent.controller.DesignIndividual;

import fr.uga.iut2.genevent.model.Adresse;
import fr.uga.iut2.genevent.model.Individual;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;

import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

public class IndividualDataController implements Initializable {

	@FXML
	private TextField nameField, firstNameField, emailField, phoneField, roadNumberField, roadNameField, postalCodeField;
	@FXML
	private DatePicker birthdayField;

	private Individual editedIndividual;

	IndividualDataController(){}//Constructeur vide par défaut
	
	//Utilisé pour spécifier l'object modifié lors de la modification (les labels doivent être mis à jour)
	public IndividualDataController(Individual editedIndividual){
		this.editedIndividual = editedIndividual;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {

		//Désactive les jours future dans le calendrier
		birthdayField.setDayCellFactory(picker -> new DateCell() {
			@Override
			public void updateItem(LocalDate date, boolean empty) {
				super.updateItem(date, empty);
				LocalDate today = LocalDate.now();

				setDisable(empty || date.isAfter(today));
			}
		});

		//Si en mode édition, initialise les field aux valeur de l'object
		if(editedIndividual != null){
			nameField.setText( editedIndividual.getName() );
			firstNameField.setText( editedIndividual.getFirstName() );
			emailField.setText( editedIndividual.getMail() );
			phoneField.setText( editedIndividual.getPhone() );
			roadNumberField.setText( editedIndividual.getAdress().getNumeroRue() );
			roadNameField.setText( editedIndividual.getAdress().getNomRue() );
			postalCodeField.setText( editedIndividual.getAdress().getCodePostal() );
			birthdayField.setValue( editedIndividual.getBirthdate().toInstant()
					.atZone(ZoneId.systemDefault())
					.toLocalDate());
		}
	}

	public String getLastName(){
		return nameField.getText().trim();
	}
	public String getFirstName(){
		return firstNameField.getText().trim();
	}
	public String getEmail(){
		return emailField.getText().trim();
	}
	public String getPhone(){
		return phoneField.getText().trim();
	}
	public Date getBirthday(){
		ZoneId defaultZoneId = ZoneId.systemDefault();
		LocalDate localDate = birthdayField.getValue();
		if (localDate != null) {
			return Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
		}else{
			return null;
		}
	}
	public Adresse getAdresse(){
		return new Adresse(getRoadNumber(), getRoadName(), getPostalCode());
	}
	public String getRoadNumber(){
		return roadNumberField.getText().trim();
	}
	public String getRoadName(){
		return roadNameField.getText().trim();
	}
	public String getPostalCode(){
		return postalCodeField.getText().trim();
	}

	/**
	 * si isInvalid est true on met le style invalid au fied qu'il faut remplir
	 * et on ajout un message qui apparait lorsque l'on survole le field
	 * @param isInvalid
	 * @param message
	 */
	public void setFirstNameInvalid(boolean isInvalid, String message){
		if (isInvalid){
			firstNameField.setTooltip(new Tooltip(message));
			firstNameField.getStyleClass().add("invalid");
		}else{
			firstNameField.getStyleClass().remove("invalid");
		}
	}
	public void setLastNameInvalid(boolean isInvalid, String message){
		if (isInvalid){
			nameField.setTooltip(new Tooltip(message));
			nameField.getStyleClass().add("invalid");
		}else{
			nameField.getStyleClass().remove("invalid");
		}
	}
	public void setEmailInvalid(boolean isInvalid, String message){
		if (isInvalid){
			emailField.setTooltip(new Tooltip(message));
			emailField.getStyleClass().add("invalid");
		}else{
			emailField.getStyleClass().remove("invalid");
		}
	}
	public void setPhoneInvalid(boolean isInvalid, String message){
		if (isInvalid){
			phoneField.setTooltip(new Tooltip(message));
			phoneField.getStyleClass().add("invalid");
		}else{
			phoneField.getStyleClass().remove("invalid");
		}
	}
	public void setBirthDayInvalid(boolean isInvalid, String message){
		if (isInvalid){
			birthdayField.setTooltip(new Tooltip(message));
			birthdayField.getStyleClass().add("invalid");
		}else{
			birthdayField.getStyleClass().remove("invalid");
		}
	}
	public void setRoadNumberInvalid(boolean isInvalid, String message){
		if (isInvalid){
			roadNameField.setTooltip(new Tooltip(message));
			roadNumberField.getStyleClass().add("invalid");
		}else{
			roadNumberField.getStyleClass().remove("invalid");
		}
	}
	public void setRoadNameInvalid(boolean isInvalid, String message){
		if (isInvalid){
			roadNameField.setTooltip(new Tooltip(message));
			roadNameField.getStyleClass().add("invalid");
		}else{
			roadNameField.getStyleClass().remove("invalid");
		}
	}
	public void setPostalCodeInvalid(boolean isInvalid, String message){
		if (isInvalid){
			postalCodeField.setTooltip(new Tooltip(message));
			postalCodeField.getStyleClass().add("invalid");
		}else{
			postalCodeField.getStyleClass().remove("invalid");
		}
	}

	//Manque setters, vérification de validité, et affichage des field invalide
	
}
