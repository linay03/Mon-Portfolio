package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.ListController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.ResourceBundle;

public abstract class DirectoryController extends ListController {

	//Probablement possible de plus généraliser avec plus d'interfaces et de types génériques
	
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		getCancelButton().setVisible(false);
	}
	
	@Override
	public void backtrackedTo() {
		initItems();
	}
}
