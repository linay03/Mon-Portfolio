package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.PageController;
import fr.uga.iut2.genevent.controller.RootController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ConsultationController<T> implements Initializable, PageController {

	@FXML
	private Label titleLabel;
	@FXML
	private ScrollPane scrollPane;

	private Pane pane = new Pane();

	private String title;

	private final ConsultationDataController<T> dataController;
	
	public Pane getPane(){
		return pane;
	}

	public ConsultationController(ConsultationDataController<T> dataController, String title){
		this.dataController = dataController;
		this.title = title;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		titleLabel.setText(title);

		scrollPane.setContent(pane);

		try{
			FXMLLoader loader = new FXMLLoader(getClass().getResource( dataController.getFxmlPath() ));
			loader.setController(dataController);
			getPane().getChildren().add(loader.load());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@FXML
	protected void back(ActionEvent event){
		RootController.getPageManager().backtrack();
	}
	@FXML
	private void edit(ActionEvent event){
		dataController.edit();
	}
}
