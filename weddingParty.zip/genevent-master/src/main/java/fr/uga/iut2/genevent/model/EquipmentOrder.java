package fr.uga.iut2.genevent.model;

import java.io.Serializable;

/**
 * Cette classe représente la notion de demande de matériel.
 * Une demande de matériel est créée lorsque l'on souhaite ajouter un matériel
 * pour un mariage.
 * Une demande de matériel possède :
 * - amount : une quantité demandée
 * - equipment : le matériel demandé
 * - wedding : le mariage qui fait la demande
 * - dateInterval : les dates pour lesquelles le matériel est demandé.
 */
public class EquipmentOrder implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private int amount;

    private Equipment equipment;

    private Wedding wedding;

    private DateInterval dateInterval;

    /**
     * La demande de matériel peut être créée en prenant le mariage en paramètre
     * @param equipment
     * @param amount
     * @param wedding
     */
    public EquipmentOrder(Equipment equipment, int amount,Wedding wedding) {
       this.equipment = equipment;
       setAmountWedding(amount);
       this.wedding = wedding;
       this.dateInterval = wedding.getDateInterval();
    }

    /**
     * La demande de matériel peut être créée en prenant un dateInterval.
     * Cela sert pour enregistrer une demande autre que celle d'un mariage.
     * @param equipment
     * @param amount
     * @param dateInterval
     */
    public EquipmentOrder(Equipment equipment, int amount,DateInterval dateInterval) {
        this.equipment = equipment;
        this.dateInterval = dateInterval;
        setAmountOthers(amount);
    }

    public Equipment getEquipment() {
        return equipment;
    }

    public void setEquipment(Equipment equipment) {
        this.equipment = equipment;
    }

    public Wedding getWedding() {
        return wedding;
    }

    public void setWedding(Wedding wedding) {
        this.wedding = wedding;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmountWedding(int amount) {
        this.amount = amount;
    }

    public void setAmountOthers(int amount) {
        this.amount = amount;
    }

    public DateInterval getDateInterval() {
        return dateInterval;
    }

    public void setDateInterval(DateInterval dateInterval) {
        this.dateInterval = dateInterval;
    }

    /**
     * Methode qui permet d'ajouter un mariage au matériel demandé.
     */
    public void addEquipmentWedding(){
        this.equipment.addWeddingReservations(wedding);
    }

    /**
     * Methode qui permet d'ajouter une demande de matériel
     * à l'équipment demandé.
     */
    public void addEquipmentOthers(){
        this.equipment.addOthersReservations(this);
    }

}
