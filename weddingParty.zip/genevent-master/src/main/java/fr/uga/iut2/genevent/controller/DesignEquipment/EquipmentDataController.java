package fr.uga.iut2.genevent.controller.DesignEquipment;

import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.controller.SupplierSelectionController;
import fr.uga.iut2.genevent.model.Equipment;
import fr.uga.iut2.genevent.model.CategorieMateriel;
import fr.uga.iut2.genevent.model.Supplier;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class EquipmentDataController implements Initializable {

    @FXML
    private TextField nameField, priceField, descriptionField, stockField;
    @FXML
    private ComboBox<CategorieMateriel> categoryComboBox;
    @FXML
    private Label supplierNameLabel, supplierEmailLabel;

    private Equipment editedEquipment;
    private Selector<Supplier> supplierSelector = new Selector<>(null);

    EquipmentDataController(){}//Constructeur vide par défaut

    //Utilisé pour spécifier l'object modifié lors de la modification (les labels doivent être mis à jour)
    EquipmentDataController(Equipment editedEquipment){
        this.editedEquipment = editedEquipment;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Initialise le comboBox
        categoryComboBox.setItems(FXCollections.observableArrayList(
                CategorieMateriel.values()
        ));
        categoryComboBox.setValue(CategorieMateriel.Decoration);

        //Vide les textField de la selection du supplier
        supplierNameLabel.setText("");
        supplierEmailLabel.setText("");

        //Si en mode édition, initialise les field aux valeur de l'object
        if(editedEquipment != null){
            nameField.setText( editedEquipment.getName() );
            priceField.setText( String.valueOf(editedEquipment.getPrice()) );
            descriptionField.setText( editedEquipment.getDescription() );
            stockField.setText( String.valueOf(editedEquipment.getTotalStock()) );
            categoryComboBox.setValue( editedEquipment.getCategoryEquipment() );
            supplierSelector.setObject( editedEquipment.getSupplier() );

            updateLabels();
        }
    }

    public String getName(){
        return nameField.getText().trim();
    }
    public String getPrice(){
        return priceField.getText().trim();
    }
    public String getDescription(){
        return descriptionField.getText();
    }
    public String getStock(){
        return stockField.getText();
    }
    public CategorieMateriel getCategory(){
        if (categoryComboBox == null){
            return null;
        }
        return categoryComboBox.getValue();
    }
    public Supplier getSupplier(){
        if (supplierNameLabel == null){
            return null;
        }
        return supplierSelector.getObject();
    }

    @FXML
    private void selectSupplier(ActionEvent event){
        //Réinit isChanged (utilisé pour remonter de deux pages si créer un nouveau)
        supplierSelector.setChanged(false);

        //Avance vers la page de selection pour selection owner. Aucun est indisponible.
        SupplierSelectionController controller = new SupplierSelectionController(supplierSelector, new ArrayList<>());
        RootController.getPageManager().stepForward(
                new Page("Selection du fournisseur", "/fr/uga/iut2/genevent/views/Base/list.fxml",
                        controller, true)
        );
    }

    public void updateLabels(){
        Supplier supplier = supplierSelector.getObject();

        if(supplier != null){
            supplierNameLabel.setText(supplier.getName());
            supplierEmailLabel.setText(supplier.getMail());
        }
    }

    //Manque setters, vérification de validité, et affichage des field invalide
    /**
     * si isInvalid est true on met le style invalid au fied qu'il faut remplir
     * et on ajout un message qui apparait lorsque l'on survole le field
     * @param isInvalid
     * @param message
     */
    public void setNameInvalid(boolean isInvalid, String message){
        if (isInvalid){
            nameField.setTooltip(new Tooltip(message));
            nameField.getStyleClass().add("invalid");
        }else{
            nameField.getStyleClass().remove("invalid");
        }
    }
    public void setCategoryInvalid(boolean isInvalid, String message){
        if (isInvalid){
            categoryComboBox.setTooltip(new Tooltip(message));
            categoryComboBox.getStyleClass().add("invalid");
        }else{
            categoryComboBox.getStyleClass().remove("invalid");
        }
    }
    public void setPriceInvalid(boolean isInvalid, String message){
        if (isInvalid){
            priceField.setTooltip(new Tooltip(message));
            priceField.getStyleClass().add("invalid");
        }else{
            priceField.getStyleClass().remove("invalid");
        }
    }
    public void setDescriptionInvalid(boolean isInvalid, String message){
        if (isInvalid){
            descriptionField.setTooltip(new Tooltip(message));
            descriptionField.getStyleClass().add("invalid");
        }else{
            descriptionField.getStyleClass().remove("invalid");
        }
    }
    public void setStockInvalid(boolean isInvalid, String message){
        if (isInvalid){
            stockField.setTooltip(new Tooltip(message));
            stockField.getStyleClass().add("invalid");
        }else{
            stockField.getStyleClass().remove("invalid");
        }
    }
    public void setSupplierInvalid(boolean isInvalid){
        if (isInvalid){
            supplierNameLabel.getParent().getStyleClass().add("invalid");
        }else{
            supplierNameLabel.getParent().getStyleClass().remove("invalid");
        }
    }

}
