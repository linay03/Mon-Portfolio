package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.ConsultationController.LocationConsultationDataController;
import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.exceptions.AdresseInvalideException;
import fr.uga.iut2.genevent.util.StringUtil;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Classe qui représente la notion de lieu.
 * Un lieu possède:
 * - un nom
 * - une adresse
 * - capacity : sa capacité maximale
 * - owner : son propriétaire
 * - price : son prix à la journée
 * - surface : sa surface
 * - weddingReserved : une liste des mariages auquels il est réservé
 * - unavailability : une liste de toutes les dates ou il est indisponible
 * - interiorExterior : une info mentionant si c'est un lieu exterieur, interieur, ou les deux
 * - details : les spécifications du lieu
 */
public class Location implements Serializable, DirectoryItem<Location> {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation

    private String name;

    private Adresse adress;

    private int capacity;

    private Owner owner;

    private float price;

    private ArrayList<Wedding> weddingsReserved = new ArrayList<>();

    private ArrayList<DateInterval> unavailability;

    private float surface;

    private InteriorExterior interiorExterior;

    private String details;


    /**
     * Nécessite que RootController ait été lancé pour fonctionner
     * @param name est le nom du Lieu (ex : La chateau dans le ciel)
     * @param adress est l'adresse du lieu
     * @param capacity est le nombre maximal de personne que peut accueillir le lieu
     * @param owner est le propriétaire du lieu
     * @param price est le prix du lieu pour
     */
    public Location(String name, Adresse adress, int capacity, float surface, Owner owner, float price,
                    InteriorExterior interiorExterior, String details, ArrayList<DateInterval> unavailability) throws AdresseInvalideException {
        setName(name);
        setAdress(adress);
        setCapacity(capacity);
        this.surface = surface;
        this.owner = owner;
        setPrice(price);
        this.interiorExterior = interiorExterior;
        this.details = details;
        this.unavailability = unavailability;
    }

    //Implémentation de directoryItem
    @Override
    public ItemFieldInfos getItemFieldInfo() {
        return new ItemFieldInfos(20, 20, 20, 10,
                getName(), getAdress().toString(), "Capacité : " + getCapacity(), getPrice() + "€");
    }
    @Override
    public ConsultationDataController<Location> getConsultationDataController() {
        return new LocationConsultationDataController(this);
    }
    @Override
    public String getElementName() {
        return "lieu";
    }

    //Getters et Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = StringUtil.capitalize(name);
    }

    public Adresse getAdress() {
        return adress;
    }
    /**
     * Vérifie adresse ne doit pas etre déjà utilisée par un autre lieu
     * Si cette adresse est valide, alors elle est définie, sinon on renvoie une exception
     * @param adress est l'adresse que l'on veut définir à ce lieu
     * @throws AdresseInvalideException Exception lancée si l'adresse est déjà occupée par un autre lieu.
     */
    public void setAdress(Adresse adress) throws AdresseInvalideException {
        if (RootController.getGenevent() != null){
            for (Location location : RootController.getGenevent().getLocations()){
                if (location.getAdress().equals(adress)){
                    throw new AdresseInvalideException();
                }
            }
        }
        this.adress = adress;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        if (capacity > 0) {
            this.capacity = capacity;
        } else {
            throw new IllegalArgumentException();
        }
    }

    public float getSurface() {
        return surface;
    }

    public void setSurface(float surface) {
        this.surface = surface;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(Float price) throws IllegalArgumentException {
        if (price==null || price >=0) {
            this.price = price;
        } else {
            throw new IllegalArgumentException();
        }
    }

    public ArrayList<DateInterval> getUnavailability() {
        return unavailability;
    }

    public void setUnavailability(ArrayList<DateInterval> unavailability) {
        this.unavailability = unavailability;
    }

    public InteriorExterior getInteriorExterior() {
        return interiorExterior;
    }

    public void setInteriorExterior(InteriorExterior interiorExterior) {
        this.interiorExterior = interiorExterior;
    }

    public ArrayList<Wedding> getWeddingsReserved() {
        return weddingsReserved;
    }

    public void setWeddingsReserved(ArrayList<Wedding> weddingsReserved) {
        this.weddingsReserved = weddingsReserved;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void addWedding(Wedding wedding) {
        wedding.addLocation(this);
    }

    /**
     * Methode qui retire le mariage parmi ceux enregistrés par le lieu
     * @param wedding
     */
    public void removeWedding(Wedding wedding) {
        if (this.weddingsReserved.contains(wedding)){
            weddingsReserved.remove(wedding);
            //TODO : appelle de la fonction dans Wedding pour enlever ce lieu
            if(wedding.containsLocation(this)){

            }
        }
    }

    /**
     * Méthode qui vérifie si les dates entrées en paramètres sont déjà dans
     * les dates indisponibles du lieu, les dates où le lieu est déjà reservé.
     * @param dateInterval
     * @return
     */
    public boolean isIntervalReserved(DateInterval dateInterval) {
        for (DateInterval dateIntervalUnavailable : unavailability) {
            if (dateInterval.overlap(dateIntervalUnavailable)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Méthode qui teste si pour cette location une
     * réservation est déjà prise à la date du mariage passé en paramètres
     */
    public boolean containsWedding(Wedding wedding){
        return this.weddingsReserved.contains(wedding);
    }

    public void addWeddingsReserved(Wedding wedding) {
        DateInterval dateIntervalUnavailable = wedding.getDateInterval();
        this.weddingsReserved.add(wedding);
        this.unavailability.add(dateIntervalUnavailable);
    }
}

