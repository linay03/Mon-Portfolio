package fr.uga.iut2.genevent.controller.DesignLocation;

import fr.uga.iut2.genevent.controller.OwnerSelectionController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class LocationTabInfosController implements Initializable {

    @FXML
    private VBox container;
    @FXML
    private TextField nameField, roadNumberField, roadNameField, postalCodeField, priceField, capacityField, surfaceField;
    @FXML
    private Button capacityPlus, capacityMinus, surfacePlus, surfaceMinus, selectOwner;
    @FXML
    private Label ownerNameLabel, ownerEmailLabel, ownerPhoneLabel;

    private int currentCapacity = 0;

    private Location editedLocation;
    private Selector<Owner> ownerSelector = new Selector<>(null);

    LocationTabInfosController(){}//Constructeur vide par défaut

    //Utilisé pour spécifier l'object modifié lors de la modification (les labels doivent être mis à jour)
    public LocationTabInfosController(Location editedLocation){
        this.editedLocation = editedLocation;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        capacityField.setText( String.valueOf(currentCapacity) );
        ownerNameLabel.setText("");
        ownerEmailLabel.setText("");
        ownerPhoneLabel.setText("");

        //Si en mode édition, initialise les field aux valeur de l'object
        if(editedLocation != null){
            nameField.setText( editedLocation.getName() );
            roadNumberField.setText( editedLocation.getAdress().getNumeroRue() );
            roadNameField.setText( editedLocation.getAdress().getNomRue() );
            postalCodeField.setText( editedLocation.getAdress().getCodePostal() );
            priceField.setText( String.valueOf(editedLocation.getPrice()) );
            capacityField.setText( String.valueOf(editedLocation.getCapacity()) );
            surfaceField.setText( String.valueOf(editedLocation.getSurface()) );
            ownerSelector.setObject(editedLocation.getOwner());
        }
    }

    @FXML
    private void upCapacity(ActionEvent event){
        currentCapacity++;
        capacityField.setText( String.valueOf(currentCapacity) );
    }
    @FXML
    private void downCapacity(ActionEvent event){
        if(currentCapacity > 0){
            currentCapacity--;
            capacityField.setText( String.valueOf(currentCapacity) );
        }
    }
    
    @FXML
    private void updateCapacity(ActionEvent event){
        try{
            int inputedValue = Integer.parseInt( capacityField.getText() );
            //clamp le min à 0
            if(inputedValue < 0){
                currentCapacity = 0;
                capacityField.setText("0");
            }
            else{
                currentCapacity = inputedValue;
            }
        }
        catch(NumberFormatException e){
            //Reset à la valeur précédente si l'entrée n'est pas un int
            capacityField.setText( String.valueOf(currentCapacity) );
        }
        container.requestFocus();
    }

    public String getName(){
        return nameField.getText().trim();
    }
    /**
     * cette fonction return l'adresse en la constituant avec la fonction getRoadNumber, getRoadName et getPostalCode
     * @return
     */
    public Adresse getAdresse(){
        return new Adresse(getRoadNumber(), getRoadName(), getPostalCode());
    }
    public String getRoadNumber(){
        return roadNumberField.getText().trim();
    }
    public String getRoadName(){
        return roadNameField.getText().trim();
    }
    public String getPostalCode(){
        return postalCodeField.getText().trim();
    }
    public String getPrice(){
        return priceField.getText().trim();
    }
    public int getCapacity(){
        return Integer.parseInt(capacityField.getText().trim());
    }
    public String getSurface(){
        return surfaceField.getText().trim();
    }
    public Owner getOwner(){
        return ownerSelector.getObject();
    }

    @FXML
    private void selectOwner(ActionEvent event){
        ownerSelector.setChanged(false);
        
        //Avance vers la page de selection pour selection owner. Aucun est indisponible.
        OwnerSelectionController controller = new OwnerSelectionController(ownerSelector, new ArrayList<>());
        RootController.getPageManager().stepForward(
                new Page("Selection du propriétaire", "/fr/uga/iut2/genevent/views/Base/list.fxml",
                        controller, true)
        );
    }
    
    public void updateLabels(){
        Owner owner = ownerSelector.getObject();
        
        if(owner != null){
            ownerNameLabel.setText(owner.getName());
            ownerEmailLabel.setText(owner.getMail());
            ownerPhoneLabel.setText(owner.getPhone());
        }
    }
    /**
     * si isInvalid est true on met le style invalid au fied qu'il faut remplir
     * et on ajout un message qui apparait lorsque l'on survole le field
     * @param isInvalid
     * @param message
     */
    public void setNameInvalid(boolean isInvalid, String message) {
        if (isInvalid) {
            nameField.setTooltip(new Tooltip(message));
            nameField.getStyleClass().add("invalid");
        } else {
            nameField.setTooltip(null);
            nameField.getStyleClass().remove("invalid");
        }
    }
    public void setRoadNumberInvalid(boolean isInvalid, String message){
        if (isInvalid) {
            roadNumberField.setTooltip(new Tooltip(message));
            roadNumberField.getStyleClass().add("invalid");
        }else {
            roadNumberField.setTooltip(null);
            roadNumberField.getStyleClass().remove("invalid");
        }
    }
    public void setRoadNameInvalid(boolean isInvalid, String message){
        if (isInvalid) {
            roadNameField.setTooltip(new Tooltip(message));
            roadNameField.getStyleClass().add("invalid");
        }else {
            roadNameField.setTooltip(null);
            roadNameField.getStyleClass().remove("invalid");
        }
    }
    public void setPostalCodeInvalid(boolean isInvalid, String message){
        if (isInvalid) {
            postalCodeField.setTooltip(new Tooltip(message));
            postalCodeField.getStyleClass().add("invalid");
        }else {
            postalCodeField.setTooltip(null);
            postalCodeField.getStyleClass().remove("invalid");
        }
    }
    public void setPriceInvalid(boolean isInvalid, String message){
        if (isInvalid) {
            priceField.setTooltip(new Tooltip(message));
            priceField.getStyleClass().add("invalid");
        }else{
            priceField.setTooltip(null);
            priceField.getStyleClass().remove("invalid");
        }
    }
    public void setCapacityInvalid(boolean isInvalid, String message){
        if (isInvalid) {
            capacityField.setTooltip(new Tooltip(message));
            capacityField.getStyleClass().add("invalid");
        }else{
            capacityField.setTooltip(null);
            capacityField.getStyleClass().remove("invalid");
        }
    }
    public void setSurfaceInvalid(boolean isInvalid, String message){
        if (isInvalid){
            surfaceField.setTooltip(new Tooltip(message));
            surfaceField.getStyleClass().add("invalid");
        }else{
            surfaceField.setTooltip(null);
            surfaceField.getStyleClass().remove("invalid");
        }
    }
    public void setOwnerInvalid(boolean isInvalid){
        if(isInvalid){
            ownerNameLabel.getParent().getStyleClass().add("invalid");
        }else{
            ownerNameLabel.getParent().getStyleClass().remove("invalid");
        }
    }

}
