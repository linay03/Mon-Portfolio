package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.controller.DesignIndividual.IndividualDesignController;
import fr.uga.iut2.genevent.controller.SelectionItems.SelectionItemController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Individual;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class IndividualSelectionController extends SelectionController<Individual> {
	
	private ArrayList<Individual> unavailable;
	
	public IndividualSelectionController(Selector<Individual> selectorObject, ArrayList<Individual> unavailable) {
		//Le selecteur où iras l'individus selectionné.
		super(selectorObject);
		this.unavailable = unavailable;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		initialiseNames("Particuliers", "particulier");
		initItems();
	}
	
	@Override
	protected void initItems() {
		for( Individual individual : RootController.getGenevent().getIndividuals() ){
			
			Pane individualItem;
			
			try {
				SelectionItemController<Individual> controller = new SelectionItemController<>(individual, getSelectorObject());
				FXMLLoader individualItemLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/selectionItem.fxml"));
				individualItemLoader.setController(controller);
				individualItem = individualItemLoader.load();
				
			} catch (IOException e) {
				individualItem = new Pane(new Label(e.getMessage()));
				throw new RuntimeException(e);
			}

			individualItem.setMinWidth(super.getContent().getWidth());
			individualItem.minWidthProperty().bind(super.getScrollPane().widthProperty());
			
			if(unavailable.contains(individual)){
				individualItem.setDisable(true);
			}
			
			super.getContent().getChildren().add(individualItem);
		}
	}


	@Override
	protected void createNew(ActionEvent event) {
		IndividualDesignController controller = new IndividualDesignController(getSelectorObject());
		RootController.getPageManager().stepForward(
				new Page("Création d'un particulier", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
						controller, true)
		);
	}
}
