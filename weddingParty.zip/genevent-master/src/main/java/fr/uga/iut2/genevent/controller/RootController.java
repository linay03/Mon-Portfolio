package fr.uga.iut2.genevent.controller;

import fr.uga.iut2.genevent.exceptions.AdresseInvalideException;
import fr.uga.iut2.genevent.insertionDonnees;
import fr.uga.iut2.genevent.model.GenEvent;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

import java.util.logging.Level;
import java.util.logging.Logger;

public class RootController {


    private static GenEvent genevent;
    private static CountDownLatch eolBarrier;  // /!\ ne pas supprimer /!\ : suivi de la durée de vie de l'interface

    private static PageManager pageManager;
    
    public static PageManager getPageManager(){
        return pageManager;
    }
    public static LeadingController getLeadingController(){
        return pageManager.getLeadingController();
    }
    
    public static GenEvent getGenevent() {
        return genevent;
    }

    public static void setGenevent(GenEvent genevent){
        RootController.genevent =genevent;
    }

    private static Logger LOGGER = Logger.getLogger(RootController.class.getPackageName());
    
    /**
     * Lance les controlleurs et garde le control de l'app.
     * @param genevent Le genEvent qui sera utilisé comme root du modèle.
     */
    public static void start(GenEvent genevent){
        RootController.genevent = genevent;
        eolBarrier = new CountDownLatch(1);  // /!\ ne pas supprimer /!\

        if(false){//Pour l'insertion de données par défaut. A désactiver
            insertDefaultData();
        }

        // démarrage de l'interface JavaFX
        Platform.startup(() -> {
            Stage primaryStage = new Stage();
            primaryStage.setMaximized(true);
            primaryStage.setOnCloseRequest((WindowEvent t) -> exit());
            primaryStage.setMinHeight(900);
            primaryStage.setMinWidth(1100);
            try {
                startController(primaryStage);
            }
            catch (IOException exc) {
                throw new RuntimeException(exc);
            }
        });

        // attente de la fin de vie de l'interface JavaFX
        try {
            eolBarrier.await();
        }
        catch (InterruptedException exc) {
            System.err.println("Erreur d'exécution de l'interface.");
            System.err.flush();
        }
    }

    private static void startController(Stage primaryStage) throws IOException {

        pageManager = new PageManager();
        pageManager.setLeadingController(new LeadingController());

        FXMLLoader leadingLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Base/leading.fxml"));
    
        leadingLoader.setController(pageManager.getLeadingController());
        Scene mainScene = new Scene(leadingLoader.load());
        mainScene.getStylesheets().add(RootController.class.getResource("/fr/uga/iut2/genevent/css/Style_Base.css").toExternalForm());

        getLeadingController().showWeddingDirectory(new ActionEvent());
    
        primaryStage.setTitle("Wedding Party - Professional wedding planer");
        primaryStage.setScene(mainScene);
        primaryStage.show();

    }

    private static void insertDefaultData(){
        try{
            insertionDonnees.initialisation();
        } catch (AdresseInvalideException e) {
            throw new RuntimeException(e);
        }
    }

    public static void exit() {
        // fermeture de l'interface JavaFX : on notifie sa fin de vie
        eolBarrier.countDown();
    }

    public static void logInfo(String message){
        LOGGER.setLevel(Level.INFO);
        LOGGER.log(Level.INFO,message);
    }

    //getLogger
    //Pour création et modif --> info
}


