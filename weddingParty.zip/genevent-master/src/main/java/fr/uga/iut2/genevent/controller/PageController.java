package fr.uga.iut2.genevent.controller;

public interface PageController {

	public default void backtrackedTo(){

	}
}
