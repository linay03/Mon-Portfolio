package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.DesignIndividual.IndividualDesignController;
import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Individual;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class IndividualDirectoryController extends DirectoryController {
	
	
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		super.initialize(url, resourceBundle);
		initialiseNames("Particuliers", "particulier");
		initItems();
	}
	
	@Override
	protected void initItems() {
		//vide tous les éléments
		getContent().getChildren().clear();
		
		for( Individual individual : RootController.getGenevent().getIndividuals() ){
			
			Pane individualItem;
			
			try {
				//Charge l'item et le relie à l'élement
				DirectoryItemController<Individual> controller = new DirectoryItemController<>(individual);
				FXMLLoader individualItemLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/directoryItem.fxml"));
				individualItemLoader.setController(controller);
				individualItem = individualItemLoader.load();
			}
			catch (IOException e) {
				individualItem = new Pane(new Label(e.getMessage()));
				throw new RuntimeException(e);
			}
			//Assure que la taille de l'item prennent toute la fenêtre
			individualItem.setMinWidth(super.getContent().getWidth());
			individualItem.minWidthProperty().bind(super.getScrollPane().widthProperty());
			
			//Ajoute l'item
			super.getContent().getChildren().add(individualItem);
		}
	}
	
	@Override
	protected void createNew(ActionEvent event) {
		IndividualDesignController controller = new IndividualDesignController();
		RootController.getPageManager().stepForward(
				new Page("Création d'un particulier", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
						controller, true)
		);
	}
}