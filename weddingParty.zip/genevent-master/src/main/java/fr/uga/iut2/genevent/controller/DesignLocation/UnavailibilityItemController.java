package fr.uga.iut2.genevent.controller.DesignLocation;

import fr.uga.iut2.genevent.controller.DesignLocation.LocationTabUnavailabilityController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

public class UnavailibilityItemController implements Initializable {
	
	@FXML
	private GridPane grid;
	@FXML
	private Label startDateLabel, endDateLabel;

	private LocalDate startDate, endDate;
	private LocationTabUnavailabilityController tabController;

	private DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("d/MM/uuuu");
	
	public Date getStarDate(){
		ZoneId defaultZoneId = ZoneId.systemDefault();
		return Date.from(startDate.atStartOfDay(defaultZoneId).toInstant());
	}
	public Date getEndDate(){
		ZoneId defaultZoneId = ZoneId.systemDefault();
		return Date.from(endDate.atStartOfDay(defaultZoneId).toInstant());
	}
	
	public UnavailibilityItemController(LocalDate startDate, LocalDate endDate, LocationTabUnavailabilityController tabController){
		this.startDate = startDate;
		this.endDate = endDate;
		this.tabController = tabController;
	}
	
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		startDateLabel.setText(startDate.format(dateFormat));
		endDateLabel.setText(endDate.format(dateFormat));
	}
	
	@FXML
	private void remove(ActionEvent event){
		//S'enlève de la liste
		tabController.removeItem(grid, this);
	}

}
