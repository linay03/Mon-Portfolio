package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.DesignCaterer.CatererDesignController;
import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Caterer;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class CatererDirectoryController extends DirectoryController{


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        super.initialize(url, resourceBundle);
        super.initialiseNames("Traiteurs", "traiteur");
        initItems();
    }

    @Override
    protected void initItems() {
        //vide les items
        getContent().getChildren().clear();

        //Temp
        for ( Caterer caterer : RootController.getGenevent().getCaterers()) {

            Pane catererItem;

            try{
                DirectoryItemController<Caterer> controller = new DirectoryItemController<>(caterer);
                FXMLLoader itemLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/views/Items/directoryItem.fxml"));
                itemLoader.setController(controller);
                catererItem = itemLoader.load();

            } catch (IOException e) {
                catererItem = new Pane(new Label(e.getMessage()));
                throw new RuntimeException(e);
            }
            catererItem.setMinWidth(super.getContent().getWidth());
            catererItem.minWidthProperty().bind(super.getScrollPane().widthProperty());

            getContent().getChildren().add(catererItem);
        }
    }

    @Override
    protected void createNew(ActionEvent event) {
        CatererDesignController controller = new CatererDesignController();
        RootController.getPageManager().stepForward(
                new Page("Création d'un traiteur", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }
}
