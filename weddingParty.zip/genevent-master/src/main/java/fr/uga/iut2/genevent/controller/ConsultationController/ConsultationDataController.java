package fr.uga.iut2.genevent.controller.ConsultationController;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public abstract class ConsultationDataController<T> implements Initializable {



    private final T object;

    protected T getConsultedObject() {
        return object;
    }

    protected ConsultationDataController(T object) {
        this.object = object;
    }

    public abstract String getFxmlPath();

    protected abstract void edit();
}
