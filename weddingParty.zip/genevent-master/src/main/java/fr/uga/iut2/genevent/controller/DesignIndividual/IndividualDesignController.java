package fr.uga.iut2.genevent.controller.DesignIndividual;

import fr.uga.iut2.genevent.controller.DesignController;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Adresse;
import fr.uga.iut2.genevent.model.Individual;
import javafx.event.ActionEvent;

import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.Date;
import java.util.ResourceBundle;

public class IndividualDesignController extends DesignController<Individual> {

    private IndividualDataController controller = new IndividualDataController();

    public IndividualDesignController(){
        super("Particulier");
    }
    public IndividualDesignController(Individual editedObject){
        super("Particulier", editedObject);
        controller = new IndividualDataController(editedObject);
    }
    public IndividualDesignController(Selector<Individual> selector){
        super(selector, "Particulier");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initializeCenter("/fr/uga/iut2/genevent/views/Design/DesignIndividual/designIndividual.fxml", controller);
    }

    @Override
    protected void save(ActionEvent event) {
        resetValidity();
        if (!checkValidity()){
            return;
        }

        String name = controller.getLastName();
        String firstName = controller.getFirstName();
        Date birthday = controller.getBirthday();
        String phone = controller.getPhone();
        Adresse adresse = controller.getAdresse();
        String email = controller.getEmail();

        if(isEditMod()){
            getEditedObject().setName(name);
            getEditedObject().setFirstName(firstName);
            getEditedObject().setBirthdate(birthday);
            getEditedObject().setPhone(phone);
            getEditedObject().setAdress(adresse);
            getEditedObject().setMail(email);

            RootController.logInfo("Modification d'un particulier");
            RootController.getPageManager().backtrack();
            RootController.getPageManager().backtrack();
        }
        else{
            Individual newIndividual = new Individual(name, firstName, birthday, phone, adresse, email);
            setNewObject(newIndividual); //L'objet créé est passé à super() pour être assigné au Selector lors d'un selection.

            RootController.getGenevent().newIndividual(newIndividual);

            RootController.logInfo("Création d'un nouveau particulier");
            RootController.getPageManager().backtrack();
        }
    }
    /**
     * Cette fonction permet de vérifier que tout les field sont replis et replis corréctement
     * @return
     */
    private boolean checkValidity(){
        boolean isValid = true;
        if (controller.getFirstName().isBlank()){
            isValid = false;
            controller.setFirstNameInvalid(true, "Le prénom doit être renseigné");
        }
        if(controller.getLastName().isBlank()){
            isValid = false;
            controller.setLastNameInvalid(true, "Le nom doit être renseigné");
        }
        if (controller.getEmail().isBlank()){
            isValid = false;
            controller.setEmailInvalid(true, "L'email doit être renseigné");
        }else if (!controller.getEmail().contains("@")){
            isValid = false;
            controller.setEmailInvalid(true, "L'email doit être du bon format");
        }
        if (controller.getPhone().isBlank()){
            isValid = false;
            controller.setPhoneInvalid(true, "Le numero de téléphone doit être renseigné");
        }else if (!controller.getPhone().matches("[0-9\\s]+")){
            //si le numéro de téléphone ne contien pas uniquement des chiffre et des espace
            isValid = false;
            controller.setPhoneInvalid(true, "Le numero de téléphone doit être du bon format");
        }
        if (controller.getBirthday() == null){
            isValid = false;
            controller.setBirthDayInvalid(true, "La date de naissance doit être renseigné");
        }
        if (controller.getRoadNumber().isBlank()){
            isValid = false;
            controller.setRoadNumberInvalid(true, "Le numero de rue doit être renseigné");
        }
        if (controller.getRoadName().isBlank()){
            isValid = false;
            controller.setRoadNameInvalid(true, "Le nom de rue doit être renseigné");
        }
        if (controller.getPostalCode().isBlank()){
            isValid = false;
            controller.setPostalCodeInvalid(true, "Le code postal doit être renseigné");
        }else if (controller.getPostalCode().length() != 5 || controller.getPostalCode().length() != 5 && !controller.getPostalCode().matches("\\d+")){
            //si le code postal ne fait pas exatement 5 de long ou si le code postal ne fait pas exatement 5 de long et contien d'autre carractère que des chiffre
            isValid = false;
            controller.setPostalCodeInvalid(true, "le code postal doit être valid (5 chiffre uniquement)");
        }
        return isValid;
    }
    /**
     * cette fonction permet de restet le style de tout les champs a remplir.
     * Cette fonction toujours appeler avant checkValidity
     */
    private void resetValidity(){
        controller.setFirstNameInvalid(false, null);
        controller.setLastNameInvalid(false, null);
        controller.setEmailInvalid(false, null);
        controller.setPhoneInvalid(false, null);
        controller.setBirthDayInvalid(false, null);
        controller.setRoadNumberInvalid(false, null);
        controller.setRoadNameInvalid(false, null);
        controller.setPostalCodeInvalid(false, null);
    }
}
