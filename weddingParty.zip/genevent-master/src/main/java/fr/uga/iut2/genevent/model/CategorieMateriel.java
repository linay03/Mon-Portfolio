package fr.uga.iut2.genevent.model;

import java.io.Serializable;

public enum CategorieMateriel implements Serializable {

    Argenterie("Argenterie"),
    Meubles("Meubles"),
    Decoration("Décoration"),
    Pour_les_enfants("Pour les enfants");

    private String label;

    CategorieMateriel(String label){
        this.label = label;
    }
}
