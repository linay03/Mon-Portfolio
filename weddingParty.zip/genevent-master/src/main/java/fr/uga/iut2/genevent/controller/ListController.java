package fr.uga.iut2.genevent.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

public abstract class ListController implements Initializable, PageController {
	
	@FXML
	private Label title;
	@FXML
	private Button buttonCreateNew, cancelButton;
	
	@FXML
	private ScrollPane scrollPane;
	@FXML
	private VBox content;
	
	public ScrollPane getScrollPane() {
		return scrollPane;
	}
	public Button getButtonCreateNew() {
		return buttonCreateNew;
	}
	public Button getCancelButton(){
		return cancelButton;
	}
	public VBox getContent() {
		return content;
	}
	
	protected void initialiseNames(String pageName, String elementName){
		title.setText(pageName);
		buttonCreateNew.setText("Créer nouveau " + elementName);
	}
	@FXML
	private void cancel(ActionEvent event){
		RootController.getPageManager().backtrack();
	}
	@FXML
	protected abstract void createNew(ActionEvent event);
	protected abstract void initItems();
	
}
