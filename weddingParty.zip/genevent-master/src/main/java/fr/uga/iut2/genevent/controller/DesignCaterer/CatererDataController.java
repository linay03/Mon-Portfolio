package fr.uga.iut2.genevent.controller.DesignCaterer;

import fr.uga.iut2.genevent.model.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;

import java.net.URL;
import java.util.ResourceBundle;

public class CatererDataController implements Initializable {

    @FXML
    private TextField nameField, emailField, phoneField, roadNumberField, roadNameField, postalCodeField;
    @FXML
    private TextArea menuField;
    @FXML
    private ComboBox<CatererCategory> categoryCbBox;

    private Caterer editedCaterer;

    CatererDataController(){}//Constructeur vide par défaut

    //Utilisé pour spécifier l'object modifié lors de la modification (les labels doivent être mis à jour)
    CatererDataController(Caterer editedCaterer){
        this.editedCaterer = editedCaterer;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        //Initialise les valeurs du comboBox
        categoryCbBox.setItems(FXCollections.observableArrayList(
                CatererCategory.values()
        ));
        categoryCbBox.setValue(CatererCategory.Mixte);

        //Si en mode édition, initialise les field aux valeur de l'object
        if(editedCaterer != null){
            nameField.setText( editedCaterer.getCompanyName() );
            emailField.setText( editedCaterer.getMail() );
            phoneField.setText( editedCaterer.getPhone() );
            menuField.setText( editedCaterer.getMenu() );
            roadNumberField.setText( editedCaterer.getAdress().getNumeroRue() );
            roadNameField.setText( editedCaterer.getAdress().getNomRue() );
            postalCodeField.setText( editedCaterer.getAdress().getCodePostal() );
            categoryCbBox.setValue( editedCaterer.getCategory() );
        }
    }

    public String getName() {
        return nameField.getText().trim();
    }

    public String getEmail() {
        return emailField.getText().trim();
    }

    public String getPhone() {
        return phoneField.getText().trim();
    }

    public String getMenu() {
        return menuField.getText().trim();
    }

    public Adresse getAdresse(){
        return new Adresse(getRoadNumber(), getRoadName(), getPostalCode());
    }
    public String getRoadNumber(){
        return roadNumberField.getText().trim();
    }
    public String getRoadName(){
        return roadNameField.getText().trim();
    }
    public String getPostalCode(){
        return postalCodeField.getText().trim();
    }

    public CatererCategory getCategory() {
        return categoryCbBox.getValue();
    }

    /**
     * si isInvalid est true on met le style invalid au fied qu'il faut remplir
     * et on ajout un message qui apparait lorsque l'on survole le field
     * @param isInvalid
     * @param message
     */
    public void setNameInvalid(boolean isInvalid, String message){
        if (isInvalid){
            nameField.setTooltip(new Tooltip(message));
            nameField.getStyleClass().add("invalid");
        }else{
            nameField.getStyleClass().remove("invalid");
        }
    }
    public void setEmailInvalid(boolean isInvalid, String message){
        if (isInvalid){
            emailField.setTooltip(new Tooltip(message));
            emailField.getStyleClass().add("invalid");
        }else{
            emailField.getStyleClass().remove("invalid");
        }
    }
    public void setPhoneInvalid(boolean isInvalid, String message){
        if (isInvalid){
            phoneField.setTooltip(new Tooltip(message));
            phoneField.getStyleClass().add("invalid");
        }else{
            phoneField.getStyleClass().remove("invalid");
        }
    }
    public void setMenuInvalid(boolean isInvalid, String message){
        if (isInvalid){
            menuField.setTooltip(new Tooltip(message));
            menuField.getStyleClass().add("invalid");
        }else{
            menuField.getStyleClass().remove("invalid");
        }
    }
    public void setCategoryInvalid(boolean isInvalid, String message){
        if (isInvalid){
            categoryCbBox.setTooltip(new Tooltip(message));
            categoryCbBox.getStyleClass().add("invalid");
        }else{
            categoryCbBox.getStyleClass().remove("invalid");
        }
    }
    public void setRoadNumberInvalid(boolean isInvalid, String message){
        if (isInvalid){
            roadNumberField.setTooltip(new Tooltip(message));
            roadNumberField.getStyleClass().add("invalid");
        }else{
            roadNumberField.getStyleClass().remove("invalid");
        }
    }
    public void setRoadNameInvalid(boolean isInvalid, String message){
        if (isInvalid){
            roadNameField.setTooltip(new Tooltip(message));
            roadNameField.getStyleClass().add("invalid");
        }else{
            roadNameField.getStyleClass().remove("invalid");
        }
    }
    public void setPostalCodeInvalid(boolean isInvalid, String message){
        if (isInvalid){
            postalCodeField.setTooltip(new Tooltip(message));
            postalCodeField.getStyleClass().add("invalid");
        }else{
            postalCodeField.getStyleClass().remove("invalid");
        }
    }
}
