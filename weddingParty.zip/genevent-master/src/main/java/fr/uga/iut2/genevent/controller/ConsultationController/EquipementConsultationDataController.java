package fr.uga.iut2.genevent.controller.ConsultationController;

import fr.uga.iut2.genevent.controller.DesignEquipment.EquipmentDesignController;
import fr.uga.iut2.genevent.controller.DesignLocation.LocationDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Equipment;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class EquipementConsultationDataController extends ConsultationDataController<Equipment> {

    @FXML
    private Label nameLabel, typeLabel, priceLabel, descriptionLabel, stockLabel, supplierLabel;


    public EquipementConsultationDataController(Equipment equipment){
        super(equipment);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        Equipment equipment = getConsultedObject();

        nameLabel.setText(equipment.getName());
        typeLabel.setText(String.valueOf(equipment.getCategoryEquipment()));
        priceLabel.setText(String.valueOf(equipment.getPrice()));
        descriptionLabel.setText(equipment.getDescription());
        stockLabel.setText(String.valueOf(equipment.getTotalStock()));
        supplierLabel.setText(equipment.getSupplier().getName());
    }

    @Override
    public String getFxmlPath() {
        return "/fr/uga/iut2/genevent/views/Consultation/Equipment/consultationEquipment.fxml";
    }

    @Override
    protected void edit(){
        EquipmentDesignController controller = new EquipmentDesignController(getConsultedObject());
        RootController.getPageManager().stepForward(
                new Page("Modification d'un materiel", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }
}
