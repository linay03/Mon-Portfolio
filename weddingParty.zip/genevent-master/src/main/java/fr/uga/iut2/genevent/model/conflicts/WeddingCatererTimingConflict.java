package fr.uga.iut2.genevent.model.conflicts;

import fr.uga.iut2.genevent.model.Caterer;
import fr.uga.iut2.genevent.model.Wedding;

import java.io.Serializable;

public class WeddingCatererTimingConflict extends Conflict implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private Caterer caterer;

    public WeddingCatererTimingConflict(Wedding wedding, Caterer caterer){
        super(wedding);
        this.caterer = caterer;
    }

    @Override
    public String conflictMessage() {
        return "ATTENTION : un traiteur n'est pas disponible à la date indiquée";
    }

}
