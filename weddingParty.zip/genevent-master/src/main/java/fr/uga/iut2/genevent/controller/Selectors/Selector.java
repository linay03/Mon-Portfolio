package fr.uga.iut2.genevent.controller.Selectors;

import fr.uga.iut2.genevent.model.Individual;

public class Selector<T> {
	
	
	private T object = null;
	private boolean isChanged = false;
	
	public T getObject() {
		return object;
	}
	public void setObject(T object) {
		this.object = object;
		isChanged = true;
	}
	
	public boolean isChanged() {
		return isChanged;
	}
	public void setChanged(boolean changed) {
		isChanged = changed;
	}
	
	public Selector(T object) {
		this.object = object;
	}
}
