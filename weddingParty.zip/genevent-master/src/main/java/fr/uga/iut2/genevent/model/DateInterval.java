package fr.uga.iut2.genevent.model;


import java.io.Serializable;
import java.util.Date;

/**
 * Cette classe représente la notion d'intervale de temps
 * Elle possède 2 attribtus :
 * startDate : Date de début de l'intervale (inclus)
 * endDate : Date de fin de l'interval (inclus)
 */
public class DateInterval implements Serializable {
    private Date startDate;
    private Date endDate;

    public DateInterval(Date startDate, Date endDate){
        setDateInterval(startDate, endDate);
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    /**
     * Méthode permettant de définir l'intervale de temps avec les contraintes selon lesquelles
     * les deux dates doivent etre non nulles
     * la date de fin doit etre supérieure ou égale à la date de début
     * @param startDate est la date de début de l'intervale
     * @param endDate est la date de fin de l'intervale
     */
    public void setDateInterval(Date startDate, Date endDate){
        if((startDate!=null && endDate!=null) && startDate.compareTo(endDate)<=0){
            this.startDate=startDate;
            this.endDate=endDate;
        }
    }

    /**
     * Méthode permettant de savoir si deux intervales de temps se croisent
     * @param dateInterval est une dateInterval avec laquelle on va comparer l'objet actuel
     * @return vrai si les deux dateInterval se croisent, faux sinon
     */
    public boolean overlap(DateInterval dateInterval) { // fonctionne comme le compareTo : on test cet Objet (this) par rapport à l'autre (param)
        if(this.startDate.compareTo(dateInterval.getStartDate()) < 0){
            return this.endDate.compareTo(dateInterval.getStartDate()) >= 0;
        }else if (this.startDate.compareTo(dateInterval.getStartDate()) > 0){
            return this.startDate.compareTo(dateInterval.getEndDate()) <= 0;
        }else {
            return true;
        }
    }


}
