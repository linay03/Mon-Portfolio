package fr.uga.iut2.genevent.controller.DesignSupplier;

import fr.uga.iut2.genevent.controller.DesignController;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Adresse;
import fr.uga.iut2.genevent.model.Owner;
import fr.uga.iut2.genevent.model.Supplier;
import javafx.event.ActionEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class SupplierDesignController extends DesignController<Supplier> {

    private SupplierDataController controller = new SupplierDataController();

    public SupplierDesignController(){
        super("Fournisseur");
    }
    public SupplierDesignController(Supplier editedObject){
        super("Fournisseur", editedObject);
        controller = new SupplierDataController(editedObject);
    }
    public SupplierDesignController(Selector<Supplier> selector){
        super(selector, "Fournisseur");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initializeCenter("/fr/uga/iut2/genevent/views/Design/DesignSupplier/designSupplier.fxml", controller);
    }

    @Override
    protected void save(ActionEvent event) {
        resetValidity();
        if (!checkValidity()){
            return;
        }

        String name = controller.getName();
        String email = controller.getEmail();
        String phone = controller.getPhone();
        Adresse adresse = controller.getAdresse();

        if(isEditMod()){
            getEditedObject().setName(name);
            getEditedObject().setMail(email);
            getEditedObject().setPhone(phone);
            getEditedObject().setAdress(adresse);

            RootController.logInfo("Modification d'un fournisseur");
            RootController.getPageManager().backtrack();
            RootController.getPageManager().backtrack();
        }
        else{
            Supplier newSupplier = new Supplier(name, phone, adresse, email);
            setNewObject(newSupplier); //L'objet créé est passé à super() pour être assigné au Selector lors d'un selection.

            RootController.getGenevent().newSupplier(newSupplier);

            RootController.logInfo("Création d'un nouveau fournisseur");
            RootController.getPageManager().backtrack();
        }
    }
    /**
     * Cette fonction permet de vérifier que tout les field sont replis et replis corréctement
     * @return
     */
    private boolean checkValidity(){
        boolean isValid = true;
        if(controller.getName().isBlank()){
            isValid = false;
            controller.setNameInvalid(true, "Le nom doit être renseigné");
        }
        if (controller.getEmail().isBlank()){
            isValid = false;
            controller.setEmailInvalid(true, "L'email doit être renseigné");
        }else if (!controller.getEmail().contains("@")){
            isValid = false;
            controller.setEmailInvalid(true, "L'email doit être du bon format");
        }
        if (controller.getPhone().isBlank()){
            isValid = false;
            controller.setPhoneInvalid(true, "Le numero de téléphone doit être reseigné");
        }else if (!controller.getPhone().matches("[0-9\\s]+")){
            isValid = false;
            controller.setPhoneInvalid(true, "Le numero de téléphone doit etre du bon format");
        }
        if (controller.getRoadNumber().isBlank()){
            isValid = false;
            controller.setRoadNumberInvalid(true, "Le numero de rue doit être renseigné");
        }
        if (controller.getRoadName().isBlank()){
            isValid = false;
            controller.setRoadNameInvalid(true, "Le nom de rue doit être renseigné");
        }
        if (controller.getPostalCode().isBlank()){
            isValid = false;
            controller.setPostalCodeInvalid(true, "Le code postal doit être renseigné");
        }else if (controller.getPostalCode().length() != 5 || controller.getPostalCode().length() != 5 && !controller.getPostalCode().matches("\\d+")){
            //si le code postal ne fait pas exatement 5 de long ou si le code postal ne fait pas exatement 5 de long et contien d'autre carractère que des chiffre
            isValid = false;
            controller.setPostalCodeInvalid(true, "le code postal doit être valid (5 chiffre uniquement)");
        }
        return isValid;
    }
    /**
     * cette fonction permet de restet le style de tout les champs a remplir.
     * Cette fonction toujours appeler avant checkValidity
     */
    private void resetValidity(){
        controller.setNameInvalid(false, null);
        controller.setEmailInvalid(false, null);
        controller.setPhoneInvalid(false, null);
        controller.setRoadNumberInvalid(false, null);
        controller.setRoadNameInvalid(false, null);
        controller.setPostalCodeInvalid(false, null);
    }
}
