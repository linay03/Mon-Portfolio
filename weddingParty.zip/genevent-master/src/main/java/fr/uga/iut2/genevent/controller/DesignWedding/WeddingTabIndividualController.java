package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.controller.IndividualSelectionController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Individual;
import fr.uga.iut2.genevent.model.Wedding;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;

public class WeddingTabIndividualController implements Initializable {
    @FXML
    private Label labelGroom1;
    @FXML
    private Label labelGroom2;
    @FXML
    private Label labelClient;
    @FXML
    private Label clientEmailLabel, groom1EmailLabel, groom2EmailLabel;

    private Wedding editedWedding;

    WeddingTabIndividualController(){}
    WeddingTabIndividualController(Wedding editedWedding){
        this.editedWedding = editedWedding;
    }

    //Les objects de selections passé en paramètres lors de la selection, la valeur de getObject() est de type Individual.
    private Selector<Individual> clientSelector = new Selector<>(null),
            groom1Selector = new Selector<>(null),
            groom2Selector = new Selector<>(null);
    
    public Individual getClient() {
        return clientSelector.getObject();
    }
    public Individual getGroom1() {
        return groom1Selector.getObject();
    }
    public Individual getGroom2() {
        return groom2Selector.getObject();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        labelGroom1.setText("");
        labelGroom2.setText("");
        labelClient.setText("");
        clientEmailLabel.setText("");
        groom1EmailLabel.setText("");
        groom2EmailLabel.setText("");

        //Si en mode edition, set les fields aux valeurs de l'objet
        if(editedWedding != null){
            clientSelector.setObject(editedWedding.getClient());
            groom1Selector.setObject(editedWedding.getGroomA());
            groom2Selector.setObject(editedWedding.getGroomB());
            updateLabels();
        }
    }

    @FXML
    private void selectGroom1(ActionEvent event){
        //Liste des individus qui devront apparaitre en grisé dans la liste de selection
        ArrayList<Individual> unavailable = new ArrayList<>(Collections.singletonList( groom2Selector.getObject()));
        
        groom1Selector.setChanged(false);
        
        //Avance vers la page de selection pour selection groom1.
        IndividualSelectionController controller = new IndividualSelectionController(groom1Selector, unavailable);
        RootController.getPageManager().stepForward(
                new Page("Selection de marié(e) 1", "/fr/uga/iut2/genevent/views/Base/list.fxml",
                        controller, true)
        );
    }
    @FXML
    private void selectGroom2(ActionEvent event){
        //Liste des individus qui devront apparaitre en grisé dans la liste de selection
        ArrayList<Individual> unavailable = new ArrayList<>(Collections.singletonList( groom1Selector.getObject()));
    
        groom2Selector.setChanged(false);
        //Avance vers la page de selection pour selection groom1.
        IndividualSelectionController controller = new IndividualSelectionController(groom2Selector, unavailable);
        RootController.getPageManager().stepForward(
                new Page("Selection de marié(e) 2", "/fr/uga/iut2/genevent/views/Base/list.fxml",
                        controller, true)
        );
    }
    @FXML
    private void selectClient(ActionEvent event){
        clientSelector.setChanged(false);
        //Avance vers la page de selection pour selection groom1.
        IndividualSelectionController controller = new IndividualSelectionController(clientSelector, new ArrayList<>());
        RootController.getPageManager().stepForward(
                new Page("Selection du client", "/fr/uga/iut2/genevent/views/Base/list.fxml",
                        controller, true)
        );
    }
    
    public void updateLabels(){
        Individual groom1 = groom1Selector.getObject();
        Individual groom2 = groom2Selector.getObject();
        Individual client = clientSelector.getObject();
        
        if(groom1 != null){
            labelGroom1.setText(groom1.getFirstName() + " " + groom1.getName());
            groom1EmailLabel.setText(groom1.getMail());
        }
        if(groom2 != null){
            labelGroom2.setText(groom2.getFirstName() + " " + groom2.getName());
            groom2EmailLabel.setText(groom2.getMail());
        }
        if(client != null){
            labelClient.setText(client.getFirstName() + " " + client.getName());
            clientEmailLabel.setText(client.getMail());
        }
    }
    /**
     * si isInvalid est true on met le style invalid au fied qu'il faut remplir
     * et on ajout un message qui apparait lorsque l'on survole le field
     * @param isInvalid
     */
    public void setGroom1Invalid(boolean isInvalid){
        if (isInvalid){
            labelGroom1.getParent().getStyleClass().add("invalid");
        }else{
            labelGroom1.getParent().getStyleClass().remove("invalid");
        }
    }

    public void setGroom2Invalid(boolean isInvalid){
        if (isInvalid){
            labelGroom2.getParent().getStyleClass().add("invalid");
        }else{
            labelGroom2.getParent().getStyleClass().remove("invalid");
        }
    }

    public void setClientInvalid(boolean isInvalid){
        if (isInvalid){
            clientEmailLabel.getParent().getStyleClass().add("invalid");
        }else{
            clientEmailLabel.getParent().getStyleClass().remove("invalid");
        }
    }

}
