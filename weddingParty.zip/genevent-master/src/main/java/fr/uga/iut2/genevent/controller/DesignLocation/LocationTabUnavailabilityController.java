package fr.uga.iut2.genevent.controller.DesignLocation;

import fr.uga.iut2.genevent.model.DateInterval;
import fr.uga.iut2.genevent.model.Location;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

public class LocationTabUnavailabilityController implements Initializable {
	
	@FXML
	private DatePicker startDatePicker, endDatePicker;
	@FXML
	private Label errorLabel;
	@FXML
	private ScrollPane scrollPane;
	@FXML
	private VBox content;
	
	private ArrayList<UnavailibilityItemController> unavailibilityItemControllers = new ArrayList<>();

	private Location editedLocation;

	LocationTabUnavailabilityController(){}

	public LocationTabUnavailabilityController(Location editedLocation){
		this.editedLocation = editedLocation;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		//Si en mode édition, initialise les field aux valeur de l'object
		errorLabel.setText("");
		if(editedLocation != null){

			for (DateInterval dateInterval : editedLocation.getUnavailability()){

				LocalDate startDate = dateInterval.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				LocalDate endDate = dateInterval.getEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

				addDateItem(startDate, endDate);
			}
		}
	}

	@FXML
	private void validate(ActionEvent event){
		clearInvalid();
		if(startDatePicker.getValue() == null && endDatePicker.getValue() == null){
			setInvalid();
			setMessage("Renseigner la date");
			return;
		}
		if(startDatePicker.getValue().isAfter( endDatePicker.getValue() )){
			setInvalid();
			errorLabel.setText("La date de fin est avant la date de début");
			return;
		}

		LocalDate startDate = startDatePicker.getValue();
		LocalDate endDate = endDatePicker.getValue();

		addDateItem(startDate, endDate);

		startDatePicker.setValue(null);
		endDatePicker.setValue(null);
	}

	private void addDateItem(LocalDate startDate, LocalDate endDate) {
		GridPane item;
		try{
			UnavailibilityItemController controller = new UnavailibilityItemController(startDate, endDate, this);
			FXMLLoader itemLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/views/Design/DesignLocation/designLocationUnavailabilityItem.fxml"));
			itemLoader.setController(controller);
			item = itemLoader.load();

			unavailibilityItemControllers.add(controller);
			content.getChildren().add(item);

		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	public void removeItem(GridPane itemGrid, UnavailibilityItemController controller){
		content.getChildren().remove(itemGrid);
		unavailibilityItemControllers.remove(controller);
	}
	
	public ArrayList<DateInterval> getUnavailabilities(){
		
		ArrayList<DateInterval> unavailabilities = new ArrayList<>();
		
		for( UnavailibilityItemController itemController : unavailibilityItemControllers){
			
			DateInterval newDateInterval = new DateInterval(itemController.getStarDate(), itemController.getEndDate());
			unavailabilities.add(newDateInterval);
		}
		return unavailabilities;
	}
	public void setInvalid(){
		startDatePicker.getStyleClass().add("invalid");
		endDatePicker.getStyleClass().add("invalid");
	}

	public void setMessage(String message){
		startDatePicker.setTooltip(new Tooltip(message));
		endDatePicker.setTooltip(new Tooltip(message));
	}

	public void clearInvalid(){
		startDatePicker.getStyleClass().remove("invalid");
		endDatePicker.getStyleClass().remove("invalid");
		errorLabel.setText("");
	}
}
