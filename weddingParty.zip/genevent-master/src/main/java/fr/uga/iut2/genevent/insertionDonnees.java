package fr.uga.iut2.genevent;

import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.exceptions.AdresseInvalideException;
import fr.uga.iut2.genevent.model.*;
import fr.uga.iut2.genevent.util.StringUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.*;

public class insertionDonnees {

    private static Logger LOGGER = Logger.getLogger(insertionDonnees.class.getPackageName());
    public static void initialisation() throws AdresseInvalideException {

        // Creation adresses

        // Rue des chevaux

        Adresse adresse1 = new Adresse("1", "rue des chevaux", "38000");
        Adresse adresse2 = new Adresse("2", "rue des chevaux", "38000");
        Adresse adresse3 = new Adresse("3", "rue des chevaux", "38000");
        Adresse adresse4 = new Adresse("4", "rue des chevaux", "38000");
        Adresse adresse5 = new Adresse("5", "rue des chevaux", "38000");
        Adresse adresse6 = new Adresse("6", "rue des chevaux", "38000");
        Adresse adresse7 = new Adresse("7", "rue des chevaux", "38000");
        Adresse adresse8 = new Adresse("8", "rue des chevaux", "38000");
        Adresse adresse9 = new Adresse("9", "rue des chevaux", "38000");
        Adresse adresse10 = new Adresse("10", "rue des chevaux", "38000");

        // Rue des poneys
        Adresse adresse11 = new Adresse("101", "rue des poneys", "38000");
        Adresse adresse12 = new Adresse("102", "rue des poneys", "38000");
        Adresse adresse13 = new Adresse("103", "rue des poneys", "38000");
        Adresse adresse14 = new Adresse("104", "rue des poneys", "38000");
        Adresse adresse15 = new Adresse("105", "rue des poneys", "38000");
        Adresse adresse16 = new Adresse("106", "rue des poneys", "38000");
        Adresse adresse17 = new Adresse("107", "rue des poneys", "38000");
        Adresse adresse18 = new Adresse("108", "rue des poneys", "38000");
        Adresse adresse19 = new Adresse("109", "rue des poneys", "38000");
        Adresse adresse20 = new Adresse("104", "rue des poneys", "38000");
        Adresse adresse21 = new Adresse("105", "rue des poneys", "38000");
        Adresse adresse22 = new Adresse("106", "rue des poneys", "38000");
        Adresse adresse23 = new Adresse("107", "rue des poneys", "38000");
        Adresse adresse24 = new Adresse("108", "rue des poneys", "38000");
        Adresse adresse25 = new Adresse("109", "rue des poneys", "38000");
        Adresse adresse26 = new Adresse("26", "rue des poneys", "38000");
        Adresse adresse27 = new Adresse("27", "rue des poneys", "38000");
        Adresse adresse28 = new Adresse("28", "rue des poneys", "38000");
        Adresse adresse29 = new Adresse("29", "rue des poneys", "38000");
        Adresse adresse30 = new Adresse("30", "rue des poneys", "38000");
        Adresse adresse31 = new Adresse("31", "rue des poneys", "38000");
        Adresse adresse32 = new Adresse("32", "rue des poneys", "38000");
        Adresse adresse33 = new Adresse("33", "rue des poneys", "38000");
        Adresse adresse34 = new Adresse("34", "rue des poneys", "38000");
        Adresse adresse35 = new Adresse("35", "rue des poneys", "38000");
        Adresse adresse36 = new Adresse("36", "rue des poneys", "38000");
        Adresse adresse37 = new Adresse("37", "rue des poneys", "38000");
        Adresse adresse38 = new Adresse("38", "rue des poneys", "38000");
        Adresse adresse39 = new Adresse("39", "rue des poneys", "38000");
        Adresse adresse40 = new Adresse("40", "rue des poneys", "38000");
        Adresse adresse41 = new Adresse("41", "rue des poneys", "38000");
        Adresse adresse42 = new Adresse("42", "rue des poneys", "38000");
        Adresse adresse43 = new Adresse("43", "rue des poneys", "38000");
        Adresse adresse44 = new Adresse("44", "rue des poneys", "38000");
        Adresse adresse45 = new Adresse("45", "rue des poneys", "38000");
        Adresse adresse46 = new Adresse("46", "rue des poneys", "38000");
        Adresse adresse47 = new Adresse("41", "rue des poneys", "38000");
        Adresse adresse48 = new Adresse("42", "rue des poneys", "38000");
        Adresse adresse49 = new Adresse("43", "rue des poneys", "38000");
        Adresse adresse50 = new Adresse("44", "rue des poneys", "38000");
        Adresse adresse51 = new Adresse("45", "rue des poneys", "38000");
        Adresse adresse52 = new Adresse("46", "rue des poneys", "38000");


        // Creation de traiteur
        Caterer caterer1 = new Caterer("Le palais Royal", "mix asiatique", CatererCategory.Mixte,
                "06 12 96 67 87", adresse1, "lepalaisroyal@gmailcom");

        Caterer caterer2 = new Caterer("Le bon pain", "pain", CatererCategory.Francais,
                "06 12 96 67 90", adresse2, "lebonpain@gmailcom");

        Caterer caterer3 = new Caterer("Les bonnes viennoiseries", "viennoiserie", CatererCategory.Francais,
                "07 60 30 64 13", adresse3, "lesbonnesviennoiseries@gmailcom");

        Caterer caterer4 = new Caterer("Les oeufs parfaits", "oeufs molets", CatererCategory.Francais,
                "06 52 82 01 18", adresse4, "lesbonnesviennoiseries@gmailcom");

        Caterer caterer5 = new Caterer("Good food", "fish and chips", CatererCategory.Anglais,
                "06 23 61 54 10", adresse5, "goodfood@gmailcom");

        Caterer caterer6 = new Caterer("Paul", "viennoiserie", CatererCategory.Francais,
                "07 71 16 27 80", adresse6, "paul@gmailcom");

        Caterer caterer7 = new Caterer("Le bon poulet", "Poulet Yassa", CatererCategory.Africain,
                "06 05 84 98 05", adresse7, "lebonpoulet@gmailcom");

        Caterer caterer8 = new Caterer("Gusto Taco", "Tacos frites", CatererCategory.Mexicain,
                "07 68 88 77 99", adresse8, "gustotacos@gmailcom");

        Caterer caterer9 = new Caterer("Jungsik", "Menu boeuf", CatererCategory.Coreen,
                "06 12 95 87 90", adresse9, "jungsik@gmailcom");

        ArrayList<Caterer> caterers = new ArrayList<>(Arrays.asList(caterer7,caterer4,caterer5,caterer6,caterer8,caterer9,caterer1,caterer2,caterer3));
        for (Caterer caterer : caterers){
            RootController.getGenevent().newCaterer(caterer);
        }
        // Creation de particuliers
        Individual individual1 = new Individual("Veno","Pol", new Date(2004,02,15),
                "07 76 65 B5 4B", adresse10,"Pol.veno@gmail.com");

        Individual individual2 = new Individual("Dupont", "Jean", new Date(1990, 5, 10),
                "06 12 34 56 78", adresse11, "jean.dupont@gmail.com");

        Individual individual3 = new Individual("Martin", "Sophie", new Date(1985, 8, 20),
                "06 98 76 54 32", adresse12, "sophie.martin@gmail.com");

        Individual individual5 = new Individual("Martin", "Emma", new Date(1998, 4, 18),
                "06 54 32 10 98", adresse13, "emma.martin@gmail.com");

        Individual individual6 = new Individual("Garcia", "Lucas", new Date(1992, 11, 30),
                "07 12 34 56 78", adresse14, "lucas.garcia@gmail.com");

        Individual individual7 = new Individual("Lefebvre", "Chloé", new Date(2000, 8, 22),
                "06 78 90 12 34", adresse15, "chloe.lefebvre@gmail.com");

        Individual individual8 = new Individual("Leroy", "Manon", new Date(1997, 6, 5),
                "07 98 76 54 32", adresse16, "manon.leroy@gmail.com");

        Individual individual9 = new Individual("Roux", "Hugo", new Date(1993, 1, 16),
                "06 56 78 90 12", adresse17, "hugo.roux@gmail.com");

        Individual individual10 = new Individual("Michel", "Léa", new Date(1991, 10, 28),
                "07 23 45 67 89", adresse18, "lea.michel@gmail.com");

        Individual individual11 = new Individual("Lopez", "Mathis", new Date(2002, 3, 9),
                "06 87 65 43 21", adresse19, "mathis.lopez@gmail.com");

        Individual individual12 = new Individual("Fournier", "Lola", new Date(1999, 12, 1),
                "07 54 32 10 98", adresse20, "lola.fournier@gmail.com");

        Individual individual13 = new Individual("Moreau", "Adam", new Date(1996, 9, 14),
                "06 32 10 98 76", adresse21, "adam.moreau@gmail.com");

        Individual individual14 = new Individual("Girard", "Alice", new Date(1994, 7, 27),
                "07 90 12 34 56", adresse22, "alice.girard@gmail.com");

        Individual individual15 = new Individual("Lemoine", "Noah", new Date(2001, 2, 8),
                "06 78 90 12 34", adresse23, "noah.lemoine@gmail.com");

        Individual individual16 = new Individual("Oipato", "Naim", new Date(2002, 2, 8),
                "06 78 90 12 34", adresse24, "naim.oipato@gmail.com");


        ArrayList<Individual> individuals = new ArrayList<>(Arrays.asList(individual1, individual2, individual3, individual14,  individual5, individual6
        ,individual7, individual8, individual9, individual10, individual11, individual12, individual13, individual14, individual15, individual16));

        for (Individual individual : individuals){
            RootController.getGenevent().newIndividual(individual);
        }

        // Creation de propriéatire (entreprise), prenom étant null
        Owner owner2 = new Owner("Entreprise A", "06 12 34 56 78", adresse25, "entreprisea@gmail.com");
        Owner owner3 = new Owner("Entreprise B", "07 23 45 67 89", adresse26, "entrepriseb@gmail.com");
        Owner owner4 = new Owner("Entreprise C", "06 98 76 54 32", adresse27, "entreprisec@gmail.com");
        Owner owner5 = new Owner("Entreprise D", "07 87 65 43 21", adresse28, "entreprised@gmail.com");
        Owner owner6 = new Owner("Entreprise E", "06 54 32 10 98", adresse29, "entreprisef@gmail.com");
        Owner owner7 = new Owner("Entreprise F", "07 43 21 09 87", adresse30, "entrepriseg@gmail.com");
        Owner owner8 = new Owner("Entreprise G", "06 90 78 56 34", adresse31, "entrepriseg@gmail.com");
        Owner owner9 = new Owner("Entreprise H", "07 56 34 12 90", adresse32, "entrepriseh@gmail.com");
        Owner owner10 = new Owner("Entreprise I", "06 78 56 34 12", adresse33, "entreprisei@gmail.com");


        // Creation de propriétaire (particulier), prenom n'est donc plus null
        Owner owner11 = new Owner("Dupont", "Jean", "06 12 34 56 78", adresse34, "dupont@gmail.com");
        Owner owner12 = new Owner("Martin", "Pierre", "07 23 45 67 89", adresse35, "martin@gmail.com");
        Owner owner13 = new Owner("Dubois", "Jacques", "06 98 76 54 32", adresse36, "dubois@gmail.com");
        Owner owner14 = new Owner("Lefebvre", "Paul", "07 87 65 43 21", adresse37, "lefebvre@gmail.com");
        Owner owner15 = new Owner("Roux", "Marc", "06 54 32 10 98", adresse38, "roux@gmail.com");
        Owner owner16 = new Owner("Garcia", "Philippe", "07 43 21 09 87", adresse39, "garcia@gmail.com");
        Owner owner17 = new Owner("Dufour", "Sylvie", "06 90 78 56 34", adresse40, "dufour@gmail.com");
        Owner owner18 = new Owner("Lopez", "Isabelle", "07 56 34 12 90", adresse41, "lopez@gmail.com");
        Owner owner19 = new Owner("Moreau", "Christophe", "06 78 56 34 12", adresse42, "moreau@gmail.com");

        ArrayList<Owner> owners = new ArrayList<>(Arrays.asList(owner2,owner3,owner4, owner5,owner6,owner7,owner8,owner9,owner10,owner11,
                owner12,owner13,owner14,owner15,owner15,owner16,owner17,owner18,owner19));

        for (Owner owner : owners){
            RootController.getGenevent().newOwner(owner);
        }

        // Creation de lieux
        Location location1 = new Location("Le palais des arbres", adresse43,150,167,owner2,
                    4000,InteriorExterior.Exterieur,"",new ArrayList<DateInterval>());


        Location location2 = new Location("Grand chateau", adresse44,150,167,owner2,
                    40000,InteriorExterior.Exterieur,"",new ArrayList<DateInterval>());



        /*DateInterval dateInterval1 = new DateInterval(new Date(2023,11,27),new Date(2023,11,29));
        DateInterval dateInterval2 = new DateInterval(new Date(2024,11,27),new Date(2024,11,29));
        Location location3 = new Location("Petite cabane dans les bois", adresse45,5,20,owner3,
                    200,InteriorExterior.Exterieur,"",new ArrayList<DateInterval>(Arrays.asList(dateInterval1,dateInterval2)));*/

        ArrayList<Location> locations = new ArrayList<>(Arrays.asList(location2,location1));

        for (Location location : locations){
            RootController.getGenevent().newLocation(location);
        }

        // Creation de fournisseurs
        Supplier supplier1 = new Supplier("Meubles de Luxe", "06 87 28 77 88", adresse46, "meublesdeluxe@gmail.com");
        Supplier supplier2 = new Supplier("Argenterie rare", "07 87 28 77 88", adresse47, "argenterierare@gmail.com");

        ArrayList<Supplier> suppliers = new ArrayList<>(Arrays.asList(supplier1,supplier2));

        for (Supplier supplier : suppliers){
            RootController.getGenevent().newSupplier(supplier);
        }

        // Creation de materiel
        Equipment equipment1 = new Equipment("chaise","chaise en bois de chêne", 20,
                2000,CategorieMateriel.Meubles,supplier1);

        Equipment equipment2 = new Equipment("banc","banc en pierre", 90,
                2000,CategorieMateriel.Meubles,supplier1);

        Equipment equipment3 = new Equipment("fourchette","fourchette en platine", 100,
                2000,CategorieMateriel.Argenterie,supplier2);

        Equipment equipment4 = new Equipment("couteau","couteau en platine", 100,
                2000,CategorieMateriel.Argenterie,supplier2);

        Equipment equipment5 = new Equipment("assiette","assiette en procelaine", 5,
                2000,CategorieMateriel.Argenterie,supplier2);

        Equipment equipment6 = new Equipment("assiette","assiette en carton", 1,
                2000,CategorieMateriel.Argenterie,supplier2);

        Equipment equipment7 = new Equipment("fourchette","fourchette en carton", 1,
                2000,CategorieMateriel.Argenterie,supplier2);

        Equipment equipment8 = new Equipment("couteau","couteau en carton", 1,
                2000,CategorieMateriel.Argenterie,supplier2);


        ArrayList<Equipment> equipments = new ArrayList<>(Arrays.asList(equipment1,equipment2,equipment3,equipment4,equipment5,
                equipment6,equipment7,equipment8));
        for (Equipment equipment : equipments){
            RootController.getGenevent().newEquipment(equipment);
        }


        // Creation Mariage
        Wedding wedding1 = new Wedding(individual1, individual1, individual2,new Date(2023,6,26), new Date(2023,6,27)
        ,new ArrayList<Location>(Arrays.asList(location1, location2)), new ArrayList<Caterer>(Arrays.asList(caterer1,caterer2)), 50,"");

        Wedding wedding2 = new Wedding(individual1, individual3,individual5,new Date(2024,6,26), new Date(2024,6,27)
                ,new ArrayList<Location>(Arrays.asList(location1, location2)), new ArrayList<Caterer>(Arrays.asList(caterer1,caterer2)), 50,"");

       // Creaton EquipmentOrder (demande/commande de matériel)
        EquipmentOrder equipmentOrder1 = new EquipmentOrder(equipment4, 1000,wedding1);
        EquipmentOrder equipmentOrder2 = new EquipmentOrder(equipment5, 1000,wedding1);


        EquipmentOrder equipmentOrder3 = new EquipmentOrder(equipment5, 1900,wedding2);
        EquipmentOrder equipmentOrder4 = new EquipmentOrder(equipment8, 100, wedding2);



        wedding1.setEquipments(new ArrayList<>(Arrays.asList(equipmentOrder1,equipmentOrder2)));
        wedding2.setEquipments(new ArrayList<>(Arrays.asList(equipmentOrder3,equipmentOrder4)));


        RootController.getGenevent().newWedding(wedding1);
        RootController.getGenevent().newWedding(wedding2);
    }

}
