package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.ConsultationController.WeddingConsultationDataController;
import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.conflicts.WeddingCatererTimingConflict;
import fr.uga.iut2.genevent.model.conflicts.WeddingEquipmentStockConflict;
import fr.uga.iut2.genevent.model.conflicts.WeddingLocationCapacityConflict;
import fr.uga.iut2.genevent.model.conflicts.WeddingLocationTimingConflict;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

/**
 * Classe qui représente les mariages.
 * Un mariage possède :
 * - un client
 * - dateInterval : la ou les dates de reservations du mariage
 * - MarieA : reseignement du marie(e) 1
 * - MarieB : renseignement du marie(e) 2
 * - locations : liste de tous les lieux enregistrés pour le mariage.
 * - caterers : liste de tous les traiteurs enregistrés pour le mariage.
 * - equipmentOrders : liste de toutes les demandes de matériel enregistrées pour le mariage.
 * - guestNb : le nombre d'invités
 * - details : les spécifications pour le mariage
 */
public class Wedding implements Serializable, DirectoryItem<Wedding> {
	
	private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation

	private Individual client;

	private DateInterval dateInterval;

	private Individual MarieA;

	private Individual MarieB;

	private ArrayList<Location> locations = new ArrayList<>();

	private ArrayList<Caterer> caterers = new ArrayList<>();

	private ArrayList<EquipmentOrder> equipmentOrders = new ArrayList<>();
	private int guestNb;

	private String details;

	public Wedding(Individual client, Individual marieA, Individual marieB){
		this.client = client;
		this.MarieA =marieA;
		this.MarieB =marieB;
		setGuestNb(0);
	}

	public Wedding(Individual client, Individual marieA, Individual marieB, Date startDate,Date endDate){
		this.client = client;
		this.MarieA =marieA;
		this.MarieB =marieB;
		this.dateInterval = new DateInterval(startDate,endDate);
		setGuestNb(0);
	}

	public Wedding(Individual client, Individual marieA, Individual marieB,Date startDate,Date endDate,
				   ArrayList<Location> locations, ArrayList<Caterer> caterers,
				   int guestNb, String details) {
		this.client = client;
		this.MarieA =marieA;
		this.MarieB =marieB;
		this.dateInterval = new DateInterval(startDate,endDate);
		setLocations(locations);
		setCaterers(caterers);
		setGuestNb(guestNb);
		this.details = details;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	//Implémentation de DirectoryItem
	@Override
	public ItemFieldInfos getItemFieldInfo() {
		return new ItemFieldInfos(20, 30, 10, 10,
				getClient().getName(), getLocations().get(0).getName(), getDetails(), String.valueOf(getGuestNb()));
	}
	@Override
	public ConsultationDataController<Wedding> getConsultationDataController() {
		return new WeddingConsultationDataController(this);
	}
	@Override
	public String getElementName() {
		return "mariage";
	}

	//Getters & Setters
	//Client
	public Individual getClient() {
		return client;
	}

	public Individual getGroomA() {
		return MarieA;
	}

	public Individual getGroomB() {
		return MarieB;
	}

	public void setClient(Individual client) {
		this.client = client;
	}

	//Date
	public DateInterval getDateInterval() {
		return dateInterval;
	}

	public void setDateInterval(DateInterval date) {
		this.dateInterval = date;
	}


	//Locations
	public ArrayList<Location> getLocations() {
		return locations;
	}

	public void setGroomA(Individual marieA) {
		MarieA = marieA;
	}

	public void setGroomB(Individual marieB) {
		MarieB = marieB;
	}

	/**
	 * Affiche les locations enregistrés
	 * @return
	 */
	/*public String getLocationsAffichage() {
		String list = "";
		for (Location location: locations){
			list +=location.getName()+" - ";
		}
		return list;
	}*/
	
	public void setLocations(ArrayList<Location> locations) {
		this.locations = locations;
	}

	// Suppose Location non null
	public void addLocation(Location location){
		if (guestNb > location.getCapacity()) {
			WeddingLocationCapacityConflict weddingLocationCapacityConflict = new WeddingLocationCapacityConflict(this, location);
			//ajouter à genevent
			throw new IllegalArgumentException();
		}
		if (location.isIntervalReserved(this.dateInterval)){
			WeddingLocationTimingConflict weddingLocationTimingConflict = new WeddingLocationTimingConflict(this,location);
			//ajouter à genevent
			throw new IllegalArgumentException();
			} else {
			location.addWeddingsReserved(this);
		}
		this.locations.add(location);
	}

	public boolean containsLocation(Location location){
		return this.locations.contains(location);
	}

	//Caterer
	public ArrayList<Caterer> getCaterers() {
		return caterers;
	}

	/**
	 * Affiche les traiteurs enregistrés
	 * @return
	 */
	public String getCaterersAffichage(){
		StringBuilder list = new StringBuilder();
		for (Caterer caterer: caterers){
			list.append(caterer.getCompanyName());
		}
		return list.toString();
	}

	public void setCaterers(ArrayList<Caterer> caterers) {
		this.caterers.clear();
		for(Caterer caterer : caterers){
			this.addCaterer(caterer);
		}
	}

	public void addCaterer(Caterer caterer){
		if (caterer!=null && !this.containsCaterer(caterer) && (!caterer.isIntervalReserved(this) && !caterer.isOthersReserved(this.getDateInterval()))){
			this.caterers.add(caterer);
			WeddingCatererTimingConflict weddingCatererTimingConflict = new WeddingCatererTimingConflict(this,caterer);
			//ajouter à genevent
			if (!caterer.isWeddingReservedFor(this)){
				caterer.addWedding(this);
			}
		}
	}

	//Equipment
	public ArrayList<EquipmentOrder> getEquipmentOrders() {
		return equipmentOrders;
	}

	public String getEquipementAffichage(){
		String list = "";
		for (EquipmentOrder equipment: equipmentOrders){
			list +=equipment.getEquipment().getName()+"";
		}
		return list;
	}

	public void setEquipments(ArrayList<EquipmentOrder> equipmentOrders) {
		for (EquipmentOrder equipmentOrder : equipmentOrders){
			addEquipmentOrder(equipmentOrder.getEquipment(),equipmentOrder.getAmount());
		}
}

	/**
	 * Méthode qui créer une demande de matériel lors de l'ajout d'un matériel dans un mariage.
	 * La quantité du matériel est à renseigner. Si la quantité demandée n'est pas disponible dans
	 * les stocks, la demande ne sera pas prise en compte.
	 * @param equipment
	 * @param amount
	 */
	public void addEquipmentOrder(Equipment equipment,int amount){
		EquipmentOrder equipmentOrder = new EquipmentOrder(equipment,amount,this);
		if (equipmentOrder.getAmount() > equipment.getCurrentStock(equipmentOrder)){
			WeddingEquipmentStockConflict weddingEquipmentStockConflict = new WeddingEquipmentStockConflict(this,equipment);
		}
		this.equipmentOrders.add(equipmentOrder);
		equipmentOrder.addEquipmentWedding();
	}
	//Guest number
	public int getGuestNb() {
		return guestNb;
	}

	public void setGuestNb(int nbInviteTotal) {
		if (guestNb >= 0){
			this.guestNb = nbInviteTotal;
		} else {
			throw new IllegalArgumentException("La valeur entrée doit être positive");
		}
	}

	/**
	 * Verifie si un traiteur précis est défini pour ce mariage
	 * @param caterer est le traiteur duquel on verifie la présence
	 * @return vrai si le traiteur est défini pour ce mariage, faux sinon
	 */
	public boolean containsCaterer(Caterer caterer){
		if (caterers.contains(caterer)){
			return true;
		}else {
			return false;
		}
	}

	/**
	 * Methode qui retire un traiteur pour un mariage
	 * @param caterer
	 */
	public void removeCaterer(Caterer caterer){
		if(this.containsCaterer(caterer)){
			this.caterers.remove(caterer);
			if(caterer.isWeddingReservedFor(this)){
				caterer.removeWedding(this);
			}
		}
	}

	/**
	 * Méthode permet d'avoir la liste des lieux non disponible pour un interval de temps donné.
	 * @param dateInterval
	 * @return
	 */
	public static ArrayList<Location> getLocationNotAvailable(DateInterval dateInterval){
		Set<Location> genLocation = RootController.getGenevent().getLocations();
		ArrayList<Location> unavailableLocations = new ArrayList<>();
		for (Location location : genLocation){
			if (location.isIntervalReserved(dateInterval)){
				unavailableLocations.add(location);
			}
		}
		return unavailableLocations;
	}
}
