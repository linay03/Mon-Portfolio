package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.controller.DesignLocation.UnavailibilityItemController;
import fr.uga.iut2.genevent.controller.LocationSelectionController;
import fr.uga.iut2.genevent.controller.OwnerSelectionController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.controller.Selectors.Selector;
import fr.uga.iut2.genevent.model.Caterer;
import fr.uga.iut2.genevent.model.DateInterval;
import fr.uga.iut2.genevent.model.Location;
import fr.uga.iut2.genevent.model.Wedding;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.ResourceBundle;

public class WeddingTabDateLocationController implements Initializable {
    @FXML
    private DatePicker startDatePicker, endDatePicker;
    @FXML
    private ScrollPane scrollPane;
    @FXML
    private VBox content;
    @FXML
    private Button selectionLocationButton;

    private ArrayList<SelectedLocationItemController> locationSelectionControllers = new ArrayList<>();

    private Wedding editedWedding;


    WeddingTabDateLocationController(){}
    WeddingTabDateLocationController(Wedding editedWedding){
        this.editedWedding = editedWedding;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        if(editedWedding != null){
            startDatePicker.setValue( editedWedding.getDateInterval().getStartDate().toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate());
            endDatePicker.setValue( editedWedding.getDateInterval().getEndDate().toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate());

            for (Location location : editedWedding.getLocations()){
                locationSelectionControllers.add( new SelectedLocationItemController(this, new Selector<>(location)) );
                updateSelectionList();
            }
            updateSelectionList();
        }
    }

    private Date getStartDate(){
        if (startDatePicker.getValue() == null){
            return null;
        }
        ZoneId defaultZoneId = ZoneId.systemDefault();
        return Date.from(startDatePicker.getValue().atStartOfDay(defaultZoneId).toInstant());
    }
    private Date getEndDate(){
        if (endDatePicker.getValue() == null){
            return null;
        }
        ZoneId defaultZoneId = ZoneId.systemDefault();
        return Date.from(endDatePicker.getValue().atStartOfDay(defaultZoneId).toInstant());
    }
    public DateInterval getDateInterval(){
        return new DateInterval(getStartDate(), getEndDate());
    }
    public ArrayList<Location> getLocations(){
        ArrayList<Location> locations = new ArrayList<>();
        for (SelectedLocationItemController item : locationSelectionControllers){
            locations.add( item.getLocationSelector().getObject() );
        }
        return locations;
    }

    @FXML
    private void pickStartDate(){
        //Set la deuxième date à la première si elle est avant la première ou si elle est vide
        if(endDatePicker.getValue() == null || getEndDate().before( getStartDate() )){
            endDatePicker.setValue(startDatePicker.getValue());
        }

        //Désactive les dates avant la première date
        endDatePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                LocalDate startDate = startDatePicker.getValue();

                setDisable(empty || date.isBefore(startDate));
            }
        });
    }
    @FXML
    private void pickEndDate(ActionEvent event){
        //Set le premier datePicker à la même value si il est vide
        if(startDatePicker.getValue() == null){
            startDatePicker.setValue( endDatePicker.getValue() );
        }
    }

    @FXML
    private void selectMore(ActionEvent event){
        Selector<Location> newLocationSelector = new Selector<>(null);
        locationSelectionControllers.add( new SelectedLocationItemController(this, newLocationSelector) );

        ArrayList<Location> unavailable = Wedding.getLocationNotAvailable(getDateInterval());
        for (SelectedLocationItemController itemController : locationSelectionControllers){
            unavailable.add( itemController.getLocationSelector().getObject() );
        }

        //Avance vers la page de selection pour selection location. Aucun est indisponible.
        LocationSelectionController controller = new LocationSelectionController(newLocationSelector, unavailable);
        RootController.getPageManager().stepForward(
                new Page("Selection d'un lieu", "/fr/uga/iut2/genevent/views/Base/list.fxml",
                        controller, true)
        );
    }

    public void updateSelectionList(){
        //Supprime tous les éléments existant
        content.getChildren().clear();

        //Ajoute les éléments de la liste
        Iterator<SelectedLocationItemController> iterator = locationSelectionControllers.iterator();
        while (iterator.hasNext()){
            SelectedLocationItemController current = iterator.next();

            if(current.getLocationSelector().getObject() == null){
                iterator.remove();
                continue;
            }

            Pane item;
            try{
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingDateLocationItem.fxml"));
                loader.setController(current);
                item = loader.load();
            } catch (IOException e) {
                item = new Pane(new Label(e.getMessage()));
                throw new RuntimeException(e);
            }
            content.getChildren().add(item);
        }
    }

    //Appelé par SelectedLocationItemController.@FXML remove() (s'enlève lui-même de tab en donnant la root du fxml et le controller
    public void removeItem(GridPane gridPane, SelectedLocationItemController controller){
        content.getChildren().remove(gridPane);
        locationSelectionControllers.remove(controller);
    }
    /**
     * si isInvalid est true on met le style invalid au fied qu'il faut remplir
     * et on ajout un message qui apparait lorsque l'on survole le field
     * @param isInvalid
     * @param message
     */
    public void setStartDateInvalid(boolean isInvalid, String message){
        if (isInvalid){
            startDatePicker.getStyleClass().add("invalid");
            startDatePicker.setTooltip(new Tooltip(message));
        }else{
            startDatePicker.getStyleClass().remove("invalid");
            startDatePicker.setTooltip(new Tooltip(null));
        }
    }

    public void setEndDateInvalid(boolean isInvalid, String mesage){
        if (isInvalid){
            endDatePicker.getStyleClass().add("invalid");
            endDatePicker.setTooltip(new Tooltip(mesage));
        }else{
            endDatePicker.getStyleClass().remove("invalid");
            endDatePicker.setTooltip(new Tooltip(null));
        }
    }

    public void setLocationInvalid(boolean isInvalid){
        if (isInvalid){
            selectionLocationButton.getStyleClass().add("invalid");
        }else{
            selectionLocationButton.getStyleClass().remove("invalid");
        }
    }
}
