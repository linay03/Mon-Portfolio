package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.model.Equipment;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.ResourceBundle;

public class EquipmentItemController implements Initializable {

    @FXML
    private GridPane container;
    @FXML
    private Label equipmentLabel, descriptionLabel, supplierLabel, priceLabel;
    @FXML
    private TextField amountField;

    private final Equipment equipment;
    private int amount;

    public Equipment getEquipment() {
        return equipment;
    }
    public int getAmount() {
        return amount;
    }

    EquipmentItemController(Equipment equipment, int amount){
        this.equipment = equipment;
        this.amount = amount;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        equipmentLabel.setText(equipment.getName());
        descriptionLabel.setText(equipment.getDescription());
        supplierLabel.setText(equipment.getSupplier().getName());
        priceLabel.setText(String.valueOf(equipment.getPrice()));

        amountField.setText(String.valueOf(amount));
    }

    @FXML
    private void upAmount(ActionEvent event){
        amount++;
        amountField.setText( String.valueOf(amount) );
    }
    @FXML
    private void downAmount(ActionEvent event){
        if(amount > 0){
            amount--;
            amountField.setText( String.valueOf(amount) );
        }
    }
    @FXML
    private void updateAmount(ActionEvent event){
        try{
            int inputedValue = Integer.parseInt( amountField.getText() );
            //clamp le min à 0
            if(inputedValue < 0){
                amount = 0;
                amountField.setText("0");
            }
            else{
                amount = inputedValue;
            }
        }
        catch(NumberFormatException e){
            //Reset à la valeur précédente si l'entrée n'est pas un int
            amountField.setText( String.valueOf(amount) );
        }
        container.requestFocus();
    }
}
