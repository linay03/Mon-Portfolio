package fr.uga.iut2.genevent.model.conflicts;

import fr.uga.iut2.genevent.model.Location;
import fr.uga.iut2.genevent.model.Wedding;

import java.io.Serializable;

public class WeddingLocationTimingConflict extends Conflict implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private Location location;

    public WeddingLocationTimingConflict(Wedding wedding, Location location) {
        super(wedding);
        this.location = location;
    }

    @Override
    public String conflictMessage() {
        return "ATTENTION : le lieu est déjà reservé pour ces date données";
    }
}
