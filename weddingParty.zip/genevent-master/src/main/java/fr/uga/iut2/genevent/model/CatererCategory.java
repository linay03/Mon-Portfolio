package fr.uga.iut2.genevent.model;

import java.io.Serializable;

public enum CatererCategory implements Serializable {

        Mexicain("Mexicain"),
        Italien("Italien"),
        Francais("Français"),
        Indien("Indien"),
        Vegan("Vegan"),
        Anglais("Anglais"),
        Americian("Americain"),
        Asiatique("Asiatique"),
        Chinois("Chinois"),
        Japonais("Japonais"),
        Coreen("Coréen"),
        Africain("Africain"),
        Mixte("Mixte"),
        Autre("Autre");


        private String label;

        CatererCategory(String label){
            this.label = label;
        }




}
