package fr.uga.iut2.genevent.model;

import fr.uga.iut2.genevent.controller.ConsultationController.OwnerConsultationDataController;
import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationDataController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.util.StringUtil;

import java.io.Serializable;

/**
 * Classe qui représente la notion de propriétaire
 * Cette classe herite de la notion de personne
 * Il peut s'agir d'une entreprise ou d'un particulier, le prénom est donc optionnel
 */
public class Owner extends Person implements Serializable, DirectoryItem<Owner> {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private String name;

    private String firstName;

    /**
     * Constructeur de la classe Owner
     * @param name est le nom du propriétaire
     * @param phone est le numero de teléphone du propriétaire
     * @param adress
     * @param mail est l'adresse mail du propriétaire
     */
    public Owner(String name, String phone, Adresse adress, String mail) {
        super(phone, adress, mail);
        setName(name);
        this.firstName=null;
    }

    /**
     * Constructeur de la classe Owner
     * @param name est le nom du propriétaire
     * @param firstName est le prénom du propriétaire
     * @param phone est le numero de teléphone du propriétaire
     * @param adress
     * @param mail est l'adresse mail du propriétaire
     */
    public Owner(String name, String firstName, String phone, Adresse adress, String mail) {
        super(phone, adress, mail);
        setName(name);
        setFirstName(firstName);
    }

    //Implémentation de DirectoryItem
    @Override
    public ItemFieldInfos getItemFieldInfo() {
        return new ItemFieldInfos(20, 20, 30, 0,
                getName(), getFirstName(), getMail(), "");
    }
    @Override
    public ConsultationDataController<Owner> getConsultationDataController() {
        return new OwnerConsultationDataController(this);
    }
    @Override
    public String getElementName() {
        return "propriétaire";
    }

    //Getters & Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = StringUtil.capitalize(name);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = StringUtil.capitalize(firstName);
    }
}
