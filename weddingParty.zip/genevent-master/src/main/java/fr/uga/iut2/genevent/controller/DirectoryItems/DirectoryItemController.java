package fr.uga.iut2.genevent.controller.DirectoryItems;

import fr.uga.iut2.genevent.controller.ConsultationController.ConsultationController;
import fr.uga.iut2.genevent.controller.DirectoryItem;
import fr.uga.iut2.genevent.controller.ItemFieldInfos;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.util.StringUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.ResourceBundle;

public class DirectoryItemController<T extends DirectoryItem<T>> implements Initializable {

    @FXML
    private GridPane grid;
    @FXML
    private Label field1, field2, field3, field4, infos;

    private final T object;

    public T getObject() {
        return object;
    }

    public DirectoryItemController(T object){
        this.object = object;
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ItemFieldInfos fieldInfos = object.getItemFieldInfo();

        //Must add up to 70
        grid.getColumnConstraints().get(0).setPercentWidth(fieldInfos.getField1Size());
        grid.getColumnConstraints().get(1).setPercentWidth(fieldInfos.getField2Size());
        grid.getColumnConstraints().get(2).setPercentWidth(fieldInfos.getField3Size());
        grid.getColumnConstraints().get(3).setPercentWidth(fieldInfos.getField4Size());

        //Initialise les valeurs affiché
        field1.setText(fieldInfos.getField1Value());
        field2.setText(fieldInfos.getField2Value());
        field3.setText(fieldInfos.getField3Value());
        field4.setText(fieldInfos.getField4Value());
        infos.setText("");
    }

    @FXML
    private void consult(ActionEvent event) {
        ConsultationController<T> controller = new ConsultationController<>(object.getConsultationDataController(),
                StringUtil.capitalize( object.getElementName() ));

        RootController.getPageManager().stepForward(
                new Page("Consultation d'un " + object.getElementName(), "/fr/uga/iut2/genevent/views/Consultation/Base/consultation.fxml",
                        controller, true)
        );
    }

}
