package fr.uga.iut2.genevent.model.conflicts;

import fr.uga.iut2.genevent.model.Location;
import fr.uga.iut2.genevent.model.Wedding;

import java.io.Serializable;

public class WeddingLocationCapacityConflict extends Conflict implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation
    private Location location;

    public WeddingLocationCapacityConflict(Wedding wedding, Location location) {
        super(wedding);
        this.location = location;
    }

    @Override
    public String conflictMessage() {
        return "ATTENTION : le nombre d'invités est supérieur à la capacité du lieu";
    }
}
