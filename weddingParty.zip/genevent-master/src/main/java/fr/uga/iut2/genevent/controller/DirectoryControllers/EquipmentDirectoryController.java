package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.DesignEquipment.EquipmentDesignController;
import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Equipment;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class EquipmentDirectoryController extends DirectoryController{

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        super.initialize(url, resourceBundle);
        initialiseNames("Matériels", "materiel");
        initItems();
    }

    @Override
    protected void initItems() {
        //vide tous les éléments
        getContent().getChildren().clear();

        for( Equipment equipment : RootController.getGenevent().getEquipments() ){

            Pane equipmentItem;

            try {
                //Charge l'item et le relie à l'élement
                DirectoryItemController<Equipment> controller = new DirectoryItemController<>(equipment);
                FXMLLoader individualItemLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/directoryItem.fxml"));
                individualItemLoader.setController(controller);
                equipmentItem = individualItemLoader.load();
            }
            catch (IOException e) {
                equipmentItem = new Pane(new Label(e.getMessage()));
                throw new RuntimeException(e);
            }
            //Assure que la taille de l'item prennent toute la fenêtre
            equipmentItem.setMinWidth(super.getContent().getWidth());
            equipmentItem.minWidthProperty().bind(super.getScrollPane().widthProperty());

            //Ajoute l'item
            super.getContent().getChildren().add(equipmentItem);
        }
    }

    @Override
    protected void createNew(ActionEvent event) {
        EquipmentDesignController controller = new EquipmentDesignController();
        RootController.getPageManager().stepForward(
                new Page("Création d'un matériel", "/fr/uga/iut2/genevent/views/Design/Base/designBase.fxml",
                        controller, true)
        );
    }
}
