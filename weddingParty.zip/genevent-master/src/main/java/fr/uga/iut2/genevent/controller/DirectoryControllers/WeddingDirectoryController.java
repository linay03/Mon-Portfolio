package fr.uga.iut2.genevent.controller.DirectoryControllers;

import fr.uga.iut2.genevent.controller.DirectoryItems.DirectoryItemController;
import fr.uga.iut2.genevent.controller.DesignWedding.WeddingDesignController;
import fr.uga.iut2.genevent.controller.Page;
import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Wedding;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class WeddingDirectoryController extends DirectoryController {
	

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		super.initialize(url, resourceBundle);
		initialiseNames("Mariages", "mariage");
		
		initItems();
	}
	
	@Override
	protected void initItems() {
		
		//vide tous les éléments
		getContent().getChildren().clear();
		
		//Vide actuellement
		for( Wedding wedding : RootController.getGenevent().getWeddings() ){
			
			Pane weddingItem;
			
			try {
				DirectoryItemController<Wedding> controller = new DirectoryItemController<>(wedding);
				FXMLLoader weddingItemLoader = new FXMLLoader(RootController.class.getResource("/fr/uga/iut2/genevent/views/Items/directoryItem.fxml"));
				weddingItemLoader.setController(controller);
				weddingItem = weddingItemLoader.load();
				
			} catch (IOException e) {
				weddingItem = new Pane(new Label(e.getMessage()));
				throw new RuntimeException(e);
			}
			
			super.getContent().getChildren().add(weddingItem);
		}
	}
	
	@Override
	protected void createNew(ActionEvent event) {
		RootController.getPageManager().stepForward(
				new Page("Création d'un Mariage", "/fr/uga/iut2/genevent/views/Design/DesignWedding/designWedding.fxml",
						new WeddingDesignController(), true)
		);
	}
}
