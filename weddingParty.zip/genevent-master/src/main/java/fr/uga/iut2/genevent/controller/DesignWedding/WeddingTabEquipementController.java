package fr.uga.iut2.genevent.controller.DesignWedding;

import fr.uga.iut2.genevent.controller.RootController;
import fr.uga.iut2.genevent.model.Equipment;
import fr.uga.iut2.genevent.model.CategorieMateriel;
import fr.uga.iut2.genevent.model.EquipmentOrder;
import fr.uga.iut2.genevent.model.Wedding;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class WeddingTabEquipementController implements Initializable {


	@FXML
	private ScrollPane scrollPane;
	@FXML
	private VBox content;

	private Wedding editedWedding;

	WeddingTabEquipementController(){}
	WeddingTabEquipementController(Wedding editedWedding){
		this.editedWedding = editedWedding;
	}

	private ArrayList<GridPane> equipmentItems = new ArrayList<>();
	private ArrayList<EquipmentItemController> equipmentItemControllers = new ArrayList<>();

	public ArrayList<EquipmentItemController> getEquipmentItemControllers(){
		ArrayList<EquipmentItemController> itemControllers = new ArrayList<>();
		for (EquipmentItemController itemController : equipmentItemControllers){
			if(itemController.getAmount() > 0){
				itemControllers.add(itemController);
			}
		}
		return itemControllers;
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {

		equipmentItems.clear();
		equipmentItemControllers.clear();

		//Pour chaque catégories
		for (CategorieMateriel currentCategory : CategorieMateriel.values()){

			//Ajoute le header de la catégorie
			equipmentItems.add( loadHeader(currentCategory) );

			//Pour tous les materiel pas encore ajouté
			for (Equipment currentEquipment : RootController.getGenevent().getEquipments()){

				//Si le materiel est dans cette catégorie
				if(currentEquipment.getCategoryEquipment() == currentCategory) {

					int amount = 0;

					//Si en mode édition update les fields au valeurs de l'objet
					if(editedWedding != null){
						amount = initializeAmounts(currentEquipment);
					}

					//Ajoute l'item
					equipmentItems.add(loadEquipment(currentEquipment, amount));
				}
			}
		}
		content.getChildren().setAll(equipmentItems);
	}

	private int initializeAmounts(Equipment currentEquipment) {
		int amount = 0;
		for (EquipmentOrder order : editedWedding.getEquipmentOrders()){
			if(order.getEquipment() == currentEquipment){
				amount = order.getAmount();
			}
		}
		return amount;
	}

	private GridPane loadHeader(CategorieMateriel currentCategory) {
		try{
			EquipmentHeaderItemController controller = new EquipmentHeaderItemController(currentCategory.name());
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingEquipmentHeaderItem.fxml"));
			loader.setController(controller);

			return loader.load();
		}
		catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	private GridPane loadEquipment(Equipment currentEquipment, int amount) {
		try{
			EquipmentItemController controller = new EquipmentItemController(currentEquipment, amount);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/views/Design/DesignWedding/designWeddingEquipmentItem.fxml"));
			loader.setController(controller);

			//Ajoute le controller à la liste de controller
			equipmentItemControllers.add(controller);

			return loader.load();
		}
		catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
