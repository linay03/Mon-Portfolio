module genevent {
    requires commons.validator;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.logging;

    opens fr.uga.iut2.genevent.template.vue to javafx.fxml;
    opens fr.uga.iut2.genevent.controller to javafx.fxml;
    
    exports fr.uga.iut2.genevent;
	opens fr.uga.iut2.genevent.controller.DesignWedding to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DirectoryItems to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.SelectionItems to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DesignLocation to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DesignIndividual to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DesignOwner to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DesignSupplier to javafx.fxml;

    opens fr.uga.iut2.genevent.controller.Selectors to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DirectoryControllers to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.ConsultationController to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DesignEquipment to javafx.fxml;
    opens fr.uga.iut2.genevent.controller.DesignCaterer to javafx.fxml;

}

